/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState } from 'react';
import { 
  BrowserRouter as Router, 
  Routes, 
  Route, 
  Navigate, 
  useNavigate, 
  useLocation 
} from 'react-router-dom';
import { 
  Briefcase, 
  LayoutDashboard, 
  Users, 
  FolderGit2, 
  FileText, 
  DollarSign, 
  User as UserIcon, 
  Sparkles, 
  LogOut, 
  Menu, 
  X, 
  Loader2, 
  ChevronRight,
  ShieldAlert,
  CreditCard,
  BarChart,
  Settings,
  AlertOctagon,
  Mail
} from 'lucide-react';

import { useAuth } from './contexts/AuthContext';
import AuthenticationView from './components/AuthenticationView';
import AdminLogin from './components/AdminLogin';

// User Views
import DashboardView from './components/DashboardView';
import ClientsView from './components/ClientsView';
import ProjectsView from './components/ProjectsView';
import InvoicesView from './components/InvoicesView';
import PaymentsView from './components/PaymentsView';
import ProfileView from './components/ProfileView';
import AiPredictiveView from './components/AiPredictiveView';
import NotificationsView from './components/NotificationsView';

// Admin Views
import AdminDashboardView from './components/AdminDashboardView';
import AdminUsersView from './components/AdminUsersView';
import AdminSubscriptionsView from './components/AdminSubscriptionsView';
import AdminAnalyticsView from './components/AdminAnalyticsView';
import AdminSettingsView from './components/AdminSettingsView';

export default function App() {
  return (
    <Router>
      <AppContent />
    </Router>
  );
}

function SuspendedAccountScreen() {
  const { logout, userProfile } = useAuth();
  return (
    <div className="min-h-screen bg-rose-50/20 flex items-center justify-center p-4 text-center font-sans" id="suspended-account-view">
      <div className="bg-white border border-rose-150 p-8 rounded-2xl max-w-md shadow-xl space-y-4">
        <div className="inline-flex p-3 bg-rose-100 text-rose-700 rounded-full animate-bounce">
          <AlertOctagon className="w-8 h-8" />
        </div>
        <h2 className="text-xl font-bold text-gray-900 tracking-tight">Your Workspace is Suspended</h2>
        <p className="text-xs text-gray-500 leading-relaxed">
          Hello <span className="font-bold">{userProfile?.name}</span>, your administrative access permissions have been frozen by the platform director. Contact our operations desk if you require verification guidelines.
        </p>
        <p className="text-xs text-rose-800 bg-rose-50 p-2.5 rounded-xl font-mono border border-rose-100 font-semibold select-all">
          SYS_STATUS: SUSPEND_ACCESS_DENIED
        </p>
        <button
          onClick={logout}
          className="w-full py-2.5 bg-rose-600 hover:bg-rose-700 text-white rounded-xl text-xs font-bold transition flex items-center justify-center gap-1.5 cursor-pointer"
          id="btn-suspend-signout"
        >
          <LogOut className="w-4 h-4" />
          <span>Exit Account Workspace</span>
        </button>
      </div>
    </div>
  );
}

function AppContent() {
  const { user, role, userProfile, loading, logout } = useAuth();
  const navigate = useNavigate();
  const location = useLocation();
  const [mobileMenuOpen, setMobileMenuOpen] = useState(false);

  // 1. Loading screen
  if (loading) {
    return (
      <div className="min-h-screen bg-gray-50 flex flex-col items-center justify-center font-sans" id="root-boot-loader">
        <Loader2 className="w-10 h-10 text-indigo-650 animate-spin" />
        <h2 className="text-sm font-bold text-gray-800 mt-4 tracking-wider uppercase font-mono animate-pulse">Booting Up Freelancer OS...</h2>
        <p className="text-3xs text-gray-400 mt-1 select-none">Configuring cloud authentication & database tables</p>
      </div>
    );
  }

  const isAdminRoute = location.pathname.startsWith('/admin');

  // 2. Unauthenticated Router Checks
  if (!user) {
    if (isAdminRoute) {
      if (location.pathname === '/admin/login') {
        return <AdminLogin />;
      }
      return <Navigate to="/admin/login" replace />;
    }
    
    // Default standard auth path
    if (location.pathname === '/login' || location.pathname === '/signup') {
      return <AuthenticationView />;
    }
    return <Navigate to="/login" replace />;
  }

  // 3. User Suspension Guard
  if (role === 'user' && userProfile?.status === 'suspended') {
    return <SuspendedAccountScreen />;
  }

  // 4. Admin Routing Block & Shell
  if (role === 'admin') {
    if (!isAdminRoute) {
      // Redirect logged-in admin to administrative desk dashboard
      return <Navigate to="/admin/dashboard" replace />;
    }

    const adminNavigationItems = [
      { path: '/admin/dashboard', label: 'Admin Dashboard', icon: LayoutDashboard },
      { path: '/admin/users', label: 'Manage Users', icon: Users },
      { path: '/admin/subscriptions', label: 'SaaS Client Licenses', icon: CreditCard },
      { path: '/admin/analytics', label: 'Platform Analytics', icon: BarChart },
      { path: '/admin/settings', label: 'System Settings', icon: Settings },
    ];

    const currentNav = adminNavigationItems.find(item => item.path === location.pathname);

    return (
      <div className="min-h-screen bg-gray-50 flex flex-col md:flex-row font-sans" id="admin-applet-shell">
        
        {/* MOBILE ADMIN NAVIGATION HEADER */}
        <header className="md:hidden bg-slate-950 border-b border-slate-800 px-4 py-3 flex items-center justify-between z-40 select-none sticky top-0 text-white" id="admin-mobile-header">
          <div className="flex items-center gap-2">
            <div className="p-1.5 bg-indigo-500 rounded-lg text-white">
              <ChevronRight className="w-5 h-5 shrink-0" />
            </div>
            <span className="text-base font-black tracking-tight font-sans">ADMIN CONSOLE</span>
          </div>
          <button
            onClick={() => setMobileMenuOpen(!mobileMenuOpen)}
            className="p-1.5 hover:bg-slate-800 rounded-lg text-slate-350 transition cursor-pointer text-white"
            id="admin-btn-mobile-burger"
          >
            {mobileMenuOpen ? <X className="w-5.5 h-5.5" /> : <Menu className="w-5.5 h-5.5" />}
          </button>
        </header>

        {/* MOBILE MENU ADMIN DRAWER */}
        {mobileMenuOpen && (
          <div className="fixed inset-0 bg-black/60 backdrop-blur-xs z-50 md:hidden flex justify-end" id="admin-mobile-overlay">
            <div className="bg-slate-900 w-72 h-full p-6 flex flex-col justify-between shadow-2xl text-white" id="admin-mobile-drawer-body">
              <div className="space-y-6">
                <div className="flex items-center justify-between border-b border-slate-800 pb-4">
                  <span className="text-lg font-black tracking-tight flex items-center gap-1.5 uppercase font-sans">
                    <ShieldAlert className="w-5 h-5 text-indigo-500" />
                    Admin Portal
                  </span>
                  <button
                    onClick={() => setMobileMenuOpen(false)}
                    className="p-1 hover:bg-slate-800 rounded-lg text-slate-400 transition cursor-pointer"
                    id="admin-btn-close-drawer"
                  >
                    <X className="w-4.5 h-4.5" />
                  </button>
                </div>

                <nav className="flex flex-col gap-1.5" id="admin-mobile-nav">
                  {adminNavigationItems.map((item) => {
                    const Icon = item.icon;
                    const isActive = location.pathname === item.path;
                    return (
                      <button
                        key={item.path}
                        onClick={() => {
                          navigate(item.path);
                          setMobileMenuOpen(false);
                        }}
                        className={`w-full p-2.5 px-3.5 rounded-xl text-xs font-bold text-left flex items-center gap-2.5 transition cursor-pointer ${
                          isActive 
                            ? 'bg-indigo-600 text-white shadow-md' 
                            : 'text-slate-300 hover:bg-slate-800'
                        }`}
                        id={`admin-mob-nav-${item.path.split('/').pop()}`}
                      >
                        <Icon className="w-4.5 h-4.5 shrink-0" />
                        {item.label}
                      </button>
                    );
                  })}
                </nav>
              </div>

              <div className="border-t border-slate-800 pt-4" id="admin-mobile-footer">
                <button
                  onClick={logout}
                  className="w-full py-2 bg-slate-950 hover:bg-rose-950 text-rose-400 rounded-lg text-xs font-bold transition flex items-center justify-center gap-1.5 cursor-pointer border border-slate-850"
                  id="admin-btn-mobile-logout"
                >
                  <LogOut className="w-4.5 h-4.5 mt-0.5" />
                  Sign Out Console
                </button>
              </div>
            </div>
          </div>
        )}

        {/* DESKTOP PERMANENT ADMIN SIDEBAR */}
        <aside className="hidden md:flex md:w-64 md:flex-col bg-slate-950 text-white border-r border-slate-800 p-6 justify-between select-none shrink-0 h-screen sticky top-0" id="admin-desktop-sidebar">
          <div className="space-y-8">
            <div className="flex items-center gap-2.5 border-b border-slate-850 pb-4">
              <div className="p-2 bg-indigo-600 text-white rounded-xl shadow-lg shrink-0">
                <ShieldAlert className="w-5.5 h-5.5" />
              </div>
              <div>
                <span className="text-base font-black tracking-tight text-white uppercase font-sans">ADMIN SUITE</span>
                <p className="text-[10px] text-indigo-400 font-bold uppercase tracking-widest leading-none mt-0.5">Control Terminal</p>
              </div>
            </div>

            <nav className="flex flex-col gap-1" id="admin-desktop-nav-routes">
              {adminNavigationItems.map((item) => {
                const Icon = item.icon;
                const isActive = location.pathname === item.path;
                return (
                  <button
                    key={item.path}
                    onClick={() => navigate(item.path)}
                    className={`w-full p-2.5 px-3.5 rounded-xl text-2xs font-bold text-left flex items-center gap-2.5 transition duration-150 cursor-pointer border border-transparent ${
                      isActive 
                        ? 'bg-indigo-600 text-white shadow-md' 
                        : 'text-slate-300 hover:bg-slate-900'
                    }`}
                    id={`admin-desk-nav-${item.path.split('/').pop()}`}
                  >
                    <Icon className="w-4.5 h-4.5 shrink-0" />
                    {item.label}
                  </button>
                );
              })}
            </nav>
          </div>

          <div className="space-y-4" id="admin-desktop-sidebar-footer">
            <button
              onClick={logout}
              className="w-full py-2 bg-slate-900 text-rose-400 border border-slate-800 hover:bg-rose-950 rounded-xl text-xs font-bold transition flex items-center justify-center gap-1.5 cursor-pointer"
              id="admin-btn-desktop-logout"
            >
              <LogOut className="w-3.5 h-3.5 mt-0.5" />
              Sign Out Console
            </button>
          </div>
        </aside>

        {/* CENTRAL VIEW PORT FOR ADMIN VIEW CHANNELS */}
        <main className="flex-1 p-5 md:p-8 overflow-y-auto max-w-7xl mx-auto w-full min-h-[calc(100vh-60px)] md:min-h-screen" id="admin-viewport">
          <Routes>
            <Route path="/admin/dashboard" element={<AdminDashboardView />} />
            <Route path="/admin/users" element={<AdminUsersView />} />
            <Route path="/admin/subscriptions" element={<AdminSubscriptionsView />} />
            <Route path="/admin/analytics" element={<AdminAnalyticsView />} />
            <Route path="/admin/settings" element={<AdminSettingsView />} />
            <Route path="*" element={<Navigate to="/admin/dashboard" replace />} />
          </Routes>
        </main>

      </div>
    );
  }

  // 5. User Routing Block & Shell
  if (role === 'user') {
    if (isAdminRoute) {
      // Users attempting to hit admin pages get re-routed back to user dashboard workspace
      return <Navigate to="/dashboard" replace />;
    }

    const userNavigationItems = [
      { path: '/dashboard', label: 'SaaS Dashboard', icon: LayoutDashboard },
      { path: '/clients', label: 'Client Directory', icon: Users },
      { path: '/projects', label: 'Work Deliverables', icon: FolderGit2 },
      { path: '/invoices', label: 'Invoice Generator', icon: FileText },
      { path: '/payments', label: 'Payment Tracker', icon: DollarSign },
      { path: '/notifications', label: 'Email Dispatch Desk', icon: Mail },
      { path: '/ai-copilot', label: 'AI Workspace Copilot', icon: Sparkles },
      { path: '/settings', label: 'Workspace Settings', icon: UserIcon },
    ];

    return (
      <div className="min-h-screen bg-gray-50 flex flex-col md:flex-row font-sans" id="user-applet-shell">
        
        {/* MOBILE USER NAVIGATION HEADER */}
        <header className="md:hidden bg-white border-b border-gray-150 px-4 py-3 flex items-center justify-between z-40 select-none sticky top-0" id="user-mobile-header">
          <div className="flex items-center gap-2">
            <div className="p-1.5 bg-indigo-600 rounded-lg text-white">
              <Briefcase className="w-5 h-5 shrink-0" />
            </div>
            <span className="text-base font-black text-gray-900 tracking-tight font-sans">FREELANCER OS</span>
          </div>
          <button
            onClick={() => setMobileMenuOpen(!mobileMenuOpen)}
            className="p-1.5 hover:bg-gray-100 rounded-lg text-gray-700 transition cursor-pointer"
            id="user-btn-mobile-burger"
          >
            {mobileMenuOpen ? <X className="w-5.5 h-5.5" /> : <Menu className="w-5.5 h-5.5" />}
          </button>
        </header>

        {/* MOBILE MENU USER DRAWER */}
        {mobileMenuOpen && (
          <div className="fixed inset-0 bg-black/50 backdrop-blur-xs z-50 md:hidden flex justify-end" id="user-mobile-overlay">
            <div className="bg-white w-72 h-full p-6 flex flex-col justify-between shadow-2xl text-gray-850" id="user-mobile-drawer-body">
              <div className="space-y-6">
                <div className="flex items-center justify-between border-b border-gray-100 pb-4">
                  <span className="text-lg font-black text-gray-900 tracking-tight flex items-center gap-1.5 font-sans">
                    <Briefcase className="w-5 h-5 text-indigo-600" />
                    Freelancer OS
                  </span>
                  <button
                    onClick={() => setMobileMenuOpen(false)}
                    className="p-1 hover:bg-gray-100 rounded-lg text-gray-500 transition cursor-pointer"
                    id="user-btn-close-drawer"
                  >
                    <X className="w-4.5 h-4.5" />
                  </button>
                </div>

                <nav className="flex flex-col gap-1.5" id="user-mobile-nav">
                  {userNavigationItems.map((item) => {
                    const Icon = item.icon;
                    const isActive = location.pathname === item.path;
                    return (
                      <button
                        key={item.path}
                        onClick={() => {
                          navigate(item.path);
                          setMobileMenuOpen(false);
                        }}
                        className={`w-full p-2.5 px-3.5 rounded-xl text-xs font-bold text-left flex items-center justify-between transition cursor-pointer ${
                          isActive 
                            ? 'bg-indigo-600 text-white shadow-md' 
                            : 'text-gray-650 hover:bg-gray-50'
                        }`}
                        id={`user-mob-nav-${item.path.split('/').pop()}`}
                      >
                        <span className="flex items-center gap-2.5">
                          <Icon className="w-4.5 h-4.5 shrink-0" />
                          {item.label}
                        </span>
                      </button>
                    );
                  })}
                </nav>
              </div>

              <div className="border-t border-gray-100 pt-4" id="user-mobile-footer">
                <div className="flex items-center gap-3 mb-4 select-none">
                  <img 
                    src={userProfile?.profilePhoto || `https://api.dicebear.com/7.x/initials/svg?seed=${userProfile?.name}`} 
                    alt="user avatar" 
                    referrerPolicy="no-referrer"
                    className="w-10 h-10 rounded-lg bg-gray-50 object-cover" 
                  />
                  <div>
                    <h4 className="text-xs font-bold text-gray-900 truncate max-w-[160px]">{userProfile?.name || 'Freelancer'}</h4>
                    <p className="text-3xs text-gray-400 truncate max-w-[160px]">{userProfile?.email}</p>
                  </div>
                </div>
                <button
                  onClick={logout}
                  className="w-full py-2 bg-gray-50 hover:bg-rose-50 text-rose-600 rounded-lg text-xs font-bold transition flex items-center justify-center gap-1.5 cursor-pointer border border-gray-150"
                  id="user-btn-mobile-logout"
                >
                  <LogOut className="w-4.5 h-4.5 mt-0.5" />
                  Sign Out Workspace
                </button>
              </div>
            </div>
          </div>
        )}

        {/* DESKTOP PERMANENT USER SIDEBAR */}
        <aside className="hidden md:flex md:w-64 md:flex-col bg-white border-r border-gray-200 p-6 justify-between select-none shrink-0 h-screen sticky top-0" id="user-desktop-sidebar">
          <div className="space-y-8">
            <div className="flex items-center gap-2.5 border-b border-gray-50 pb-4">
              <div className="p-2 bg-indigo-600 text-white rounded-xl shadow-md shrink-0">
                <Briefcase className="w-5.5 h-5.5" />
              </div>
              <div>
                <span className="text-base font-black text-gray-950 tracking-tight">FREELANCER OS</span>
                <p className="text-[10px] text-indigo-600 font-bold uppercase tracking-widest leading-none mt-0.5">SaaS Suite</p>
              </div>
            </div>

            <nav className="flex flex-col gap-1" id="user-desktop-nav-routes">
              {userNavigationItems.map((item) => {
                const Icon = item.icon;
                const isActive = location.pathname === item.path;
                return (
                  <button
                    key={item.path}
                    onClick={() => navigate(item.path)}
                    className={`w-full p-2.5 px-3.5 rounded-xl text-2xs font-bold font-sans text-left flex items-center justify-between transition duration-150 cursor-pointer border border-transparent ${
                      isActive 
                        ? 'bg-indigo-600 text-white shadow-xs' 
                        : 'text-gray-650 hover:bg-gray-50 hover:text-gray-900'
                    }`}
                    id={`user-desk-nav-${item.path.split('/').pop()}`}
                  >
                    <span className="flex items-center gap-2.5 font-sans">
                      <Icon className="w-4.5 h-4.5 shrink-0" />
                      {item.label}
                    </span>
                  </button>
                );
              })}
            </nav>
          </div>

          <div className="space-y-4" id="user-desktop-sidebar-footer">
            <div className="bg-gray-50/50 hover:bg-gray-50 border border-gray-150/50 p-3 rounded-xl flex items-center gap-2.5 transition">
              <img 
                src={userProfile?.profilePhoto || `https://api.dicebear.com/7.x/initials/svg?seed=${userProfile?.name}`} 
                alt="avatar user" 
                referrerPolicy="no-referrer"
                className="w-8.5 h-8.5 bg-gray-100 rounded-lg object-cover" 
              />
              <div className="flex-1 min-w-0">
                <h4 className="text-xs font-bold text-gray-900 truncate">{userProfile?.name || 'Freelancer'}</h4>
                <p className="text-[10px] text-gray-400 truncate mt-0.5">{userProfile?.email}</p>
              </div>
            </div>

            <button
              onClick={logout}
              className="w-full py-2 bg-white text-rose-600 border border-rose-100 hover:bg-rose-50 rounded-xl text-xs font-bold transition duration-150 flex items-center justify-center gap-1.5 cursor-pointer"
              id="user-btn-desktop-logout"
            >
              <LogOut className="w-3.5 h-3.5 mt-0.5" />
              Sign Out Suite
            </button>
          </div>
        </aside>

        {/* CENTRAL VIEW PORT FOR CORE USER DESK VIEWS */}
        <main className="flex-1 p-5 md:p-8 overflow-y-auto max-w-7xl mx-auto w-full min-h-[calc(100vh-60px)] md:min-h-screen" id="user-viewport">
          <Routes>
            <Route path="/dashboard" element={<DashboardView onNavigate={(view) => navigate('/' + (view === 'ai' ? 'ai-copilot' : view))} />} />
            <Route path="/clients" element={<ClientsView />} />
            <Route path="/projects" element={<ProjectsView />} />
            <Route path="/invoices" element={<InvoicesView />} />
            <Route path="/payments" element={<PaymentsView />} />
            <Route path="/notifications" element={<NotificationsView />} />
            <Route path="/ai-copilot" element={<AiPredictiveView />} />
            <Route path="/settings" element={<ProfileView />} />
            <Route path="*" element={<Navigate to="/dashboard" replace />} />
          </Routes>
        </main>

      </div>
    );
  }

  // Fallback re-route just in case
  return <Navigate to="/login" replace />;
}
