import React, { createContext, useContext, useState, useEffect, ReactNode } from 'react';
import { 
  User, 
  onAuthStateChanged,
  createUserWithEmailAndPassword,
  signInWithEmailAndPassword,
  signInWithPopup,
  signOut,
  sendPasswordResetEmail,
  updateProfile as updateAuthProfile
} from 'firebase/auth';
import { auth, googleProvider } from '../firebase';
import { UserProfile, AdminProfile } from '../types';
import { 
  getUserProfile, 
  createUserProfile, 
  updateUserProfile, 
  getAdminProfile, 
  createAdminProfile 
} from '../services/db';

interface AuthContextType {
  user: User | null;
  userProfile: UserProfile | null;
  adminProfile: AdminProfile | null;
  role: 'user' | 'admin' | null;
  loading: boolean;
  signUpWithEmail: (email: string, password: string, name: string) => Promise<void>;
  loginWithEmail: (email: string, password: string) => Promise<void>;
  loginWithGoogle: () => Promise<void>;
  resetPassword: (email: string) => Promise<void>;
  logout: () => Promise<void>;
  updateProfileInfo: (details: Partial<Omit<UserProfile, 'userId' | 'createdAt'>>) => Promise<void>;
  refreshProfile: () => Promise<void>;
}

const AuthContext = createContext<AuthContextType | undefined>(undefined);

export function useAuth() {
  const context = useContext(AuthContext);
  if (!context) {
    throw new Error('useAuth must be used within an AuthProvider');
  }
  return context;
}

export function AuthProvider({ children }: { children: ReactNode }) {
  const [user, setUser] = useState<User | null>(null);
  const [userProfile, setUserProfile] = useState<UserProfile | null>(null);
  const [adminProfile, setAdminProfile] = useState<AdminProfile | null>(null);
  const [role, setRole] = useState<'user' | 'admin' | null>(null);
  const [loading, setLoading] = useState(true);

  // Load profile details from database based on authenticated user
  const fetchProfile = async (uid: string, userEmail: string, userDisplayName?: string) => {
    try {
      // 1. Check if they are the designated bootstrap admin, or already an registered admin doc
      const isBootstrap = userEmail.toLowerCase() === "usainpakistanvpn@gmail.com";
      let admin = await getAdminProfile(uid);

      if (!admin && isBootstrap) {
        // Secure manual initialization of the bootstrap admin profile
        admin = await createAdminProfile(uid, userDisplayName || 'Usain Admin', userEmail);
      }

      if (admin) {
        setAdminProfile(admin);
        setUserProfile(null);
        setRole('admin');
      } else {
        // 2. Fetch standard user profile
        let profile = await getUserProfile(uid);
        if (!profile) {
          // Create with default role and status fields
          profile = await createUserProfile(uid, {
            name: userDisplayName || userEmail.split('@')[0],
            email: userEmail,
            companyName: '',
            freelancerCategory: 'Consulting',
            country: 'United States',
            profilePhoto: `https://api.dicebear.com/7.x/initials/svg?seed=${encodeURIComponent(userDisplayName || userEmail)}`,
            role: 'user',
            status: 'active'
          });
        }
        setUserProfile(profile);
        setAdminProfile(null);
        setRole('user');
      }
    } catch (err) {
      console.error('Failed to load user profile roles from database', err);
      // Fail gracefully
      setRole(null);
      setUserProfile(null);
      setAdminProfile(null);
    }
  };

  useEffect(() => {
    const unsubscribe = onAuthStateChanged(auth, async (currentUser) => {
      setUser(currentUser);
      if (currentUser) {
        await fetchProfile(currentUser.uid, currentUser.email || '', currentUser.displayName || '');
      } else {
        setUserProfile(null);
        setAdminProfile(null);
        setRole(null);
      }
      setLoading(false);
    });

    return () => unsubscribe();
  }, []);

  const signUpWithEmail = async (email: string, password: string, name: string) => {
    setLoading(true);
    try {
      const result = await createUserWithEmailAndPassword(auth, email, password);
      // Update Auth Profile Display Name
      await updateAuthProfile(result.user, { displayName: name });
      // Create user entry in users/admins collection
      await fetchProfile(result.user.uid, email, name);
    } catch (err) {
      setLoading(false);
      throw err;
    }
  };

  const loginWithEmail = async (email: string, password: string) => {
    setLoading(true);
    try {
      await signInWithEmailAndPassword(auth, email, password);
    } catch (err) {
      setLoading(false);
      throw err;
    }
  };

  const loginWithGoogle = async () => {
    setLoading(true);
    try {
      await signInWithPopup(auth, googleProvider);
    } catch (err) {
      setLoading(false);
      throw err;
    }
  };

  const resetPassword = async (email: string) => {
    await sendPasswordResetEmail(auth, email);
  };

  const logout = async () => {
    setLoading(true);
    try {
      await signOut(auth);
    } finally {
      setLoading(false);
    }
  };

  const updateProfileInfo = async (details: Partial<Omit<UserProfile, 'userId' | 'createdAt'>>) => {
    if (!user) throw new Error('Unauthenticated');
    await updateUserProfile(user.uid, details);
    if (userProfile) {
      setUserProfile({
        ...userProfile,
        ...details
      } as UserProfile);
    }
  };

  const refreshProfile = async () => {
    if (user) {
      await fetchProfile(user.uid, user.email || '', user.displayName || '');
    }
  };

  const value = {
    user,
    userProfile,
    adminProfile,
    role,
    loading,
    signUpWithEmail,
    loginWithEmail,
    loginWithGoogle,
    resetPassword,
    logout,
    updateProfileInfo,
    refreshProfile
  };

  return (
    <AuthContext.Provider value={value}>
      {!loading && children}
    </AuthContext.Provider>
  );
}
