import { 
  collection, 
  doc, 
  getDocs, 
  setDoc,
  query, 
  where, 
  orderBy, 
  limit, 
  serverTimestamp,
  getDoc
} from 'firebase/firestore';
import { db, handleFirestoreError, OperationType } from '../firebase';
import { NotificationEmail, Client, Project, Invoice } from '../types';

// ==========================================
// 1. Fetch Email Notification Logs
// ==========================================
export async function getEmailLogs(userId: string): Promise<NotificationEmail[]> {
  const path = 'emails';
  try {
    const ref = collection(db, 'emails');
    const q = query(ref, where('userId', '==', userId), orderBy('sentAt', 'desc'), limit(50));
    const snap = await getDocs(q);
    const items: NotificationEmail[] = [];
    snap.forEach((doc) => {
      items.push({ id: doc.id, ...doc.data() } as NotificationEmail);
    });
    return items;
  } catch (error) {
    handleFirestoreError(error, OperationType.LIST, path);
    return [];
  }
}

// ==========================================
// 2. Core Email Sender & Ledger Registrator
// ==========================================
export async function sendTransactionalEmail(
  userId: string, 
  emailData: Omit<NotificationEmail, 'id' | 'userId' | 'sentAt' | 'status'>
): Promise<NotificationEmail> {
  const path = 'emails';
  try {
    const ref = collection(db, 'emails');
    const newDocRef = doc(ref);

    // Dynamic key scanning if user brings their secret (optional extensibility)
    const hasCredentials = false; // By default we leverage high-fidelity simulation and log to our sandboxed user dashboard

    const data: NotificationEmail = {
      id: newDocRef.id,
      userId,
      ...emailData,
      status: hasCredentials ? 'sent' : 'simulated',
      sentAt: serverTimestamp()
    };

    await setDoc(newDocRef, data);

    console.log(`[TRANSACTIONAL EMAIL DISPATCHED] to ${emailData.recipientName} (${emailData.recipientEmail}) - Event: ${emailData.triggerEvent}`);
    
    return data;
  } catch (error) {
    handleFirestoreError(error, OperationType.CREATE, path);
    throw error;
  }
}

// ==========================================
// 3. Dynamic Template Composers
// ==========================================

export function composeInvoiceCreatedEmail(invoice: Invoice, client: Client, freelancerName: string): { subject: string; body: string } {
  const formattedTotal = invoice.totalAmount.toLocaleString('en-US', { style: 'currency', currency: 'USD' });
  const subject = `Invoice ${invoice.invoiceNumber} from ${freelancerName || 'Freelancer'}`;
  
  const body = `Hi ${client.clientName},

I hope you are doing well!

I have generated a new billing invoice (${invoice.invoiceNumber}) for our project deliverables. 

--------------------------------------------------
INVOICE SUMMARY:
Invoice Serial: ${invoice.invoiceNumber}
Date of Emission: ${invoice.invoiceDate}
Settlement Due Date: ${invoice.dueDate}
Outstanding Total: ${formattedTotal}
--------------------------------------------------

You can view the comprehensive details and items ledger in our shared workstation. Please render payment on or before ${invoice.dueDate}.

Best regards,
${freelancerName || 'Freelancer'}
${client.company ? `Partner for ${client.company}` : ''}`;

  return { subject, body };
}

export function composePaymentReceivedEmail(invoiceNo: string, amount: number, client: Client, freelancerName: string): { subject: string; body: string } {
  const formattedAmount = amount.toLocaleString('en-US', { style: 'currency', currency: 'USD' });
  const subject = `Receipt Confirmation: Payment Received for ${invoiceNo}`;
  
  const body = `Hi ${client.clientName},

Thank you for your prompt settlement!

This email is to confirm that I have safely received your payment of ${formattedAmount} matching invoice ${invoiceNo}. Your invoice ledger is now marked as fully PAID.

I truly appreciate your timely cooperation and partner collaboration on this work.

Warmest regards,
${freelancerName || 'Freelancer'}
${client.company ? 'Finance Desk' : ''}`;

  return { subject, body };
}

export function composePaymentReminderEmail(invoice: Invoice, client: Client, freelancerName: string): { subject: string; body: string } {
  const formattedTotal = invoice.totalAmount.toLocaleString('en-US', { style: 'currency', currency: 'USD' });
  const subject = `Urgent Follow-up Reminder: Overdue Settlement ${invoice.invoiceNumber}`;
  
  const body = `Hi ${client.clientName},

I am writing to politely follow up on your payment of ${formattedTotal} for invoice ${invoice.invoiceNumber}, which was scheduled to be settled on ${invoice.dueDate}.

This account is currently past its due terms. If payment has already been dispatched, please disregard this automated note.

Otherwise, please arrange for the outstanding balance of ${formattedTotal} to be processed at your earliest convenience to preserve active project timelines.

Thank you for your understanding!

Best regards,
${freelancerName || 'Freelancer'}`;

  return { subject, body };
}

export function composeDeadlineApproachingEmail(project: Project, client: Client, freelancerName: string, daysLeft: number): { subject: string; body: string } {
  const subject = `Project Milestone Check: "${project.projectName}" Deadline Approaching`;
  const daysText = daysLeft === 0 ? "today" : daysLeft === 1 ? "tomorrow" : `in ${daysLeft} days`;

  const body = `Hi ${client.clientName},

This is an automated project milestone reminder for our upcoming deliverable "${project.projectName}".

Based on our scheduled timetable, our project milestone or delivery date is scheduled for ${project.deadline} (${daysText}).

I am wrapping up the final deliverables and auditing the items checklist. If you have any questions or feedback before this deadline, please reach out.

Best regards,
${freelancerName || 'Freelancer'}
Lead Project Desk`;

  return { subject, body };
}

// ==========================================
// 4. Automated Triggers Hook
// ==========================================

/**
 * Triggers notification upon raw invoice creation
 */
export async function triggerInvoiceCreatedNotification(userId: string, invoice: Invoice): Promise<NotificationEmail | null> {
  try {
    const clientRef = doc(db, 'clients', invoice.clientId);
    const clientSnap = await getDoc(clientRef);
    if (!clientSnap.exists()) return null;
    const client = clientSnap.data() as Client;

    const userRef = doc(db, 'users', userId);
    const userSnap = await getDoc(userRef);
    const freelancerName = userSnap.exists() ? (userSnap.data().companyName || userSnap.data().name) : 'Freelancer';

    const { subject, body } = composeInvoiceCreatedEmail(invoice, client, freelancerName);

    return await sendTransactionalEmail(userId, {
      recipientEmail: client.email,
      recipientName: client.clientName,
      subject,
      body,
      triggerEvent: 'invoice_created',
      referenceId: invoice.id,
      referenceNumber: invoice.invoiceNumber
    });
  } catch (err) {
    console.error('Failed to trigger invoice created notification:', err);
    return null;
  }
}

/**
 * Triggers notification upon invoice payment confirmation
 */
export async function triggerPaymentReceivedNotification(
  userId: string, 
  invoiceId: string, 
  invoiceNumber: string, 
  amount: number, 
  clientId: string
): Promise<NotificationEmail | null> {
  try {
    const clientRef = doc(db, 'clients', clientId);
    const clientSnap = await getDoc(clientRef);
    if (!clientSnap.exists()) return null;
    const client = clientSnap.data() as Client;

    const userRef = doc(db, 'users', userId);
    const userSnap = await getDoc(userRef);
    const freelancerName = userSnap.exists() ? (userSnap.data().companyName || userSnap.data().name) : 'Freelancer';

    const { subject, body } = composePaymentReceivedEmail(invoiceNumber, amount, client, freelancerName);

    return await sendTransactionalEmail(userId, {
      recipientEmail: client.email,
      recipientName: client.clientName,
      subject,
      body,
      triggerEvent: 'payment_received',
      referenceId: invoiceId,
      referenceNumber: invoiceNumber
    });
  } catch (err) {
    console.error('Failed to trigger payment received notification:', err);
    return null;
  }
}

/**
 * Triggers manual or automated follow-up payment reminders
 */
export async function triggerPaymentReminderNotification(userId: string, invoiceId: string): Promise<NotificationEmail | null> {
  try {
    const invoiceRef = doc(db, 'invoices', invoiceId);
    const invoiceSnap = await getDoc(invoiceRef);
    if (!invoiceSnap.exists()) return null;
    const invoice = invoiceSnap.data() as Invoice;

    const clientRef = doc(db, 'clients', invoice.clientId);
    const clientSnap = await getDoc(clientRef);
    if (!clientSnap.exists()) return null;
    const client = clientSnap.data() as Client;

    const userRef = doc(db, 'users', userId);
    const userSnap = await getDoc(userRef);
    const freelancerName = userSnap.exists() ? (userSnap.data().companyName || userSnap.data().name) : 'Freelancer';

    const { subject, body } = composePaymentReminderEmail(invoice, client, freelancerName);

    return await sendTransactionalEmail(userId, {
      recipientEmail: client.email,
      recipientName: client.clientName,
      subject,
      body,
      triggerEvent: 'payment_reminder',
      referenceId: invoice.id,
      referenceNumber: invoice.invoiceNumber
    });
  } catch (err) {
    console.error('Failed to trigger payment reminder notification:', err);
    return null;
  }
}

/**
 * Triggers project deadline alerts
 */
export async function triggerDeadlineApproachingNotification(
  userId: string, 
  projectId: string, 
  daysLeft: number
): Promise<NotificationEmail | null> {
  try {
    const projectRef = doc(db, 'projects', projectId);
    const projectSnap = await getDoc(projectRef);
    if (!projectSnap.exists()) return null;
    const project = projectSnap.data() as Project;

    const clientRef = doc(db, 'clients', project.clientId);
    const clientSnap = await getDoc(clientRef);
    if (!clientSnap.exists()) return null;
    const client = clientSnap.data() as Client;

    const userRef = doc(db, 'users', userId);
    const userSnap = await getDoc(userRef);
    const freelancerName = userSnap.exists() ? (userSnap.data().companyName || userSnap.data().name) : 'Freelancer';

    const { subject, body } = composeDeadlineApproachingEmail(project, client, freelancerName, daysLeft);

    return await sendTransactionalEmail(userId, {
      recipientEmail: client.email,
      recipientName: client.clientName,
      subject,
      body,
      triggerEvent: 'deadline_approaching',
      referenceId: project.id,
      referenceNumber: project.projectName
    });
  } catch (err) {
    console.error('Failed to trigger deadline notification:', err);
    return null;
  }
}
