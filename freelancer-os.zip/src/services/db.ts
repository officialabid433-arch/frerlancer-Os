import { 
  collection, 
  doc, 
  getDoc, 
  getDocs, 
  setDoc, 
  updateDoc, 
  deleteDoc, 
  query, 
  where, 
  orderBy, 
  limit, 
  serverTimestamp 
} from 'firebase/firestore';
import { db, handleFirestoreError, OperationType } from '../firebase';
import { 
  triggerInvoiceCreatedNotification, 
  triggerPaymentReceivedNotification 
} from './emailService';
import { 
  UserProfile, 
  AdminProfile,
  Subscription,
  Client, 
  Project, 
  Invoice, 
  Payment, 
  Activity, 
  ClientStatus, 
  ProjectStatus, 
  PaymentStatus, 
  ActivityType 
} from '../types';

// ==========================================
// 1. User Profiles
// ==========================================
export async function getUserProfile(userId: string): Promise<UserProfile | null> {
  const path = `users/${userId}`;
  try {
    const docRef = doc(db, 'users', userId);
    const docSnap = await getDoc(docRef);
    if (docSnap.exists()) {
      return docSnap.data() as UserProfile;
    }
    return null;
  } catch (error) {
    handleFirestoreError(error, OperationType.GET, path);
    return null;
  }
}

export async function createUserProfile(userId: string, profile: Omit<UserProfile, 'userId' | 'createdAt'>): Promise<UserProfile> {
  const path = `users/${userId}`;
  try {
    const docRef = doc(db, 'users', userId);
    const profileData: UserProfile = {
      userId,
      ...profile,
      createdAt: serverTimestamp()
    };
    await setDoc(docRef, profileData);
    await logActivity(userId, 'Created your Freelancer OS profile', ActivityType.AUTH);
    return profileData;
  } catch (error) {
    handleFirestoreError(error, OperationType.CREATE, path);
    throw error;
  }
}

export async function updateUserProfile(userId: string, profile: Partial<Omit<UserProfile, 'userId' | 'createdAt'>>): Promise<void> {
  const path = `users/${userId}`;
  try {
    const docRef = doc(db, 'users', userId);
    await updateDoc(docRef, {
      ...profile,
      updatedAt: serverTimestamp()
    });
    await logActivity(userId, 'Updated your company profile information', ActivityType.AUTH);
  } catch (error) {
    handleFirestoreError(error, OperationType.UPDATE, path);
    throw error;
  }
}

// ==========================================
// 2. Client Management
// ==========================================
export async function getClients(userId: string): Promise<Client[]> {
  const path = 'clients';
  try {
    const clientsRef = collection(db, 'clients');
    const q = query(clientsRef, where('userId', '==', userId), orderBy('createdAt', 'desc'));
    const snap = await getDocs(q);
    const items: Client[] = [];
    snap.forEach((doc) => {
      items.push({ id: doc.id, ...doc.data() } as Client);
    });
    return items;
  } catch (error) {
    handleFirestoreError(error, OperationType.LIST, path);
    return [];
  }
}

export async function addClient(userId: string, client: Omit<Client, 'id' | 'userId' | 'createdAt' | 'updatedAt'>): Promise<Client> {
  const path = 'clients';
  try {
    const clientColRef = collection(db, 'clients');
    const newDocRef = doc(clientColRef); // Generates valid safe DB ID automatically
    const clientData: Client = {
      id: newDocRef.id,
      userId,
      ...client,
      createdAt: serverTimestamp(),
      updatedAt: serverTimestamp()
    };
    await setDoc(newDocRef, clientData);
    await logActivity(userId, `Added new client: ${client.clientName} (${client.company})`, ActivityType.CLIENT);
    return clientData;
  } catch (error) {
    handleFirestoreError(error, OperationType.CREATE, path);
    throw error;
  }
}

export async function updateClient(userId: string, clientId: string, client: Partial<Omit<Client, 'id' | 'userId' | 'createdAt' | 'updatedAt'>>): Promise<void> {
  const path = `clients/${clientId}`;
  try {
    const docRef = doc(db, 'clients', clientId);
    await updateDoc(docRef, {
      ...client,
      updatedAt: serverTimestamp()
    });
    await logActivity(userId, `Updated details of client: ${client.clientName || 'record ID ' + clientId}`, ActivityType.CLIENT);
  } catch (error) {
    handleFirestoreError(error, OperationType.UPDATE, path);
    throw error;
  }
}

export async function deleteClient(userId: string, clientId: string, clientName: string): Promise<void> {
  const path = `clients/${clientId}`;
  try {
    const docRef = doc(db, 'clients', clientId);
    await deleteDoc(docRef);
    await logActivity(userId, `Deleted client profile: ${clientName}`, ActivityType.CLIENT);
  } catch (error) {
    handleFirestoreError(error, OperationType.DELETE, path);
    throw error;
  }
}

// ==========================================
// 3. Project Management
// ==========================================
export async function getProjects(userId: string): Promise<Project[]> {
  const path = 'projects';
  try {
    const ref = collection(db, 'projects');
    const q = query(ref, where('userId', '==', userId), orderBy('createdAt', 'desc'));
    const snap = await getDocs(q);
    const items: Project[] = [];
    snap.forEach((doc) => {
      items.push({ id: doc.id, ...doc.data() } as Project);
    });
    return items;
  } catch (error) {
    handleFirestoreError(error, OperationType.LIST, path);
    return [];
  }
}

export async function addProject(userId: string, project: Omit<Project, 'id' | 'userId' | 'createdAt' | 'updatedAt'>): Promise<Project> {
  const path = 'projects';
  try {
    const ref = collection(db, 'projects');
    const newDocRef = doc(ref);
    const data: Project = {
      id: newDocRef.id,
      userId,
      ...project,
      createdAt: serverTimestamp(),
      updatedAt: serverTimestamp()
    };
    await setDoc(newDocRef, data);
    await logActivity(userId, `Created project: ${project.projectName}`, ActivityType.PROJECT);
    return data;
  } catch (error) {
    handleFirestoreError(error, OperationType.CREATE, path);
    throw error;
  }
}

export async function updateProject(userId: string, projectId: string, project: Partial<Omit<Project, 'id' | 'userId' | 'createdAt' | 'updatedAt'>>): Promise<void> {
  const path = `projects/${projectId}`;
  try {
    const docRef = doc(db, 'projects', projectId);
    await updateDoc(docRef, {
      ...project,
      updatedAt: serverTimestamp()
    });
    await logActivity(userId, `Updated status or details of project: ${project.projectName || 'record ID ' + projectId}`, ActivityType.PROJECT);
  } catch (error) {
    handleFirestoreError(error, OperationType.UPDATE, path);
    throw error;
  }
}

export async function deleteProject(userId: string, projectId: string, projectName: string): Promise<void> {
  const path = `projects/${projectId}`;
  try {
    const docRef = doc(db, 'projects', projectId);
    await deleteDoc(docRef);
    await logActivity(userId, `Deleted project: ${projectName}`, ActivityType.PROJECT);
  } catch (error) {
    handleFirestoreError(error, OperationType.DELETE, path);
    throw error;
  }
}

// ==========================================
// 4. Invoice Generator
// ==========================================
export async function getInvoices(userId: string): Promise<Invoice[]> {
  const path = 'invoices';
  try {
    const ref = collection(db, 'invoices');
    const q = query(ref, where('userId', '==', userId), orderBy('createdAt', 'desc'));
    const snap = await getDocs(q);
    const items: Invoice[] = [];
    snap.forEach((doc) => {
      items.push({ id: doc.id, ...doc.data() } as Invoice);
    });
    return items;
  } catch (error) {
    handleFirestoreError(error, OperationType.LIST, path);
    return [];
  }
}

export async function generateNextInvoiceNumber(userId: string): Promise<string> {
  try {
    const invoices = await getInvoices(userId);
    if (invoices.length === 0) return 'INV-1001';
    
    // Attempt parsing list to extract maximum serial
    let maxNum = 1000;
    invoices.forEach(inv => {
      const match = inv.invoiceNumber.match(/INV-(\d+)/i);
      if (match && match[1]) {
        const num = parseInt(match[1], 10);
        if (num > maxNum) maxNum = num;
      }
    });
    return `INV-${maxNum + 1}`;
  } catch {
    return `INV-${Date.now().toString().slice(-4)}`;
  }
}

export async function addInvoice(userId: string, invoice: Omit<Invoice, 'id' | 'userId' | 'createdAt' | 'updatedAt'>): Promise<Invoice> {
  const path = 'invoices';
  try {
    const ref = collection(db, 'invoices');
    const newDocRef = doc(ref);
    const data: Invoice = {
      id: newDocRef.id,
      userId,
      ...invoice,
      createdAt: serverTimestamp(),
      updatedAt: serverTimestamp()
    };
    await setDoc(newDocRef, data);
    
    // Automatically register a mirror outstandingPayment entry in payments tracker
    await addPayment(userId, {
      invoiceId: newDocRef.id,
      invoiceNumber: invoice.invoiceNumber,
      amount: invoice.totalAmount,
      paymentDate: invoice.dueDate,
      paymentStatus: invoice.status // Matches the initial unpaid status
    });

    await logActivity(userId, `Generated Invoice: ${invoice.invoiceNumber} for ${invoice.clientName}`, ActivityType.INVOICE);

    // Trigger transactional email notification asynchronously (non-blocking)
    try {
      await triggerInvoiceCreatedNotification(userId, data);
    } catch (e) {
      console.warn("Non-blocking email trigger failed:", e);
    }

    return data;
  } catch (error) {
    handleFirestoreError(error, OperationType.CREATE, path);
    throw error;
  }
}

export async function updateInvoiceStatus(userId: string, invoiceId: string, status: PaymentStatus): Promise<void> {
  const path = `invoices/${invoiceId}`;
  try {
    const docRef = doc(db, 'invoices', invoiceId);
    await updateDoc(docRef, {
      status,
      updatedAt: serverTimestamp()
    });

    // Mirror to matching payment entry if exists
    const payRef = collection(db, 'payments');
    const q = query(payRef, where('invoiceId', '==', invoiceId), where('userId', '==', userId));
    const snap = await getDocs(q);
    snap.forEach(async (pDoc) => {
      const pRef = doc(db, 'payments', pDoc.id);
      await updateDoc(pRef, {
        paymentStatus: status,
        updatedAt: serverTimestamp()
      });
    });

    await logActivity(userId, `Marked Invoice of ID ${invoiceId} as ${status}`, ActivityType.INVOICE);

    // Trigger transactional receipt/confirmation if paid settled
    if (status === PaymentStatus.PAID) {
      try {
        const invSnap = await getDoc(docRef);
        if (invSnap.exists()) {
          const invData = invSnap.data() as Invoice;
          await triggerPaymentReceivedNotification(
            userId,
            invoiceId,
            invData.invoiceNumber,
            invData.totalAmount,
            invData.clientId
          );
        }
      } catch (e) {
        console.warn("Non-blocking payment confirmation email failed:", e);
      }
    }
  } catch (error) {
    handleFirestoreError(error, OperationType.UPDATE, path);
    throw error;
  }
}

export async function deleteInvoice(userId: string, invoiceId: string, invoiceNumber: string): Promise<void> {
  const path = `invoices/${invoiceId}`;
  try {
    const docRef = doc(db, 'invoices', invoiceId);
    await deleteDoc(docRef);

    // Delete associated historical payment logger if any
    const payRef = collection(db, 'payments');
    const q = query(payRef, where('invoiceId', '==', invoiceId), where('userId', '==', userId));
    const snap = await getDocs(q);
    snap.forEach(async (pDoc) => {
      await deleteDoc(doc(db, 'payments', pDoc.id));
    });

    await logActivity(userId, `Deleted invoice: ${invoiceNumber}`, ActivityType.INVOICE);
  } catch (error) {
    handleFirestoreError(error, OperationType.DELETE, path);
    throw error;
  }
}

// ==========================================
// 5. Payment Tracker
// ==========================================
export async function getPayments(userId: string): Promise<Payment[]> {
  const path = 'payments';
  try {
    const ref = collection(db, 'payments');
    const q = query(ref, where('userId', '==', userId), orderBy('paymentDate', 'desc'));
    const snap = await getDocs(q);
    const items: Payment[] = [];
    snap.forEach((doc) => {
      items.push({ id: doc.id, ...doc.data() } as Payment);
    });
    return items;
  } catch (error) {
    handleFirestoreError(error, OperationType.LIST, path);
    return [];
  }
}

export async function addPayment(userId: string, payment: Omit<Payment, 'id' | 'userId' | 'createdAt' | 'updatedAt'>): Promise<Payment> {
  const path = 'payments';
  try {
    const ref = collection(db, 'payments');
    // Ensure no duplicate payment items for identical invoice ids
    const q = query(ref, where('invoiceId', '==', payment.invoiceId), where('userId', '==', userId));
    const snap = await getDocs(q);
    if (!snap.empty) {
      // Return the matches or update them
      const item = snap.docs[0];
      return { id: item.id, ...item.data() } as Payment;
    }

    const newDocRef = doc(ref);
    const data: Payment = {
      id: newDocRef.id,
      userId,
      ...payment,
      createdAt: serverTimestamp(),
      updatedAt: serverTimestamp()
    };
    await setDoc(newDocRef, data);
    return data;
  } catch (error) {
    handleFirestoreError(error, OperationType.CREATE, path);
    throw error;
  }
}

export async function updatePaymentStatus(userId: string, paymentId: string, invoiceId: string, status: PaymentStatus): Promise<void> {
  const path = `payments/${paymentId}`;
  try {
    const docRef = doc(db, 'payments', paymentId);
    await updateDoc(docRef, {
      paymentStatus: status,
      paymentDate: new Date().toISOString().split('T')[0],
      updatedAt: serverTimestamp()
    });

    // Also sync back status of matching Invoice record
    const invRef = doc(db, 'invoices', invoiceId);
    await updateDoc(invRef, {
      status,
      updatedAt: serverTimestamp()
    });

    await logActivity(userId, `Updated payment ledger: Invoice ID ${invoiceId} is now ${status}`, ActivityType.PAYMENT);

    // Trigger transactional receipt confirmation if paid settled
    if (status === PaymentStatus.PAID) {
      try {
        const invSnap = await getDoc(invRef);
        if (invSnap.exists()) {
          const invData = invSnap.data() as Invoice;
          await triggerPaymentReceivedNotification(
            userId,
            invoiceId,
            invData.invoiceNumber,
            invData.totalAmount,
            invData.clientId
          );
        }
      } catch (e) {
        console.warn("Non-blocking payment receipt confirmation email failed:", e);
      }
    }
  } catch (error) {
    handleFirestoreError(error, OperationType.UPDATE, path);
    throw error;
  }
}

// ==========================================
// 6. Recent Activities Logs
// ==========================================
export async function getActivities(userId: string): Promise<Activity[]> {
  const path = 'activities';
  try {
    const ref = collection(db, 'activities');
    const q = query(ref, where('userId', '==', userId), orderBy('createdAt', 'desc'), limit(25));
    const snap = await getDocs(q);
    const items: Activity[] = [];
    snap.forEach((doc) => {
      items.push({ id: doc.id, ...doc.data() } as Activity);
    });
    return items;
  } catch (error) {
    handleFirestoreError(error, OperationType.LIST, path);
    return [];
  }
}

export async function logActivity(userId: string, description: string, type: ActivityType): Promise<void> {
  const path = 'activities';
  try {
    const ref = collection(db, 'activities');
    const newDocRef = doc(ref);
    const activityData: Activity = {
      id: newDocRef.id,
      userId,
      description,
      type,
      createdAt: serverTimestamp()
    };
    await setDoc(newDocRef, activityData);
  } catch (error) {
    // Fail silently in logger to avoid breaking the core business cycle, but print to trace logs
    console.warn(`Activity log write failed: ${error}`);
  }
}

// ==========================================
// 7. Admin and Subscription Management
// ==========================================
export async function getAdminProfile(adminId: string): Promise<AdminProfile | null> {
  const path = `admins/${adminId}`;
  try {
    const docRef = doc(db, 'admins', adminId);
    const docSnap = await getDoc(docRef);
    if (docSnap.exists()) {
      return docSnap.data() as AdminProfile;
    }
    return null;
  } catch (error) {
    handleFirestoreError(error, OperationType.GET, path);
    return null;
  }
}

export async function createAdminProfile(adminId: string, name: string, email: string): Promise<AdminProfile> {
  const path = `admins/${adminId}`;
  try {
    const docRef = doc(db, 'admins', adminId);
    const profileData: AdminProfile = {
      adminId,
      name,
      email,
      role: 'admin',
      status: 'active',
      createdAt: serverTimestamp()
    };
    await setDoc(docRef, profileData);
    return profileData;
  } catch (error) {
    handleFirestoreError(error, OperationType.CREATE, path);
    throw error;
  }
}

export async function getAllUsers(): Promise<UserProfile[]> {
  const path = 'users';
  try {
    const ref = collection(db, 'users');
    const q = query(ref, orderBy('createdAt', 'desc'));
    const snap = await getDocs(q);
    const users: UserProfile[] = [];
    snap.forEach((doc) => {
      users.push(doc.data() as UserProfile);
    });
    return users;
  } catch (error) {
    handleFirestoreError(error, OperationType.LIST, path);
    return [];
  }
}

export async function updateUserStatus(userId: string, status: 'active' | 'suspended'): Promise<void> {
  const path = `users/${userId}`;
  try {
    const docRef = doc(db, 'users', userId);
    await updateDoc(docRef, {
      status
    });
  } catch (error) {
    handleFirestoreError(error, OperationType.UPDATE, path);
    throw error;
  }
}

export async function deleteUser(userId: string): Promise<void> {
  const path = `users/${userId}`;
  try {
    const docRef = doc(db, 'users', userId);
    await deleteDoc(docRef);
  } catch (error) {
    handleFirestoreError(error, OperationType.DELETE, path);
    throw error;
  }
}

export async function getAllProjects(): Promise<Project[]> {
  const path = 'projects';
  try {
    const ref = collection(db, 'projects');
    const snap = await getDocs(ref);
    const items: Project[] = [];
    snap.forEach((doc) => {
      items.push({ id: doc.id, ...doc.data() } as Project);
    });
    return items;
  } catch (error) {
    handleFirestoreError(error, OperationType.LIST, path);
    return [];
  }
}

export async function getAllInvoices(): Promise<Invoice[]> {
  const path = 'invoices';
  try {
    const ref = collection(db, 'invoices');
    const snap = await getDocs(ref);
    const items: Invoice[] = [];
    snap.forEach((doc) => {
      items.push({ id: doc.id, ...doc.data() } as Invoice);
    });
    return items;
  } catch (error) {
    handleFirestoreError(error, OperationType.LIST, path);
    return [];
  }
}

export async function getAllPayments(): Promise<Payment[]> {
  const path = 'payments';
  try {
    const ref = collection(db, 'payments');
    const snap = await getDocs(ref);
    const items: Payment[] = [];
    snap.forEach((doc) => {
      items.push({ id: doc.id, ...doc.data() } as Payment);
    });
    return items;
  } catch (error) {
    handleFirestoreError(error, OperationType.LIST, path);
    return [];
  }
}

export async function getSubscriptions(): Promise<Subscription[]> {
  const path = 'subscriptions';
  try {
    const ref = collection(db, 'subscriptions');
    const snap = await getDocs(ref);
    const items: Subscription[] = [];
    snap.forEach((doc) => {
      items.push({ id: doc.id, ...doc.data() } as Subscription);
    });
    return items;
  } catch (error) {
    handleFirestoreError(error, OperationType.LIST, path);
    return [];
  }
}

export async function addSubscription(sub: Omit<Subscription, 'id' | 'createdAt' | 'updatedAt'>): Promise<Subscription> {
  const path = 'subscriptions';
  try {
    const ref = collection(db, 'subscriptions');
    const newDocRef = doc(ref);
    const data: Subscription = {
      id: newDocRef.id,
      ...sub,
      createdAt: serverTimestamp(),
      updatedAt: serverTimestamp()
    };
    await setDoc(newDocRef, data);
    return data;
  } catch (error) {
    handleFirestoreError(error, OperationType.CREATE, path);
    throw error;
  }
}

export async function updateSubscription(id: string, updates: Partial<Omit<Subscription, 'id' | 'createdAt' | 'updatedAt'>>): Promise<void> {
  const path = `subscriptions/${id}`;
  try {
    const docRef = doc(db, 'subscriptions', id);
    await updateDoc(docRef, {
      ...updates,
      updatedAt: serverTimestamp()
    });
  } catch (error) {
    handleFirestoreError(error, OperationType.UPDATE, path);
    throw error;
  }
}

export async function deleteSubscription(id: string): Promise<void> {
  const path = `subscriptions/${id}`;
  try {
    const docRef = doc(db, 'subscriptions', id);
    await deleteDoc(docRef);
  } catch (error) {
    handleFirestoreError(error, OperationType.DELETE, path);
    throw error;
  }
}

export async function getAllActivities(): Promise<Activity[]> {
  const path = 'activities';
  try {
    const ref = collection(db, 'activities');
    const q = query(ref, orderBy('createdAt', 'desc'), limit(100));
    const snap = await getDocs(q);
    const items: Activity[] = [];
    snap.forEach((doc) => {
      items.push({ id: doc.id, ...doc.data() } as Activity);
    });
    return items;
  } catch (error) {
    handleFirestoreError(error, OperationType.LIST, path);
    return [];
  }
}

export async function createNewAdmin(adminId: string, email: string, name: string): Promise<void> {
  const path = `admins/${adminId}`;
  try {
    const docRef = doc(db, 'admins', adminId);
    await setDoc(docRef, {
      adminId,
      name,
      email,
      role: 'admin',
      status: 'active',
      createdAt: serverTimestamp()
    });
  } catch (error) {
    handleFirestoreError(error, OperationType.CREATE, path);
    throw error;
  }
}

