export enum ClientStatus {
  ACTIVE = 'Active',
  INACTIVE = 'Inactive',
  LEAD = 'Lead'
}

export enum ProjectStatus {
  PENDING = 'Pending',
  IN_PROGRESS = 'In Progress',
  COMPLETED = 'Completed',
  CANCELLED = 'Cancelled'
}

export enum PaymentStatus {
  PAID = 'Paid',
  UNPAID = 'Unpaid',
  OVERDUE = 'Overdue'
}

export enum ActivityType {
  AUTH = 'auth',
  CLIENT = 'client',
  PROJECT = 'project',
  INVOICE = 'invoice',
  PAYMENT = 'payment'
}

export interface UserProfile {
  userId: string;
  name: string;
  email: string;
  profilePhoto?: string;
  companyName?: string;
  freelancerCategory?: string;
  country?: string;
  role: 'user';
  status: 'active' | 'suspended';
  createdAt: any; // Firestore Timestamp
}

export interface AdminProfile {
  adminId: string;
  name: string;
  email: string;
  role: 'admin';
  status: 'active';
  createdAt: any;
}

export interface Subscription {
  id: string;
  userId: string;
  userEmail: string;
  plan: 'Starter' | 'Grower' | 'Professional' | 'Enterprise';
  price: number;
  billingCycle: 'monthly' | 'yearly';
  status: 'active' | 'cancelled' | 'expired' | 'trialing';
  createdAt: any;
  updatedAt: any;
}

export interface Client {
  id: string;
  userId: string;
  clientName: string;
  email: string;
  phone: string;
  company: string;
  country: string;
  notes: string;
  status: ClientStatus;
  createdAt: any;
  updatedAt: any;
}

export interface Project {
  id: string;
  userId: string;
  clientId: string;
  projectName: string;
  description: string;
  budget: number;
  deadline: string;
  status: ProjectStatus;
  createdAt: any;
  updatedAt: any;
}

export interface InvoiceItem {
  id: string;
  name: string;
  quantity: number;
  price: number;
  total: number;
}

export interface Invoice {
  id: string;
  invoiceNumber: string;
  userId: string;
  clientId: string;
  clientName: string;
  invoiceDate: string;
  dueDate: string;
  items: InvoiceItem[];
  totalAmount: number;
  status: PaymentStatus;
  createdAt: any;
  updatedAt: any;
}

export interface Payment {
  id: string;
  userId: string;
  invoiceId: string;
  invoiceNumber: string;
  amount: number;
  paymentDate: string;
  paymentStatus: PaymentStatus;
  createdAt: any;
  updatedAt: any;
}

export interface Activity {
  id: string;
  userId: string;
  description: string;
  type: ActivityType;
  createdAt: any;
}

export interface NotificationEmail {
  id: string;
  userId: string;
  recipientEmail: string;
  recipientName: string;
  subject: string;
  body: string;
  triggerEvent: 'invoice_created' | 'payment_received' | 'payment_reminder' | 'deadline_approaching';
  status: 'sent' | 'failed' | 'simulated';
  sentAt: any; // Firestore ServerTimestamp or ISO string
  referenceId?: string; // invoiceId or projectId or paymentId
  referenceNumber?: string; // e.g. INV-1001 or "Client Website App Redesign"
}
