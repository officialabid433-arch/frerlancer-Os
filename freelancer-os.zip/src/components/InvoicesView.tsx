import React, { useState, useEffect } from 'react';
import { 
  Plus, 
  Trash2, 
  Trash,
  FileText, 
  ExternalLink, 
  ArrowUpRight, 
  X, 
  CheckCircle2, 
  XCircle, 
  Clock, 
  Loader2, 
  DollarSign, 
  Calculator, 
  Printer, 
  Mail, 
  Receipt 
} from 'lucide-react';
import { Invoice, Client, InvoiceItem, PaymentStatus } from '../types';
import { getInvoices, addInvoice, updateInvoiceStatus, deleteInvoice, getClients, generateNextInvoiceNumber } from '../services/db';
import { useAuth } from '../contexts/AuthContext';

export default function InvoicesView() {
  const { user, userProfile } = useAuth();
  const [invoices, setInvoices] = useState<Invoice[]>([]);
  const [clients, setClients] = useState<Client[]>([]);
  const [loading, setLoading] = useState(true);

  // Invoice creation form states
  const [isCreateModalOpen, setIsCreateModalOpen] = useState(false);
  const [formClientId, setFormClientId] = useState('');
  const [formDueDate, setFormDueDate] = useState('');
  const [formItems, setFormItems] = useState<Omit<InvoiceItem, 'id'>[]>([{ name: '', quantity: 1, price: 0 }]);
  const [savingInvoice, setSavingInvoice] = useState(false);

  // PDF Preview states
  const [selectedInvoice, setSelectedInvoice] = useState<Invoice | null>(null);
  const [isPdfModalOpen, setIsPdfModalOpen] = useState(false);

  const loadData = async () => {
    if (!user) return;
    try {
      setLoading(true);
      const [invList, clientList] = await Promise.all([
        getInvoices(user.uid),
        getClients(user.uid)
      ]);
      setInvoices(invList);
      setClients(clientList);
      if (clientList.length > 0) {
        setFormClientId(clientList[0].id);
      }
    } catch (err) {
      console.error(err);
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    loadData();
  }, [user]);

  // Handle opening modal
  const handleOpenCreate = () => {
    if (clients.length === 0) {
      alert('You must add at least one client before generating an invoice.');
      return;
    }
    setFormClientId(clients[0].id);
    setFormDueDate('');
    setFormItems([{ name: '', quantity: 1, price: 0 }]);
    setIsCreateModalOpen(true);
  };

  // Add line item row
  const addLineItem = () => {
    setFormItems([...formItems, { name: '', quantity: 1, price: 0 }]);
  };

  // Remove line item row
  const removeLineItem = (index: number) => {
    if (formItems.length === 1) return;
    const update = [...formItems];
    update.splice(index, 1);
    setFormItems(update);
  };

  // Update line item details
  const updateLineItem = (index: number, key: keyof Omit<InvoiceItem, 'id'>, value: any) => {
    const update = [...formItems];
    if (key === 'quantity') {
      update[index].quantity = Number(value);
    } else if (key === 'price') {
      update[index].price = Number(value);
    } else if (key === 'name') {
      update[index].name = String(value);
    }
    setFormItems(update);
  };

  // Calculator helper
  const calculateFormTotal = () => {
    return formItems.reduce((acc, curr) => acc + (curr.quantity * curr.price), 0);
  };

  // Save invoice to database
  const handleSaveInvoice = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!user) return;
    if (!formClientId || !formDueDate) {
      alert('Client assignment and payment due dates are required properties.');
      return;
    }

    // Verify all line items are populated
    const invalidItem = formItems.some(it => !it.name.trim() || it.price < 0 || it.quantity <= 0);
    if (invalidItem) {
      alert('Please fill out all line item descriptions with valid prices and positive quantities.');
      return;
    }

    try {
      setSavingInvoice(true);
      
      const clientRecord = clients.find(c => c.id === formClientId);
      const clientName = clientRecord ? clientRecord.clientName : 'Client';
      
      // Auto generate invoice serial number sequence
      const nextInvNum = await generateNextInvoiceNumber(user.uid);
      const totalAmount = calculateFormTotal();

      // Transform formItems adding unique IDs
      const mappedItems: InvoiceItem[] = formItems.map((item, idx) => ({
        id: `item-${Date.now()}-${idx}`,
        name: item.name,
        quantity: item.quantity,
        price: item.price,
        total: item.quantity * item.price
      }));

      await addInvoice(user.uid, {
        invoiceNumber: nextInvNum,
        clientId: formClientId,
        clientName,
        invoiceDate: new Date().toISOString().split('T')[0],
        dueDate: formDueDate,
        items: mappedItems,
        totalAmount,
        status: PaymentStatus.UNPAID // Initially unpaid
      });

      setIsCreateModalOpen(false);
      await loadData();
    } catch (err) {
      console.error(err);
      alert('Error recording invoice ledger: ' + (err instanceof Error ? err.message : String(err)));
    } finally {
      setSavingInvoice(false);
    }
  };

  // Change Status (Mark Paid / Unpaid)
  const handleToggleInvoiceStatus = async (invoiceId: string, currentStatus: PaymentStatus) => {
    if (!user) return;
    const nextStatus = currentStatus === PaymentStatus.PAID ? PaymentStatus.UNPAID : PaymentStatus.PAID;
    try {
      await updateInvoiceStatus(user.uid, invoiceId, nextStatus);
      await loadData();
    } catch (err) {
      console.error(err);
      alert('Failed to update invoice status.');
    }
  };

  // Delete invoice
  const handleDeleteInvoice = async (id: string, num: string) => {
    if (!user) return;
    if (!confirm(`Are you sure you want to permanently delete invoice ${num}?`)) return;
    try {
      await deleteInvoice(user.uid, id, num);
      await loadData();
    } catch (err) {
      console.error(err);
      alert('Failed to delete invoice.');
    }
  };

  // Print/Download PDF Trigger
  const handleOpenPdf = (invoice: Invoice) => {
    setSelectedInvoice(invoice);
    setIsPdfModalOpen(true);
  };

  const handlePrint = () => {
    window.print();
  };

  // Calculations for KPI counters
  const totalRevenue = invoices.reduce((sum, inv) => sum + inv.totalAmount, 0);
  const paidRevenue = invoices.filter(i => i.status === PaymentStatus.PAID).reduce((sum, inv) => sum + inv.totalAmount, 0);
  const unpaidRevenue = invoices.filter(i => i.status !== PaymentStatus.PAID).reduce((sum, inv) => sum + inv.totalAmount, 0);

  return (
    <div className="space-y-6" id="invoices-view-container">
      {/* Header */}
      <div className="flex flex-col md:flex-row md:items-center md:justify-between gap-4" id="invoices-header">
        <div>
          <h2 className="text-2xl font-bold tracking-tight text-gray-950" id="invoices-title">Invoice Generator</h2>
          <p className="text-sm text-gray-500 mt-1" id="invoices-desc">Create formal dynamic billings, track outstanding balances, and export high-fidelity customer receipts.</p>
        </div>
        <button
          onClick={handleOpenCreate}
          className="inline-flex items-center gap-2 justify-center px-4 py-2 bg-indigo-600 hover:bg-indigo-700 text-white rounded-lg text-sm font-medium transition cursor-pointer"
          id="btn-trigger-create-invoice"
        >
          <Plus className="w-4 h-4" />
          Create Invoice
        </button>
      </div>

      {/* Stats Cards */}
      <div className="grid grid-cols-1 sm:grid-cols-3 gap-4" id="invoices-kpis">
        <div className="bg-white p-4 rounded-xl border border-gray-100 flex items-center gap-4 shadow-xs" id="invoice-kpi-total">
          <div className="p-3 bg-indigo-50 text-indigo-600 rounded-lg">
            <Receipt className="w-5 h-5" />
          </div>
          <div>
            <p className="text-xs text-gray-500 font-medium font-sans">Total Billed</p>
            <h3 className="text-xl font-bold text-gray-900 mt-0.5">${totalRevenue.toLocaleString(undefined, { minimumFractionDigits: 2, maximumFractionDigits: 2 })}</h3>
          </div>
        </div>

        <div className="bg-white p-4 rounded-xl border border-gray-100 flex items-center gap-4 shadow-xs" id="invoice-kpi-paid">
          <div className="p-3 bg-emerald-50 text-emerald-600 rounded-lg">
            <CheckCircle2 className="w-5 h-5" />
          </div>
          <div>
            <p className="text-xs text-gray-500 font-medium font-sans">Paid Collected</p>
            <h3 className="text-xl font-bold text-gray-900 mt-0.5">${paidRevenue.toLocaleString(undefined, { minimumFractionDigits: 2, maximumFractionDigits: 2 })}</h3>
          </div>
        </div>

        <div className="bg-white p-4 rounded-xl border border-gray-100 flex items-center gap-4 shadow-xs" id="invoice-kpi-outstanding">
          <div className="p-3 bg-rose-50 text-rose-600 rounded-lg">
            <Clock className="w-5 h-5" />
          </div>
          <div>
            <p className="text-xs text-gray-500 font-medium font-sans">Outstanding Unpaid</p>
            <h3 className="text-xl font-bold text-gray-900 mt-0.5">${unpaidRevenue.toLocaleString(undefined, { minimumFractionDigits: 2, maximumFractionDigits: 2 })}</h3>
          </div>
        </div>
      </div>

      {/* Invoices List Display */}
      {loading ? (
        <div className="flex flex-col items-center justify-center p-12 bg-white rounded-xl border border-gray-100 shadow-xs" id="invoices-loading">
          <Loader2 className="w-8 h-8 text-indigo-600 animate-spin" />
          <p className="text-sm text-gray-500 mt-2">Retrieving invoices logs...</p>
        </div>
      ) : invoices.length === 0 ? (
        <div className="text-center p-12 bg-white rounded-xl border border-gray-100 shadow-xs" id="invoices-empty">
          <div className="w-12 h-12 bg-indigo-50 text-indigo-600 rounded-full flex items-center justify-center mx-auto mb-3">
            <FileText className="w-6 h-6" />
          </div>
          <p className="text-base font-semibold text-gray-900">No invoices drafted yet</p>
          <p className="text-sm text-gray-500 mt-1 max-w-sm mx-auto">
            Design professional multi-item billings. Instantly calculate VAT/pricing totals and print invoice document slips.
          </p>
          <button
            onClick={handleOpenCreate}
            className="mt-4 px-4 py-2 bg-indigo-600 hover:bg-indigo-700 text-white rounded-lg text-sm font-medium transition cursor-pointer"
            id="cta-add-first-invoice"
          >
            Draft First Invoice
          </button>
        </div>
      ) : (
        <div className="bg-white rounded-xl border border-gray-100 shadow-xs overflow-hidden" id="invoices-list-wrapper">
          <div className="overflow-x-auto text-sm text-gray-700">
            <table className="w-full text-left border-collapse" id="invoices-table">
              <thead>
                <tr className="bg-gray-50 border-b border-gray-100 font-semibold text-gray-650 text-xs">
                  <th className="p-4 px-6">Invoice Serial</th>
                  <th className="p-4">Assigned Client</th>
                  <th className="p-4">Emission Date</th>
                  <th className="p-4">Payment Due</th>
                  <th className="p-4">Billed Amount</th>
                  <th className="p-4 text-center">Status</th>
                  <th className="p-4 text-right px-6">Operations</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-gray-50">
                {invoices.map((inv) => (
                  <tr key={inv.id} className="hover:bg-gray-50/50 transition">
                    <td className="p-4 px-6 font-bold text-gray-900">{inv.invoiceNumber}</td>
                    <td className="p-4 font-medium text-gray-800">{inv.clientName}</td>
                    <td className="p-4 text-xs text-gray-500">{inv.invoiceDate}</td>
                    <td className="p-4 text-xs text-gray-500">{inv.dueDate}</td>
                    <td className="p-4 font-bold text-gray-900">${inv.totalAmount.toLocaleString(undefined, { minimumFractionDigits: 2 })}</td>
                    <td className="p-4 text-center">
                      <button
                        onClick={() => handleToggleInvoiceStatus(inv.id, inv.status)}
                        className={`inline-flex items-center gap-1.5 px-3 py-1 rounded-full text-2xs font-semibold uppercase tracking-wider cursor-pointer border ${
                          inv.status === PaymentStatus.PAID 
                            ? 'bg-emerald-55/10 text-emerald-700 border-emerald-55/20' 
                            : 'bg-rose-55/10 text-rose-700 border-rose-55/20'
                        }`}
                        title="Click to toggle payment status"
                        id={`btn-toggle-status-${inv.id}`}
                      >
                        {inv.status === PaymentStatus.PAID ? (
                          <>
                            <CheckCircle2 className="w-3.5 h-3.5 text-emerald-600" />
                            Paid
                          </>
                        ) : (
                          <>
                            <Clock className="w-3.5 h-3.5 text-rose-500 animate-pulse" />
                            Unpaid
                          </>
                        )}
                      </button>
                    </td>
                    <td className="p-4 text-right px-6 space-x-3.5">
                      <button
                        onClick={() => handleOpenPdf(inv)}
                        className="p-1 px-2.5 text-xs text-indigo-650 font-semibold hover:text-indigo-805 bg-indigo-50 border border-indigo-100 hover:border-indigo-200 rounded-md transition cursor-pointer inline-flex items-center gap-1"
                        id={`btn-export-${inv.id}`}
                      >
                        <ExternalLink className="w-3 h-3" />
                        Export / PDF
                      </button>
                      <button
                        onClick={() => handleDeleteInvoice(inv.id, inv.invoiceNumber)}
                        className="p-1 text-gray-400 hover:text-rose-600 transition cursor-pointer"
                        title="Delete invoice record"
                        id={`btn-del-inv-${inv.id}`}
                      >
                        <Trash className="w-4 h-4 inline" />
                      </button>
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </div>
      )}

      {/* Styled Large Form Modal for Invoice Creation */}
      {isCreateModalOpen && (
        <div className="fixed inset-0 bg-black/50 backdrop-blur-xs flex items-center justify-center z-50 p-4 animate-fade-in" id="invoice-create-overlay">
          <div className="bg-white w-full max-w-2xl rounded-2xl shadow-xl border border-gray-100 overflow-hidden flex flex-col animate-scale-up" id="invoice-create-content">
            {/* Header */}
            <div className="px-6 py-4 border-b border-gray-100 flex items-center justify-between bg-gray-50">
              <h3 className="text-base font-bold text-gray-900">Compose Business Invoice Layout</h3>
              <button
                onClick={() => setIsCreateModalOpen(false)}
                className="p-1.5 hover:bg-gray-200 text-gray-500 rounded-lg transition"
                id="btn-close-create-invoice"
              >
                <X className="w-4.5 h-4.5" />
              </button>
            </div>

            {/* Form */}
            <form onSubmit={handleSaveInvoice} className="p-6 space-y-5 overflow-y-auto max-h-[80vh]">
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                <div>
                  <label className="block text-xs font-semibold text-gray-750 mb-1">Target Account Client *</label>
                  <select
                    required
                    value={formClientId}
                    onChange={(e) => setFormClientId(e.target.value)}
                    className="w-full bg-white text-gray-905 border border-gray-200 rounded-lg px-3 py-2 text-sm outline-none focus:border-indigo-500 cursor-pointer"
                    id="invoice-form-client"
                  >
                    {clients.map(c => (
                      <option key={c.id} value={c.id}>{c.clientName} ({c.company || 'Private User'})</option>
                    ))}
                  </select>
                </div>

                <div>
                  <label className="block text-xs font-semibold text-gray-750 mb-1">Payment Settlement Due *</label>
                  <input
                    type="date"
                    required
                    value={formDueDate}
                    onChange={(e) => setFormDueDate(e.target.value)}
                    className="w-full bg-white text-gray-905 border border-gray-200 rounded-lg px-3 py-2 text-sm outline-none focus:border-indigo-500 cursor-pointer"
                    id="invoice-form-duedate"
                  />
                </div>
              </div>

              {/* Line Items Grid section */}
              <div className="space-y-3" id="invoice-line-items-section">
                <div className="flex items-center justify-between border-t border-gray-100 pt-3">
                  <span className="text-xs font-bold text-gray-900 flex items-center gap-1">
                    <Calculator className="w-4 h-4 text-indigo-500" />
                    Billable Line Items
                  </span>
                  <button
                    type="button"
                    onClick={addLineItem}
                    className="text-xs text-indigo-600 hover:text-indigo-800 font-bold inline-flex items-center gap-1 cursor-pointer"
                    id="btn-add-line-item"
                  >
                    <Plus className="w-3.5 h-3.5" />
                    + Add Item Row
                  </button>
                </div>

                <div className="space-y-3.5">
                  {formItems.map((item, idx) => (
                    <div key={idx} className="flex flex-col sm:flex-row items-center gap-3 bg-gray-50/50 p-3 rounded-xl border border-gray-200" id={`line-row-${idx}`}>
                      <div className="flex-1 w-full">
                        <label className="block sm:hidden text-3xs font-semibold text-gray-400 mb-0.5">Description</label>
                        <input
                          type="text"
                          required
                          placeholder="e.g. Core App Feature Redesigned Work"
                          value={item.name}
                          onChange={(e) => updateLineItem(idx, 'name', e.target.value)}
                          className="w-full bg-white text-gray-900 border border-gray-200 rounded-lg px-3 py-1.5 text-xs outline-none focus:border-indigo-500"
                          id={`item-name-${idx}`}
                        />
                      </div>

                      <div className="w-full sm:w-24 shrink-0">
                        <label className="block sm:hidden text-3xs font-semibold text-gray-400 mb-0.5 font-sans">QTY</label>
                        <input
                          type="number"
                          required
                          min={1}
                          placeholder="qty"
                          value={item.quantity}
                          onChange={(e) => updateLineItem(idx, 'quantity', e.target.value)}
                          className="w-full bg-white text-gray-900 border border-gray-200 rounded-lg px-3 py-1.5 text-xs outline-none focus:border-indigo-500 text-center"
                          id={`item-qty-${idx}`}
                        />
                      </div>

                      <div className="w-full sm:w-32 shrink-0">
                        <label className="block sm:hidden text-3xs font-semibold text-gray-400 mb-0.5">Price ($)</label>
                        <input
                          type="number"
                          required
                          min={0}
                          placeholder="Price"
                          value={item.price}
                          onChange={(e) => updateLineItem(idx, 'price', e.target.value)}
                          className="w-full bg-white text-gray-900 border border-gray-200 rounded-lg px-3 py-1.5 text-xs outline-none focus:border-indigo-500 text-right"
                          id={`item-price-${idx}`}
                        />
                      </div>

                      <div className="flex items-center justify-between sm:justify-start w-full sm:w-auto gap-4 pt-2 sm:pt-0 shrink-0">
                        <span className="text-xs font-bold text-gray-900 sm:w-16 text-right">
                          ${(item.quantity * item.price).toLocaleString(undefined, { minimumFractionDigits: 2 })}
                        </span>
                        <button
                          type="button"
                          disabled={formItems.length === 1}
                          onClick={() => removeLineItem(idx)}
                          className="text-gray-400 hover:text-rose-600 transition rounded-lg p-1.5 hover:bg-rose-50 disabled:opacity-30 cursor-pointer"
                          id={`btn-remove-line-${idx}`}
                        >
                          <Trash2 className="w-4 h-4" />
                        </button>
                      </div>
                    </div>
                  ))}
                </div>
              </div>

              {/* Summary Bottom Column */}
              <div className="bg-indigo-55/5 p-4 rounded-xl border border-indigo-55/10 flex flex-col justify-end items-end text-sm space-y-1.5 mt-4" id="invoice-calculators-summary">
                <div className="flex items-center gap-8 justify-between w-full sm:w-72">
                  <span className="text-gray-500 font-sans">Line Items Subtotal:</span>
                  <span className="font-medium text-gray-800">${calculateFormTotal().toLocaleString(undefined, { minimumFractionDigits: 2 })}</span>
                </div>
                <div className="flex items-center gap-8 justify-between w-full sm:w-72">
                  <span className="text-gray-500 font-sans">Standard Service VAT Fee (0%):</span>
                  <span className="font-medium text-gray-800">$0.00</span>
                </div>
                <div className="flex items-center gap-8 justify-between w-full sm:w-72 border-t border-indigo-100/50 pt-2 font-bold text-indigo-950">
                  <span className="text-sm">Invoice Grand Total:</span>
                  <span className="text-base">${calculateFormTotal().toLocaleString(undefined, { minimumFractionDigits: 2 })}</span>
                </div>
              </div>

              {/* Operations row */}
              <div className="pt-4 border-t border-gray-100 flex items-center justify-end gap-3">
                <button
                  type="button"
                  onClick={() => setIsCreateModalOpen(false)}
                  className="px-4 py-2 text-sm font-semibold text-gray-700 hover:bg-gray-150 rounded-lg border border-gray-200 transition cursor-pointer"
                  id="btn-close-invoice"
                >
                  Cancel
                </button>
                <button
                  type="submit"
                  disabled={savingInvoice}
                  className="px-4 py-2 bg-indigo-600 hover:bg-indigo-700 text-white rounded-lg text-sm font-semibold transition inline-flex items-center gap-1 cursor-pointer disabled:opacity-50"
                  id="btn-save-invoice"
                >
                  {savingInvoice && <Loader2 className="w-3.5 h-3.5 animate-spin" />}
                  Generate Slip
                </button>
              </div>
            </form>
          </div>
        </div>
      )}

      {/* Styled PDF/Receipt Print Modal Layout enabling PDF printing preview */}
      {isPdfModalOpen && selectedInvoice && (
        <div className="fixed inset-0 bg-black/60 backdrop-blur-xs flex items-center justify-center z-50 p-4 font-sans animate-fade-in" id="invoice-print-overlay">
          <div className="bg-white w-full max-w-3xl rounded-2xl shadow-2xl border border-gray-200 overflow-hidden flex flex-col max-h-[90vh] animate-scale-up" id="invoice-print-content">
            {/* Control header - hidden on standard printed medium */}
            <div className="px-6 py-4 border-b border-gray-200 flex items-center justify-between bg-gray-50 print:hidden">
              <span className="text-xs font-bold text-gray-650 flex items-center gap-1">
                <Printer className="w-4.5 h-4.5 text-indigo-600" />
                Receipt PDF Exporter
              </span>
              <div className="flex items-center gap-3">
                <button
                  onClick={handlePrint}
                  className="px-3.5 py-1.5 bg-indigo-600 hover:bg-indigo-700 text-white text-xs font-semibold rounded-lg inline-flex items-center gap-1.5 cursor-pointer shadow-xs transition"
                  id="btn-print-trigger"
                >
                  <Printer className="w-3.5 h-3.5" />
                  Print / Save PDF
                </button>
                <button
                  onClick={() => setIsPdfModalOpen(false)}
                  className="p-1.5 hover:bg-gray-200 text-gray-500 rounded-lg transition cursor-pointer"
                  id="btn-close-print-modal"
                >
                  <X className="w-4 h-4" />
                </button>
              </div>
            </div>

            {/* Print canvas */}
            <div className="p-8 sm:p-12 overflow-y-auto flex-1 font-sans text-gray-700 bg-white leading-relaxed print:p-0" id="print-receipt-document">
              {/* Top Row Grid */}
              <div className="flex flex-col sm:flex-row justify-between items-start gap-6 border-b border-gray-100 pb-8">
                <div>
                  <h1 className="text-2xl font-black text-indigo-700 tracking-tight select-none">FREELANCER OS</h1>
                  <p className="text-xs text-gray-400 mt-1 uppercase tracking-widest font-mono">Dynamic Billing slip</p>
                  <div className="mt-4 text-xs text-gray-500 space-y-0.5">
                    <p className="font-bold text-gray-800">{userProfile?.name || 'Freelance Service'}</p>
                    {userProfile?.companyName && <p>{userProfile.companyName}</p>}
                    <p>{userProfile?.email}</p>
                    {userProfile?.country && <p>{userProfile.country}</p>}
                  </div>
                </div>

                <div className="text-left sm:text-right text-xs space-y-1 bg-gray-50 p-4 rounded-xl border border-gray-100 sm:bg-transparent sm:border-0 sm:p-0">
                  <h3 className="text-lg font-black text-gray-900 tracking-tight">{selectedInvoice.invoiceNumber}</h3>
                  <p className="text-gray-500 mt-2">Emission Date: <span className="font-bold text-gray-700">{selectedInvoice.invoiceDate}</span></p>
                  <p className="text-gray-500">Payment Due: <span className="font-bold text-gray-700">{selectedInvoice.dueDate}</span></p>
                  <p className="text-gray-550 pt-2 font-semibold">Ledger Status: <span className="uppercase text-indigo-600 font-bold">{selectedInvoice.status}</span></p>
                </div>
              </div>

              {/* Client specifications mapping */}
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-6 py-8 border-b border-gray-100">
                <div className="space-y-1.5 text-xs text-gray-500">
                  <p className="text-3xs uppercase text-gray-400 tracking-wider font-bold">Invoiced To:</p>
                  <p className="font-bold text-gray-800 text-sm">{selectedInvoice.clientName}</p>
                  {clients.find(c => c.id === selectedInvoice.clientId)?.company && (
                    <p>{clients.find(c => c.id === selectedInvoice.clientId)?.company}</p>
                  )}
                  {clients.find(c => c.id === selectedInvoice.clientId)?.email && (
                    <p>{clients.find(c => c.id === selectedInvoice.clientId)?.email}</p>
                  )}
                </div>

                <div className="space-y-1.5 text-left sm:text-right text-xs text-gray-500">
                  <p className="text-3xs uppercase text-gray-400 tracking-wider font-bold">Ledger Entity Profile:</p>
                  <p className="font-medium text-gray-800">{userProfile?.freelancerCategory || 'General Service Vendor'}</p>
                  <p>Invoiced Client Ref: <span className="font-mono">{selectedInvoice.clientId.slice(0, 10)}</span></p>
                </div>
              </div>

              {/* Items table */}
              <div className="py-8" id="doc-receipt-items-table">
                <table className="w-full text-xs text-left border-collapse">
                  <thead>
                    <tr className="border-b border-gray-200 text-gray-400 uppercase tracking-wider font-extrabold font-mono text-3xs">
                      <th className="py-2 pb-3">Line item</th>
                      <th className="py-2 pb-3 text-center">Qty</th>
                      <th className="py-2 pb-3 text-right">Unit Price</th>
                      <th className="py-2 pb-3 text-right">Total</th>
                    </tr>
                  </thead>
                  <tbody className="divide-y divide-gray-100">
                    {selectedInvoice.items && selectedInvoice.items.map((item, idx) => (
                      <tr key={item.id || idx} className="text-gray-800">
                        <td className="py-3 font-semibold text-gray-900">{item.name}</td>
                        <td className="py-3 text-center text-gray-500">{item.quantity}</td>
                        <td className="py-3 text-right text-gray-500">${(item.price || 0).toLocaleString(undefined, { minimumFractionDigits: 2 })}</td>
                        <td className="py-3 text-right font-bold text-gray-950">${(item.total || item.quantity * item.price).toLocaleString(undefined, { minimumFractionDigits: 2 })}</td>
                      </tr>
                    ))}
                  </tbody>
                </table>
              </div>

              {/* Total rows */}
              <div className="flex flex-col items-end border-t border-gray-200 pt-6 space-y-1.5 text-xs text-gray-500" id="doc-receipt-calculator">
                <div className="flex items-center gap-8 justify-between w-full sm:w-64">
                  <span>Line items subtotal:</span>
                  <span className="font-semibold text-gray-900">${selectedInvoice.totalAmount.toLocaleString(undefined, { minimumFractionDigits: 2 })}</span>
                </div>
                <div className="flex items-center gap-8 justify-between w-full sm:w-64">
                  <span>Standard service VAT:</span>
                  <span>$0.00</span>
                </div>
                <div className="flex items-center gap-8 justify-between w-full sm:w-64 border-t border-gray-900 pt-2 text-sm font-black text-gray-950">
                  <span>Total Bill Gross Amount:</span>
                  <span>${selectedInvoice.totalAmount.toLocaleString(undefined, { minimumFractionDigits: 2 })} USD</span>
                </div>
              </div>

              {/* Small footprint */}
              <div className="mt-16 text-center text-2xs text-gray-400 border-t border-gray-50 pt-6 space-y-1 select-none">
                <p>Thank you for your continuous professional partnership!</p>
                <p className="font-mono text-3xs">Generated automatically via Freelancer OS Secure billing ledgers.</p>
              </div>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}
