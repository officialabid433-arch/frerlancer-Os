import React, { useState } from 'react';
import { 
  Sparkles, 
  Send, 
  FileText, 
  MessageSquare, 
  Receipt, 
  Compass, 
  Bot, 
  Loader2, 
  Copy, 
  Check, 
  Undo 
} from 'lucide-react';

export default function AiPredictiveView() {
  const [activeTab, setActiveTab] = useState<'proposal' | 'parser' | 'reply' | 'summary'>('proposal');
  const [loading, setLoading] = useState(false);
  const [copied, setCopied] = useState(false);

  // States for Proposal
  const [propClient, setPropClient] = useState('');
  const [propScope, setPropScope] = useState('');
  const [propBudget, setPropBudget] = useState('5000');
  const [proposalOutput, setProposalOutput] = useState('');

  // States for Invoicing Parser
  const [parserInput, setParserInput] = useState('');
  const [parsedInvoice, setParsedInvoice] = useState<any | null>(null);

  // States for Reply assistant
  const [replyTone, setReplyTone] = useState('Professional reminder');
  const [replyContext, setReplyContext] = useState('');
  const [replyOutput, setReplyOutput] = useState('');

  // States for Summary generator
  const [sumProjectName, setSumProjectName] = useState('');
  const [sumMilestones, setSumMilestones] = useState('');
  const [summaryOutput, setSummaryOutput] = useState('');

  // Universal helper for copy
  const handleCopy = (text: string) => {
    navigator.clipboard.writeText(text);
    setCopied(true);
    setTimeout(() => setCopied(false), 2000);
  };

  // Smart prompt generation triggers
  const handleWriteProposal = (e: React.FormEvent) => {
    e.preventDefault();
    if (!propClient.trim() || !propScope.trim()) {
      alert('Please fill out client name and project scope fields.');
      return;
    }
    setLoading(true);
    setTimeout(() => {
      setProposalOutput(`Subject: Professional Partnership Proposal: Creative Solutions for ${propClient}

Dear Board members at ${propClient},

Thank you for discussing your upcoming digital objectives. Following your shared scope parameter concerning "${propScope}", we have mapped out a tailored high-performance solution that aligns with your timeline, budget constraints ($${propBudget} USD), and business expansion targets.

Our proposed execution strategy consists of three key phases:
1. Technical Audit & Discovery Checklist (Week 1)
2. Interactive Deliverable Interface & UX Engineering Prototype (Week 2-3)
3. Testing, Security Verification & Fluid Production Handoff (Week 4)

Expected Outcomes:
- Accelerated delivery timelines mapped out transparently under Freelancer OS.
- Highly responsive product layouts optimizing conversions by up to 35%.
- Rigorous security and Firestore database structure compliance.

Total Proposed Budget: $${propBudget} USD
Payment Terms: 50% Upfront Retainer Fee / 50% Upon Secure Milestone Deployment.

We are fully prepared to launch this partnership on next-day terms. Please let us know if you would like to proceed with signing the general master service agreements.

Sincerely,
Freelancer OS Consulting Services`);
      setLoading(false);
    }, 1200);
  };

  const handleParseInvoiceText = (e: React.FormEvent) => {
    e.preventDefault();
    if (!parserInput.trim()) {
      alert('Please enter some plain text instructions.');
      return;
    }
    setLoading(true);
    setTimeout(() => {
      // Simulate clever AI regex extraction parsing!
      let client = 'Extracted Client Ltd';
      let hours = 20;
      let rate = 75;
      
      // Try extracting numerals
      const hourMatch = parserInput.match(/(\d+)\s*(hrs|hours)/i);
      if (hourMatch && hourMatch[1]) hours = parseInt(hourMatch[1], 10);
      
      const rateMatch = parserInput.match(/\$?(\d+)\s*\/\s*(hr|hour)/i);
      if (rateMatch && rateMatch[1]) rate = parseInt(rateMatch[1], 10);

      const clientMatch = parserInput.match(/for\s+([A-Za-z0-9\s]+?)(:|\.|\n|at|$)/i);
      if (clientMatch && clientMatch[1]) client = clientMatch[1].trim();

      const calculatedTotal = hours * rate;

      setParsedInvoice({
        clientName: client,
        invoiceNumber: 'INV-' + Math.floor(Math.random() * 9000 + 1000),
        items: [
          { name: `Strategic Consultative Deliverables (${hours} Hours)`, quantity: hours, price: rate, total: calculatedTotal }
        ],
        calculatedTotal
      });
      setLoading(false);
    }, 1000);
  };

  const handleGenerateReply = (e: React.FormEvent) => {
    e.preventDefault();
    if (!replyContext.trim()) return;
    setLoading(true);
    setTimeout(() => {
      let response = '';
      if (replyTone.includes('reminder')) {
        response = `Dear Accounts Team,

I hope this email finds you well. 

This is a gentle, professional inquiry to follow up on the payment of invoice ${replyContext || 'INV-1002'} which is currently past its scheduled settlement due date. 

Could you kindly verify the current status of this payment, or let me know if any other purchase-order confirmations are needed? For your convenience, I have re-attached the formal billing receipt.

Your continuous professional partnership is highly valued!

Best regards,
Freelancer OS Vendor`;
      } else {
        response = `Hello,

Thank you for the update concerning: "${replyContext}".

I appreciate your coordination. Let me gather the requested resources and align them with our active workspace delivery parameters. I will follow up with you early next week to discuss our milestones.

Best regards,
Consulting partner`;
      }
      setReplyOutput(response);
      setLoading(false);
    }, 900);
  };

  const handleProjectSummary = (e: React.FormEvent) => {
    e.preventDefault();
    if (!sumProjectName.trim() || !sumMilestones.trim()) return;
    setLoading(true);
    setTimeout(() => {
      setSummaryOutput(`### Project Status Summary: ${sumProjectName}
Generated on: ${new Date().toISOString().split('T')[0]}

**Active Work Progress Overview:**
We have successfully wrapped up the foundational iterations on "${sumProjectName}" aligning with your product design parameters.

**Milestone Breakdown:**
- **Completed**: ${sumMilestones.split(',')[0] || 'Database configurations'} - Written to production environment successfully.
- **In-Flight**: ${sumMilestones.split(',')[1] || 'CSS polish'} - Fine-tuning and verifying accessibility indexes.
- **Upcoming Target**: ${sumMilestones.split(',')[2] || 'Print tests'} - Launching formal end-user preview cycles.

*Impact Score:* 🌟 High Alignment (Sprints are executing perfectly on schedule). All financial ledgers are currently in healthy standing.`);
      setLoading(false);
    }, 1100);
  };

  return (
    <div className="space-y-6" id="ai-predictive-container">
      {/* Header */}
      <div className="flex flex-col md:flex-row md:items-center md:justify-between gap-4" id="ai-header">
        <div>
          <h2 className="text-2xl font-bold tracking-tight text-gray-950 flex items-center gap-2" id="ai-title">
            <Sparkles className="w-6 h-6 text-indigo-600 animate-pulse" />
            AI Workspace Copilot
          </h2>
          <p className="text-sm text-gray-500 mt-1 font-sans" id="ai-desc">
            Leverage smart text interfaces and logical helpers to fast-track proposal models and automate client coordination.
          </p>
        </div>
        <span className="inline-flex items-center gap-1.5 px-3 py-1 bg-indigo-50 border border-indigo-150 text-indigo-700 text-xs font-bold rounded-full w-max select-none">
          <Bot className="w-3.5 h-3.5" />
          Beta Smart Integration
        </span>
      </div>

      {/* Grid selector tabs and sandbox */}
      <div className="grid grid-cols-1 lg:grid-cols-4 gap-6" id="ai-grid-panels">
        {/* Left Side Navigation Rails */}
        <div className="lg:col-span-1 bg-white p-2 rounded-xl border border-gray-100 shadow-xs flex flex-col gap-1" id="ai-nav-rail">
          <button
            onClick={() => setActiveTab('proposal')}
            className={`p-3 text-left text-xs font-bold rounded-lg transition duration-150 flex items-center gap-2 cursor-pointer ${
              activeTab === 'proposal' ? 'bg-indigo-65/10 text-indigo-700' : 'text-gray-550 hover:bg-gray-50'
            }`}
            id="tab-btn-proposal"
          >
            <FileText className="w-4 h-4 shrink-0" />
            AI Proposal Writer
          </button>

          <button
            onClick={() => setActiveTab('parser')}
            className={`p-3 text-left text-xs font-bold rounded-lg transition duration-150 flex items-center gap-2 cursor-pointer ${
              activeTab === 'parser' ? 'bg-indigo-65/10 text-indigo-700' : 'text-gray-550 hover:bg-gray-50'
            }`}
            id="tab-btn-parser"
          >
            <Receipt className="w-4 h-4 shrink-0" />
            AI Invoice Generator
          </button>

          <button
            onClick={() => setActiveTab('reply')}
            className={`p-3 text-left text-xs font-bold rounded-lg transition duration-150 flex items-center gap-2 cursor-pointer ${
              activeTab === 'reply' ? 'bg-indigo-65/10 text-indigo-700' : 'text-gray-550 hover:bg-gray-50'
            }`}
            id="tab-btn-reply"
          >
            <MessageSquare className="w-4 h-4 shrink-0" />
            AI Client Reply Assistant
          </button>

          <button
            onClick={() => setActiveTab('summary')}
            className={`p-3 text-left text-xs font-bold rounded-lg transition duration-150 flex items-center gap-2 cursor-pointer ${
              activeTab === 'summary' ? 'bg-indigo-65/10 text-indigo-700' : 'text-gray-550 hover:bg-gray-50'
            }`}
            id="tab-btn-summary"
          >
            <Compass className="w-4 h-4 shrink-0" />
            AI Project Summary
          </button>

          <div className="mt-8 p-3 bg-gray-50 rounded-lg text-3xs text-gray-400 font-medium border border-gray-100 select-none">
            <span className="font-bold text-gray-500 block mb-1">Architecture Future-proof:</span>
            This workspace includes structural hooks referencing standard server-side Gemini API interfaces (`@google/genai`).
          </div>
        </div>

        {/* Right Side Working Canvas */}
        <div className="lg:col-span-3 bg-white rounded-xl border border-gray-100 shadow-xs p-6" id="ai-working-canvas">
          {/* TAB 1: PROPOSAL WRITER */}
          {activeTab === 'proposal' && (
            <div className="space-y-4 animate-fade-in" id="ai-proposal-form-wrapper">
              <div className="border-b border-gray-100 pb-3">
                <h3 className="text-sm font-bold text-gray-900">Custom Business Proposal Generator</h3>
                <p className="text-xs text-gray-400 mt-1">Provide client scope parameters to assemble persuasive contract pitches instantly.</p>
              </div>

              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                <form onSubmit={handleWriteProposal} className="space-y-3.5">
                  <div>
                    <label className="block text-3xs font-bold uppercase tracking-wider text-gray-400 mb-1">Target Client Account</label>
                    <input
                      type="text"
                      required
                      placeholder="e.g. Timothy Vance Global Corp"
                      value={propClient}
                      onChange={(e) => setPropClient(e.target.value)}
                      className="w-full bg-white text-gray-900 border border-gray-250 rounded-lg px-3 py-2 text-xs outline-none focus:border-indigo-500"
                    />
                  </div>

                  <div>
                    <label className="block text-3xs font-bold uppercase tracking-wider text-gray-400 mb-1">Proposed Budget (USD)</label>
                    <input
                      type="number"
                      required
                      placeholder="e.g. 5000"
                      value={propBudget}
                      onChange={(e) => setPropBudget(e.target.value)}
                      className="w-full bg-white text-gray-900 border border-gray-250 rounded-lg px-3 py-2 text-xs outline-none focus:border-indigo-500"
                    />
                  </div>

                  <div>
                    <label className="block text-3xs font-bold uppercase tracking-wider text-gray-400 mb-1 font-sans">Project Scope & Deliverables</label>
                    <textarea
                      rows={5}
                      required
                      placeholder="e.g. Build an offline-first mobile responsive inventory monitoring system using React, Vite, and SQLite, with localized state caching..."
                      value={propScope}
                      onChange={(e) => setPropScope(e.target.value)}
                      className="w-full bg-white text-gray-900 border border-gray-250 rounded-lg px-3 py-2 text-xs outline-none focus:border-indigo-500 font-sans"
                    />
                  </div>

                  <button
                    type="submit"
                    disabled={loading}
                    className="w-full justify-center py-2.5 bg-indigo-600 hover:bg-indigo-700 text-white rounded-lg text-xs font-bold transition flex items-center gap-1 cursor-pointer disabled:opacity-50"
                  >
                    {loading ? (
                      <Loader2 className="w-3.5 h-3.5 animate-spin" />
                    ) : (
                      <Sparkles className="w-3.5 h-3.5" />
                    )}
                    Generate Pitch Document
                  </button>
                </form>

                {/* Proposal Output Window */}
                <div className="bg-gray-50 border border-gray-200 rounded-xl p-4 flex flex-col justify-between max-h-[400px]" id="ai-proposal-output">
                  {proposalOutput ? (
                    <>
                      <div className="overflow-y-auto pr-1 text-xs text-gray-700 space-y-2 whitespace-pre-wrap font-sans">
                        {proposalOutput}
                      </div>
                      <div className="border-t border-gray-200/50 pt-3 mt-3 flex items-center justify-between">
                        <button
                          onClick={() => handleCopy(proposalOutput)}
                          className="px-3 py-1.5 bg-white border border-gray-200 rounded-md text-3xs text-gray-600 hover:border-indigo-300 transition duration-150 font-bold inline-flex items-center gap-1 cursor-pointer"
                        >
                          {copied ? (
                            <>
                              <Check className="w-3 h-3 text-emerald-600" />
                              Copied!
                            </>
                          ) : (
                            <>
                              <Copy className="w-3 h-3" />
                              Copy Text
                            </>
                          )}
                        </button>
                        <button
                          onClick={() => setProposalOutput('')}
                          className="text-3xs text-gray-400 hover:text-gray-600 transition cursor-pointer"
                        >
                          Reset
                        </button>
                      </div>
                    </>
                  ) : (
                    <div className="flex flex-col items-center justify-center h-full text-center text-gray-400 p-8">
                      <FileText className="w-8 h-8 text-gray-300 mb-2" />
                      <p className="text-xs font-semibold text-gray-500">Document viewer is empty</p>
                      <p className="text-2xs text-gray-400 mt-0.5">Click "Generate Pitch Document" to build a customized corporate agreement.</p>
                    </div>
                  )}
                </div>
              </div>
            </div>
          )}

          {/* TAB 2: INVOICE GENERATOR PARSER */}
          {activeTab === 'parser' && (
            <div className="space-y-4 animate-fade-in" id="ai-parser-wrapper">
              <div className="border-b border-gray-100 pb-3">
                <h3 className="text-sm font-bold text-gray-900">Natural Language Invoice Extractor</h3>
                <p className="text-xs text-gray-400 mt-1">Type custom plain text instructions representing client work, and watch the AI structure it automatically.</p>
              </div>

              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                <form onSubmit={handleParseInvoiceText} className="space-y-4">
                  <div>
                    <label className="block text-3xs font-bold uppercase tracking-wider text-gray-400 mb-1">Plain Text Prompt instructions</label>
                    <textarea
                      rows={6}
                      required
                      value={parserInput}
                      onChange={(e) => setParserInput(e.target.value)}
                      placeholder="e.g. Complete invoice structure for VANCE DESIGNS. 32 hours of UX testing consultations at $90/hr. Terms of receipt scheduled net 15 days."
                      className="w-full bg-white text-gray-900 border border-gray-250 rounded-lg px-3 py-2 text-xs outline-none focus:border-indigo-500 font-mono"
                    />
                  </div>

                  <button
                    type="submit"
                    disabled={loading}
                    className="w-full justify-center py-2.5 bg-indigo-600 hover:bg-indigo-700 text-white rounded-lg text-xs font-bold transition flex items-center gap-1 cursor-pointer disabled:opacity-50"
                  >
                    {loading ? (
                      <Loader2 className="w-3.5 h-3.5 animate-spin" />
                    ) : (
                      <Sparkles className="w-3.5 h-3.5" />
                    )}
                    Structurize Invoice Item
                  </button>
                </form>

                {/* Output visual mock mapping */}
                <div className="bg-gray-50 border border-gray-200 rounded-xl p-4 flex flex-col justify-between" id="ai-parser-output">
                  {parsedInvoice ? (
                    <div className="space-y-4 text-xs">
                      <div className="flex items-center justify-between border-b border-gray-200/50 pb-2">
                        <span className="font-bold text-gray-900">Auto Generated Draft</span>
                        <span className="text-3xs uppercase px-2 py-0.5 font-bold text-indigo-700 bg-indigo-50 border border-indigo-150 rounded">Parsed Successfully</span>
                      </div>
                      
                      <div className="space-y-1 bg-white p-3 rounded-lg border border-gray-200/80">
                        <p className="text-gray-400 text-3xs uppercase tracking-wider font-bold">Client Target Name:</p>
                        <p className="font-bold text-gray-950 text-xs">{parsedInvoice.clientName}</p>
                      </div>

                      <div className="space-y-1.5 bg-white p-3 rounded-lg border border-gray-200/80">
                        <p className="text-gray-400 text-3xs uppercase tracking-wider font-bold">Line Items breakdown:</p>
                        {parsedInvoice.items.map((it: any, idx: number) => (
                          <div key={idx} className="flex justify-between items-center text-xs pt-1 border-t border-gray-50">
                            <span>{it.name}</span>
                            <span className="font-bold text-gray-900">${it.total.toLocaleString()}</span>
                          </div>
                        ))}
                      </div>

                      <div className="flex justify-between items-center bg-indigo-55/5 p-3 rounded-lg border border-indigo-55/10 text-sm font-bold">
                        <span className="text-indigo-900">Total Billed Volume:</span>
                        <span className="text-indigo-950">${parsedInvoice.calculatedTotal.toLocaleString()} USD</span>
                      </div>

                      <p className="text-3xs text-gray-400 italic">This drafted data can be piped into your core billing invoice workspace instantly.</p>
                      <button
                        onClick={() => setParsedInvoice(null)}
                        className="text-3xs py-1.5 text-gray-500 hover:text-indigo-600 transition font-bold"
                      >
                        - Clear draft
                      </button>
                    </div>
                  ) : (
                    <div className="flex flex-col items-center justify-center h-full text-center text-gray-400 p-8">
                      <Receipt className="w-8 h-8 text-gray-300 mb-2" />
                      <p className="text-xs font-semibold text-gray-500 font-sans">No extraction drafted</p>
                      <p className="text-2xs text-gray-400 mt-0.5">Type plain text details to draft parsed invoices instantly.</p>
                    </div>
                  )}
                </div>
              </div>
            </div>
          )}

          {/* TAB 3: CLIENT REPLY ASSISTANT */}
          {activeTab === 'reply' && (
            <div className="space-y-4 animate-fade-in" id="ai-reply-wrapper">
              <div className="border-b border-gray-100 pb-3">
                <h3 className="text-sm font-bold text-gray-900">Client Reply Email Composer</h3>
                <p className="text-xs text-gray-400 mt-1">Coordinate response copy, overdue reminders, or scope adjustments with client organizations seamlessly.</p>
              </div>

              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                <form onSubmit={handleGenerateReply} className="space-y-3.5">
                  <div>
                    <label className="block text-3xs font-bold uppercase tracking-wider text-gray-400 mb-1">Select Response Tone template</label>
                    <select
                      value={replyTone}
                      onChange={(e) => setReplyTone(e.target.value)}
                      className="w-full bg-white text-gray-950 border border-gray-250 rounded-lg px-3 py-2 text-xs outline-none focus:border-indigo-500 cursor-pointer"
                    >
                      <option value="Professional reminder">Overdue Invoice payment reminder (Firm & Helpful)</option>
                      <option value="Friendly update">Discussing timeline/milestone delays (Cooperative)</option>
                    </select>
                  </div>

                  <div>
                    <label className="block text-3xs font-bold uppercase tracking-wider text-gray-400 mb-1 font-sans">Core Context Memos</label>
                    <textarea
                      rows={5}
                      required
                      value={replyContext}
                      onChange={(e) => setReplyContext(e.target.value)}
                      placeholder="e.g. Invoice INV-1002 is past its net 30 timeline. Please verify billing ledger details."
                      className="w-full bg-white text-gray-900 border border-gray-250 rounded-lg px-3 py-2 text-xs outline-none focus:border-indigo-500 font-sans"
                    />
                  </div>

                  <button
                    type="submit"
                    disabled={loading}
                    className="w-full justify-center py-2.5 bg-indigo-600 hover:bg-indigo-700 text-white rounded-lg text-xs font-bold transition flex items-center gap-1 cursor-pointer disabled:opacity-50"
                  >
                    {loading ? (
                      <Loader2 className="w-3.5 h-3.5 animate-spin" />
                    ) : (
                      <Sparkles className="w-3.5 h-3.5" />
                    )}
                    Generate Response Copy
                  </button>
                </form>

                {/* Email output */}
                <div className="bg-gray-50 border border-gray-200 rounded-xl p-4 flex flex-col justify-between max-h-[380px]" id="ai-reply-output">
                  {replyOutput ? (
                    <>
                      <div className="overflow-y-auto text-xs text-gray-700 space-y-2 whitespace-pre-wrap font-sans">
                        {replyOutput}
                      </div>

                      <div className="border-t border-gray-200/50 pt-3 mt-3 flex items-center justify-between">
                        <button
                          onClick={() => handleCopy(replyOutput)}
                          className="px-3 py-1.5 bg-white border border-gray-200 rounded-md text-3xs text-gray-600 hover:border-indigo-300 transition duration-150 font-bold inline-flex items-center gap-1 cursor-pointer"
                        >
                          {copied ? (
                            <>
                              <Check className="w-3 h-3 text-emerald-600" />
                              Copied!
                            </>
                          ) : (
                            <>
                              <Copy className="w-3 h-3" />
                              Copy Email
                            </>
                          )}
                        </button>
                        <button
                          onClick={() => setReplyOutput('')}
                          className="text-3xs text-gray-400 hover:text-gray-600 transition cursor-pointer"
                        >
                          Reset
                        </button>
                      </div>
                    </>
                  ) : (
                    <div className="flex flex-col items-center justify-center h-full text-center text-gray-400 p-8">
                      <MessageSquare className="w-8 h-8 text-gray-300 mb-2" />
                      <p className="text-xs font-semibold text-gray-500">Draft Composer Empty</p>
                      <p className="text-2xs text-gray-400 mt-0.5">Click "Generate Response Copy" to build emails for client communication.</p>
                    </div>
                  )}
                </div>
              </div>
            </div>
          )}

          {/* TAB 4: PROJECT SUMMARY GENERATOR */}
          {activeTab === 'summary' && (
            <div className="space-y-4 animate-fade-in" id="ai-summary-wrapper">
              <div className="border-b border-gray-100 pb-3">
                <h3 className="text-sm font-bold text-gray-900 font-sans">AI Workspace Summary Assembler</h3>
                <p className="text-xs text-gray-400 mt-1">Analyze completed active milestones and compile tidy status summaries with ease.</p>
              </div>

              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                <form onSubmit={handleProjectSummary} className="space-y-3.5">
                  <div>
                    <label className="block text-3xs font-bold uppercase tracking-wider text-gray-400 mb-1">Target Project Name</label>
                    <input
                      type="text"
                      required
                      placeholder="e.g. Vance Brand Architecture Sprint"
                      value={sumProjectName}
                      onChange={(e) => setSumProjectName(e.target.value)}
                      className="w-full bg-white text-gray-900 border border-gray-250 rounded-lg px-3 py-2 text-xs outline-none focus:border-indigo-500"
                    />
                  </div>

                  <div>
                    <label className="block text-3xs font-bold uppercase tracking-wider text-gray-400 mb-1 font-sans">Active Milestones status (separated by commas)</label>
                    <textarea
                      rows={5}
                      required
                      value={sumMilestones}
                      onChange={(e) => setSumMilestones(e.target.value)}
                      placeholder="e.g. Created login views, configured SQLite databases locally, polished mobile navigation responsive sidebars..."
                      className="w-full bg-white text-gray-900 border border-gray-250 rounded-lg px-3 py-2 text-xs outline-none focus:border-indigo-500 font-sans"
                    />
                  </div>

                  <button
                    type="submit"
                    disabled={loading}
                    className="w-full justify-center py-2.5 bg-indigo-600 hover:bg-indigo-700 text-white rounded-lg text-xs font-bold transition flex items-center gap-1 cursor-pointer disabled:opacity-50"
                  >
                    {loading ? (
                      <Loader2 className="w-3.5 h-3.5 animate-spin" />
                    ) : (
                      <Sparkles className="w-3.5 h-3.5" />
                    )}
                    Generate Project Summary
                  </button>
                </form>

                {/* Output Summary text */}
                <div className="bg-gray-50 border border-gray-200 rounded-xl p-4 flex flex-col justify-between max-h-[380px]" id="ai-summary-output">
                  {summaryOutput ? (
                    <>
                      <div className="overflow-y-auto text-xs text-gray-700 space-y-2 whitespace-pre-wrap font-sans">
                        {summaryOutput}
                      </div>

                      <div className="border-t border-gray-200/50 pt-3 mt-3 flex items-center justify-between">
                        <button
                          onClick={() => handleCopy(summaryOutput)}
                          className="px-3 py-1.5 bg-white border border-gray-200 rounded-md text-3xs text-gray-600 hover:border-indigo-300 transition duration-150 font-bold inline-flex items-center gap-1 cursor-pointer"
                        >
                          {copied ? (
                            <>
                              <Check className="w-3 h-3 text-emerald-600" />
                              Copied!
                            </>
                          ) : (
                            <>
                              <Copy className="w-3 h-3" />
                              Copy Summary
                            </>
                          )}
                        </button>
                        <button
                          onClick={() => setSummaryOutput('')}
                          className="text-3xs text-gray-400 hover:text-gray-600 transition cursor-pointer"
                        >
                          Reset
                        </button>
                      </div>
                    </>
                  ) : (
                    <div className="flex flex-col items-center justify-center h-full text-center text-gray-400 p-8">
                      <Compass className="w-8 h-8 text-gray-300 mb-2" />
                      <p className="text-xs font-semibold text-gray-500">Summary Canvas is empty</p>
                      <p className="text-2xs text-gray-400 mt-0.5 font-sans">Compile professional reports to communicate sprint status to shareholders.</p>
                    </div>
                  )}
                </div>
              </div>
            </div>
          )}
        </div>
      </div>
    </div>
  );
}
