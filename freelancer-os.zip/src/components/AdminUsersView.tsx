import React, { useEffect, useState } from 'react';
import { 
  Users, 
  Search, 
  ShieldCheck, 
  UserX, 
  Trash2, 
  Key, 
  Loader2, 
  Mail, 
  CircleAlert 
} from 'lucide-react';
import { getAllUsers, updateUserStatus, deleteUser, logActivity } from '../services/db';
import { UserProfile, ActivityType } from '../types';
import { useAuth } from '../contexts/AuthContext';

export default function AdminUsersView() {
  const { adminProfile } = useAuth();
  const [users, setUsers] = useState<UserProfile[]>([]);
  const [loading, setLoading] = useState(true);
  const [actionLoading, setActionLoading] = useState<string | null>(null);
  const [searchQuery, setSearchQuery] = useState('');
  const [successMsg, setSuccessMsg] = useState('');
  const [errorMsg, setErrorMsg] = useState('');

  const loadAllUsers = async () => {
    try {
      setLoading(true);
      const data = await getAllUsers();
      setUsers(data || []);
    } catch (err: any) {
      console.error(err);
      setErrorMsg('Failed to load users directory information.');
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    loadAllUsers();
  }, []);

  const handleToggleStatus = async (userId: string, currentStatus: 'active' | 'suspended') => {
    const newStatus = currentStatus === 'suspended' ? 'active' : 'suspended';
    try {
      setErrorMsg('');
      setSuccessMsg('');
      setActionLoading(userId + '-status');

      await updateUserStatus(userId, newStatus);
      
      // Update UI state
      setUsers(prev => prev.map(u => u.userId === userId ? { ...u, status: newStatus } : u));
      
      // Log auditing activity
      await logActivity(
        adminProfile?.adminId || 'system-admin',
        `Admin modified user ${userId} state status to "${newStatus}"`,
        ActivityType.AUTH
      );

      setSuccessMsg(`Successfully toggled account status of user to "${newStatus}".`);
      setTimeout(() => setSuccessMsg(''), 4000);
    } catch (err: any) {
      console.error(err);
      setErrorMsg(err?.message || 'Access Denied: Unpermitted action state change.');
    } finally {
      setActionLoading(null);
    }
  };

  const handleDeleteUser = async (userId: string) => {
    if (!window.confirm("Are you sure you want to permanently delete this user? This cannot be undone.")) {
      return;
    }

    try {
      setErrorMsg('');
      setSuccessMsg('');
      setActionLoading(userId + '-delete');

      await deleteUser(userId);
      
      // Update local state
      setUsers(prev => prev.filter(u => u.userId !== userId));

      await logActivity(
        adminProfile?.adminId || 'system-admin',
        `Admin deleted user profile account ${userId}`,
        ActivityType.AUTH
      );

      setSuccessMsg("User profile deleted successfully.");
      setTimeout(() => setSuccessMsg(''), 4000);
    } catch (err: any) {
      console.error(err);
      setErrorMsg(err?.message || 'Failed to delete target user profile.');
    } finally {
      setActionLoading(null);
    }
  };

  const filteredUsers = users.filter(user => {
    const name = user.name || '';
    const email = user.email || '';
    const category = user.freelancerCategory || '';
    return name.toLowerCase().includes(searchQuery.toLowerCase()) || 
           email.toLowerCase().includes(searchQuery.toLowerCase()) ||
           category.toLowerCase().includes(searchQuery.toLowerCase());
  });

  return (
    <div className="space-y-6 animate-fade-in font-sans" id="admin-users-root">
      
      {/* Header and counter */}
      <div className="flex flex-col md:flex-row md:items-center justify-between border-b border-gray-150 pb-5 gap-4">
        <div>
          <h1 className="text-2xl font-black text-gray-950 tracking-tight">SaaS User Directory Management</h1>
          <p className="text-xs text-gray-500 mt-1">Review active users, modify administrative status (suspend, activate) and remove expired profiles.</p>
        </div>
        <div className="bg-indigo-50 border border-indigo-150 p-2.5 px-4.5 rounded-2xl flex items-center gap-2 text-indigo-750 font-bold text-xs font-mono select-none">
          <Users className="w-4.5 h-4.5 shrink-0" />
          <span>Total Database Users: {users.length}</span>
        </div>
      </div>

      {/* Messaging feedbacks */}
      {successMsg && (
        <div className="p-3 bg-emerald-50 border border-emerald-150 rounded-xl text-xs text-emerald-850 font-semibold" id="users-success-feed">
          {successMsg}
        </div>
      )}

      {errorMsg && (
        <div className="p-3 bg-rose-50 border border-rose-150 rounded-xl text-xs text-rose-850 font-semibold" id="users-error-feed">
          {errorMsg}
        </div>
      )}

      {/* Query Filter and Actions */}
      <div className="flex flex-col sm:flex-row items-center gap-4 bg-white p-4 border border-gray-150 rounded-2xl select-none">
        <div className="relative w-full flex-1">
          <Search className="absolute left-3.5 top-3 w-4 h-4 text-gray-400" />
          <input
            type="text"
            placeholder="Search matching users by name, email, or category..."
            value={searchQuery}
            onChange={(e) => setSearchQuery(e.target.value)}
            className="w-full pl-10 pr-4 py-2.5 bg-gray-50/50 border border-gray-200 text-xs rounded-xl outline-none focus:bg-white focus:border-indigo-650"
            id="search-users-field"
          />
        </div>
        <button 
          onClick={loadAllUsers}
          disabled={loading}
          className="w-full sm:w-auto px-5 py-2.5 bg-gray-50 hover:bg-gray-100 border border-gray-200 text-xs text-gray-800 rounded-xl font-bold transition flex items-center justify-center gap-1.5 cursor-pointer disabled:opacity-50"
        >
          {loading ? <Loader2 className="w-3.5 h-3.5 animate-spin" /> : 'Reload Roster'}
        </button>
      </div>

      {loading ? (
        <div className="flex flex-col items-center justify-center py-16" id="users-loading-spinner">
          <Loader2 className="w-8 h-8 text-indigo-650 animate-spin" />
        </div>
      ) : (
        <div className="bg-white border border-gray-150 rounded-2xl overflow-hidden shadow-xs" id="users-list-wrapper">
          <div className="overflow-x-auto">
            <table className="w-full text-left border-collapse" id="admin-users-table">
              <thead>
                <tr className="bg-gray-50 border-b border-gray-150 text-[10px] font-extrabold text-gray-400 uppercase select-none">
                  <th className="p-4 px-6">User Avatar & Name</th>
                  <th className="p-4">Billing Contact</th>
                  <th className="p-4">Category</th>
                  <th className="p-4">Identity Match</th>
                  <th className="p-4">Account Status</th>
                  <th className="p-4 text-right px-6">Access Powers</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-gray-150 text-xs">
                {filteredUsers.length === 0 ? (
                  <tr>
                    <td colSpan={6} className="p-12 text-center text-gray-400 font-semibold">
                      No matching user profile records found.
                    </td>
                  </tr>
                ) : (
                  filteredUsers.map((user) => (
                    <tr key={user.userId} className="hover:bg-gray-50/50 transition">
                      
                      {/* Avatar Profile */}
                      <td className="p-4 px-6 flex items-center gap-3">
                        <img 
                          src={user.profilePhoto || `https://api.dicebear.com/7.x/initials/svg?seed=${user.name}`}
                          alt="profile" 
                          referrerPolicy="no-referrer"
                          className="w-8.5 h-8.5 bg-gray-100 rounded-lg object-cover border border-gray-100"
                        />
                        <div className="min-w-0">
                          <h4 className="font-bold text-gray-950 truncate max-w-[170px]">{user.name}</h4>
                          <span className="text-[10px] font-mono text-gray-400 font-semibold">ROLE: {user.role || 'user'}</span>
                        </div>
                      </td>

                      {/* Contact details */}
                      <td className="p-4 shrink-0">
                        <div className="flex items-center gap-1">
                          <Mail className="w-3.5 h-3.5 text-gray-400" />
                          <span className="font-semibold text-gray-700">{user.email}</span>
                        </div>
                      </td>

                      {/* Category field */}
                      <td className="p-4">
                        <span className="bg-gray-100/70 border border-gray-150 text-gray-800 text-[10px] font-bold font-mono px-2 py-0.5 rounded-full uppercase">
                          {user.freelancerCategory || 'N/A'}
                        </span>
                      </td>

                      {/* UID path */}
                      <td className="p-4">
                        <span className="text-[10px] text-gray-400 font-mono" title={user.userId}>
                          {user.userId.slice(0, 8)}...
                        </span>
                      </td>

                      {/* State Status column */}
                      <td className="p-4">
                        <span className={`inline-flex items-center gap-1 px-2.5 py-0.5 rounded-full text-[10px] font-mono font-bold uppercase border ${
                          user.status !== 'suspended' 
                            ? 'bg-emerald-50 border-emerald-150 text-emerald-800' 
                            : 'bg-rose-50 border-rose-150 text-rose-800'
                        }`}>
                          {user.status !== 'suspended' ? 'Active' : 'Suspended'}
                        </span>
                      </td>

                      {/* State status changer operations */}
                      <td className="p-4 text-right px-6 space-x-2.5">
                        <button
                          onClick={() => handleToggleStatus(user.userId, user.status || 'active')}
                          disabled={actionLoading !== null}
                          className={`p-1.5 px-3 rounded-lg border text-3xs font-extrabold uppercase tracking-wide transition cursor-pointer inline-flex items-center gap-1 select-none ${
                            user.status !== 'suspended' 
                              ? 'bg-amber-50 border-amber-150 text-amber-900 hover:bg-amber-100' 
                              : 'bg-emerald-50 border-emerald-150 text-emerald-900 hover:bg-emerald-100'
                          }`}
                          title={user.status !== 'suspended' ? "Suspend member access" : "Activate member access"}
                          id={`btn-suspend-${user.userId}`}
                        >
                          {actionLoading === user.userId + '-status' ? (
                            <Loader2 className="w-3 h-3 animate-spin" />
                          ) : user.status !== 'suspended' ? (
                            <>
                              <UserX className="w-3.5 h-3.5 text-amber-700" />
                              <span>Suspend</span>
                            </>
                          ) : (
                            <>
                              <ShieldCheck className="w-3.5 h-3.5 text-emerald-700" />
                              <span>Activate</span>
                            </>
                          )}
                        </button>
                        <button
                          onClick={() => handleDeleteUser(user.userId)}
                          disabled={actionLoading !== null}
                          className="p-1.5 px-2 bg-rose-50 hover:bg-rose-100 border border-rose-150 text-rose-900 rounded-lg transition cursor-pointer select-none inline-flex items-center"
                          title="Purge profile"
                          id={`btn-delete-${user.userId}`}
                        >
                          {actionLoading === user.userId + '-delete' ? (
                            <Loader2 className="w-3 h-3 animate-spin" />
                          ) : (
                            <Trash2 className="w-3.5 h-3.5 text-rose-700" />
                          )}
                        </button>
                      </td>

                    </tr>
                  ))
                )}
              </tbody>
            </table>
          </div>
        </div>
      )}

    </div>
  );
}
