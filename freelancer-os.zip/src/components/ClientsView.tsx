import React, { useState, useEffect } from 'react';
import { 
  Plus, 
  Search, 
  Edit, 
  Trash2, 
  Mail, 
  Phone, 
  Globe, 
  Building, 
  X, 
  Loader2, 
  Filter, 
  FileSpreadsheet, 
  UserCheck2 
} from 'lucide-react';
import { Client, ClientStatus } from '../types';
import { getClients, addClient, updateClient, deleteClient } from '../services/db';
import { useAuth } from '../contexts/AuthContext';

export default function ClientsView() {
  const { user } = useAuth();
  const [clients, setClients] = useState<Client[]>([]);
  const [loading, setLoading] = useState(true);
  const [searchQuery, setSearchQuery] = useState('');
  const [statusFilter, setStatusFilter] = useState<string>('All');

  // Form states
  const [isModalOpen, setIsModalOpen] = useState(false);
  const [editingClient, setEditingClient] = useState<Client | null>(null);
  const [formName, setFormName] = useState('');
  const [formEmail, setFormEmail] = useState('');
  const [formPhone, setFormPhone] = useState('');
  const [formCompany, setFormCompany] = useState('');
  const [formCountry, setFormCountry] = useState('');
  const [formNotes, setFormNotes] = useState('');
  const [formStatus, setFormStatus] = useState<ClientStatus>(ClientStatus.ACTIVE);
  const [formSaving, setFormSaving] = useState(false);

  // Load clients
  const loadClientRecords = async () => {
    if (!user) return;
    try {
      setLoading(true);
      const data = await getClients(user.uid);
      setClients(data);
    } catch (err) {
      console.error(err);
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    loadClientRecords();
  }, [user]);

  // Open modal for add
  const handleOpenAdd = () => {
    setEditingClient(null);
    setFormName('');
    setFormEmail('');
    setFormPhone('');
    setFormCompany('');
    setFormCountry('');
    setFormNotes('');
    setFormStatus(ClientStatus.ACTIVE);
    setIsModalOpen(true);
  };

  // Open modal for edit
  const handleOpenEdit = (client: Client) => {
    setEditingClient(client);
    setFormName(client.clientName);
    setFormEmail(client.email);
    setFormPhone(client.phone || '');
    setFormCompany(client.company || '');
    setFormCountry(client.country || '');
    setFormNotes(client.notes || '');
    setFormStatus(client.status);
    setIsModalOpen(true);
  };

  // Submit form
  const handleSaveClient = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!user) return;
    if (!formName.trim() || !formEmail.trim()) {
      alert('Client Name and Email are required properties.');
      return;
    }

    try {
      setFormSaving(true);
      if (editingClient) {
        // Update Action
        await updateClient(user.uid, editingClient.id, {
          clientName: formName,
          email: formEmail,
          phone: formPhone,
          company: formCompany,
          country: formCountry,
          notes: formNotes,
          status: formStatus
        });
      } else {
        // Create Action
        await addClient(user.uid, {
          clientName: formName,
          email: formEmail,
          phone: formPhone,
          company: formCompany,
          country: formCountry,
          notes: formNotes,
          status: formStatus
        });
      }
      setIsModalOpen(false);
      await loadClientRecords();
    } catch (err) {
      console.error(err);
      alert('Error storing client data: ' + (err instanceof Error ? err.message : String(err)));
    } finally {
      setFormSaving(false);
    }
  };

  // Delete Action
  const handleDeleteClient = async (clientId: string, name: string) => {
    if (!user) return;
    if (!confirm(`Are you sure you want to remove client "${name}"? This operation cannot be undone.`)) return;
    
    try {
      await deleteClient(user.uid, clientId, name);
      await loadClientRecords();
    } catch (err) {
      console.error(err);
      alert('Failed to delete client record.');
    }
  };

  // Filtration logic
  const filteredClients = clients.filter(c => {
    const queryLower = searchQuery.toLowerCase();
    const matchSearch = 
      c.clientName.toLowerCase().includes(queryLower) ||
      c.email.toLowerCase().includes(queryLower) ||
      c.company.toLowerCase().includes(queryLower);
    
    const matchStatus = statusFilter === 'All' ? true : c.status === statusFilter;
    return matchSearch && matchStatus;
  });

  // KPI Calculations
  const totalClients = clients.length;
  const activeCount = clients.filter(c => c.status === ClientStatus.ACTIVE).length;
  const leadCount = clients.filter(c => c.status === ClientStatus.LEAD).length;

  return (
    <div className="space-y-6" id="clients-view-container">
      {/* Header and Add Trigger */}
      <div className="flex flex-col md:flex-row md:items-center md:justify-between gap-4" id="clients-view-header">
        <div>
          <h2 className="text-2xl font-bold tracking-tight text-gray-950" id="clients-title">Client Directory</h2>
          <p className="text-sm text-gray-500 mt-1" id="clients-desc">Store professional credentials, contact paths, and statuses of your SaaS clients.</p>
        </div>
        <button
          onClick={handleOpenAdd}
          className="inline-flex items-center gap-2 justify-center px-4 py-2 bg-indigo-600 hover:bg-indg-700 text-white rounded-lg text-sm font-medium transition cursor-pointer"
          id="btn-add-client"
        >
          <Plus className="w-4 h-4" />
          Add Client
        </button>
      </div>

      {/* KPI Stats overview */}
      <div className="grid grid-cols-1 sm:grid-cols-3 gap-4" id="clients-kpis">
        <div className="bg-white p-4 rounded-xl border border-gray-100 flex items-center gap-4 shadow-xs" id="kpi-card-total">
          <div className="p-3 bg-indigo-50 text-indigo-600 rounded-lg">
            <Building className="w-5 h-5" />
          </div>
          <div>
            <p className="text-xs text-gray-500 font-medium">Total Clients</p>
            <h3 className="text-xl font-bold text-gray-900 mt-0.5">{totalClients}</h3>
          </div>
        </div>
        <div className="bg-white p-4 rounded-xl border border-gray-100 flex items-center gap-4 shadow-xs" id="kpi-card-active">
          <div className="p-3 bg-emerald-50 text-emerald-600 rounded-lg">
            <UserCheck2 className="w-5 h-5" />
          </div>
          <div>
            <p className="text-xs text-gray-500 font-medium">Active Accounts</p>
            <h3 className="text-xl font-bold text-gray-900 mt-0.5">{activeCount}</h3>
          </div>
        </div>
        <div className="bg-white p-4 rounded-xl border border-gray-100 flex items-center gap-4 shadow-xs" id="kpi-card-leads">
          <div className="p-3 bg-amber-50 text-amber-600 rounded-lg">
            <FileSpreadsheet className="w-5 h-5" />
          </div>
          <div>
            <p className="text-xs text-gray-500 font-medium font-sans">Leads & Prospects</p>
            <h3 className="text-xl font-bold text-gray-900 mt-0.5">{leadCount}</h3>
          </div>
        </div>
      </div>

      {/* Filters and search section */}
      <div className="flex flex-col sm:flex-row items-center gap-3 bg-white p-4 rounded-xl border border-gray-100 shadow-xs" id="clients-filter-bar">
        <div className="relative flex-1 w-full" id="search-input-wrapper">
          <Search className="absolute left-3 top-2.5 h-4.5 w-4.5 text-gray-400" />
          <input
            type="text"
            placeholder="Search by client name, email, or company name..."
            value={searchQuery}
            onChange={(e) => setSearchQuery(e.target.value)}
            className="w-full bg-gray-50 text-gray-900 pl-10 pr-4 py-2 rounded-lg text-sm border border-gray-200 outline-none focus:border-indigo-500 font-sans"
            id="client-search-field"
          />
        </div>
        <div className="flex items-center gap-2 w-full sm:w-auto" id="filter-wrapper">
          <Filter className="w-4 h-4 text-gray-400 cursor-pointer" />
          <select
            value={statusFilter}
            onChange={(e) => setStatusFilter(e.target.value)}
            className="w-full sm:w-auto text-sm text-gray-700 bg-gray-50 border border-gray-200 rounded-lg px-3 py-2 cursor-pointer outline-none focus:border-indigo-500"
            id="client-filter-dropdown"
          >
            <option value="All">All Statuses</option>
            <option value={ClientStatus.ACTIVE}>Active</option>
            <option value={ClientStatus.INACTIVE}>Inactive</option>
            <option value={ClientStatus.LEAD}>Lead</option>
          </select>
        </div>
      </div>

      {/* Grid or Table listing clients */}
      {loading ? (
        <div className="flex flex-col items-center justify-center p-12 bg-white rounded-xl border border-gray-100 shadow-xs" id="clients-loading-spinner">
          <Loader2 className="w-8 h-8 text-indigo-600 animate-spin" />
          <p className="text-sm text-gray-500 mt-2">Retrieving client list from cloud database...</p>
        </div>
      ) : filteredClients.length === 0 ? (
        <div className="text-center p-12 bg-white rounded-xl border border-gray-100 shadow-xs" id="clients-empty">
          <div className="w-12 h-12 bg-indigo-50 text-indigo-600 rounded-full flex items-center justify-center mx-auto mb-3">
            <Search className="w-6 h-6" />
          </div>
          <p className="text-base font-semibold text-gray-900">No client records found</p>
          <p className="text-sm text-gray-500 mt-1 max-w-sm mx-auto">
            {searchQuery || statusFilter !== 'All' 
              ? "We couldn't find any entries matching your current filters. Clear filters and try again." 
              : "Launch your business footprint by adding your first client contact database parameters today!"}
          </p>
          {!searchQuery && statusFilter === 'All' && (
            <button
              onClick={handleOpenAdd}
              className="mt-4 px-4 py-2 bg-indigo-600 hover:bg-indigo-700 text-white rounded-lg text-sm font-medium transition cursor-pointer"
              id="cta-add-first-client"
            >
              Construct Record
            </button>
          )}
        </div>
      ) : (
        <div className="grid grid-cols-1 md:grid-cols-2 xl:grid-cols-3 gap-6" id="clients-grid-list">
          {filteredClients.map((client) => (
            <div 
              key={client.id}
              className="bg-white rounded-xl border border-gray-100 shadow-xs hover:shadow-md transition duration-200 flex flex-col justify-between overflow-hidden"
              id={`client-card-${client.id}`}
            >
              {/* Card top banner / details */}
              <div className="p-5 space-y-4">
                <div className="flex items-start justify-between gap-2">
                  <div>
                    <h4 className="text-base font-bold text-gray-900 tracking-tight">{client.clientName}</h4>
                    {client.company && (
                      <p className="text-xs text-gray-500 font-medium flex items-center gap-1 mt-0.5">
                        <Building className="w-3.5 h-3.5" />
                        {client.company}
                      </p>
                    )}
                  </div>
                  <span 
                    className={`inline-flex items-center px-2 py-0.5 rounded-full text-2xs font-semibold ${
                      client.status === ClientStatus.ACTIVE ? 'bg-emerald-55/10 text-emerald-700 border border-emerald-55/20' :
                      client.status === ClientStatus.LEAD ? 'bg-amber-50 text-amber-700 border border-amber-200' :
                      'bg-gray-100 text-gray-600'
                    }`}
                  >
                    {client.status}
                  </span>
                </div>

                {/* Sub-contacts */}
                <div className="space-y-2 pt-2 border-t border-gray-50 text-xs text-gray-600">
                  <div className="flex items-center gap-2">
                    <Mail className="w-3.5 h-3.5 text-gray-400 shrink-0" />
                    <span className="truncate">{client.email}</span>
                  </div>
                  {client.phone && (
                    <div className="flex items-center gap-2">
                      <Phone className="w-3.5 h-3.5 text-gray-400 shrink-0" />
                      <span>{client.phone}</span>
                    </div>
                  )}
                  {client.country && (
                    <div className="flex items-center gap-2">
                      <Globe className="w-3.5 h-3.5 text-gray-400 shrink-0" />
                      <span>{client.country}</span>
                    </div>
                  )}
                </div>

                {/* Notes panel */}
                {client.notes && (
                  <div className="bg-gray-50 p-2.5 rounded-lg text-xs text-gray-500 italic mt-3 max-h-20 overflow-y-auto">
                    "{client.notes}"
                  </div>
                )}
              </div>

              {/* Action Operations Footer */}
              <div className="bg-gray-50 border-t border-gray-100 px-5 py-3 flex items-center justify-end gap-3">
                <button
                  onClick={() => handleOpenEdit(client)}
                  className="p-1 px-2.5 text-xs text-gray-650 hover:text-indigo-600 flex items-center gap-1 bg-white border border-gray-250 rounded-md transition hover:border-indigo-300 font-medium cursor-pointer"
                  id={`btn-edit-${client.id}`}
                >
                  <Edit className="w-3.5 h-3.5" />
                  Edit
                </button>
                <button
                  onClick={() => handleDeleteClient(client.id, client.clientName)}
                  className="p-1 px-2.5 text-xs text-rose-600 hover:text-rose-700 flex items-center gap-1 bg-white border border-rose-200 rounded-md transition hover:bg-rose-50 font-medium cursor-pointer"
                  id={`btn-delete-${client.id}`}
                >
                  <Trash2 className="w-3.5 h-3.5" />
                  Delete
                </button>
              </div>
            </div>
          ))}
        </div>
      )}

      {/* Styled slide over or clean overlay modal for Add/Edit Client */}
      {isModalOpen && (
        <div className="fixed inset-0 bg-black/50 backdrop-blur-xs flex items-center justify-center z-50 p-4 animate-fade-in" id="client-modal-overlay">
          <div className="bg-white w-full max-w-lg rounded-2xl shadow-xl border border-gray-100 overflow-hidden flex flex-col" id="client-modal-content">
            {/* Header */}
            <div className="px-6 py-4 border-b border-gray-100 flex items-center justify-between bg-gray-50">
              <h3 className="text-base font-bold text-gray-900">
                {editingClient ? 'Revise Client Profile' : 'Initiate New Client Record'}
              </h3>
              <button
                onClick={() => setIsModalOpen(false)}
                className="p-1.5 hover:bg-gray-200 text-gray-500 rounded-lg transition"
                id="btn-close-modal"
              >
                <X className="w-4.5 h-4.5" />
              </button>
            </div>

            {/* Form */}
            <form onSubmit={handleSaveClient} className="p-6 space-y-4 overflow-y-auto max-h-[80vh]">
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                <div className="col-span-1 sm:col-span-2">
                  <label className="block text-xs font-semibold text-gray-700 mb-1">Company Contact Name *</label>
                  <input
                    type="text"
                    required
                    value={formName}
                    onChange={(e) => setFormName(e.target.value)}
                    placeholder="e.g. Timothy Vance"
                    className="w-full bg-white text-gray-900 border border-gray-200 rounded-lg px-3 py-2 text-sm outline-none focus:border-indigo-500"
                    id="input-client-name"
                  />
                </div>

                <div>
                  <label className="block text-xs font-semibold text-gray-700 mb-1">Direct Work Email *</label>
                  <input
                    type="email"
                    required
                    value={formEmail}
                    onChange={(e) => setFormEmail(e.target.value)}
                    placeholder="e.g. timothy@vance.io"
                    className="w-full bg-white text-gray-900 border border-gray-200 rounded-lg px-3 py-2 text-sm outline-none focus:border-indigo-500"
                    id="input-client-email"
                  />
                </div>

                <div>
                  <label className="block text-xs font-semibold text-gray-700 mb-1">Phone Number</label>
                  <input
                    type="text"
                    value={formPhone}
                    onChange={(e) => setFormPhone(e.target.value)}
                    placeholder="e.g. +1 555-019-900"
                    className="w-full bg-white text-gray-900 border border-gray-200 rounded-lg px-3 py-2 text-sm outline-none focus:border-indigo-500"
                    id="input-client-phone"
                  />
                </div>

                <div>
                  <label className="block text-xs font-semibold text-gray-700 mb-1">Company / Entity Name</label>
                  <input
                    type="text"
                    value={formCompany}
                    onChange={(e) => setFormCompany(e.target.value)}
                    placeholder="e.g. Vance Creative Labs"
                    className="w-full bg-white text-gray-900 border border-gray-200 rounded-lg px-3 py-2 text-sm outline-none focus:border-indigo-500"
                    id="input-client-company"
                  />
                </div>

                <div>
                  <label className="block text-xs font-semibold text-gray-700 mb-1">Origin Country</label>
                  <input
                    type="text"
                    value={formCountry}
                    onChange={(e) => setFormCountry(e.target.value)}
                    placeholder="e.g. Canada"
                    className="w-full bg-white text-gray-900 border border-gray-200 rounded-lg px-3 py-2 text-sm outline-none focus:border-indigo-500"
                    id="input-client-country"
                  />
                </div>

                <div className="col-span-1 sm:col-span-2">
                  <label className="block text-xs font-semibold text-gray-700 mb-1">Client Pipeline Status</label>
                  <select
                    value={formStatus}
                    onChange={(e) => setFormStatus(e.target.value as ClientStatus)}
                    className="w-full bg-white text-gray-900 border border-gray-200 rounded-lg px-3 py-2 text-sm outline-none focus:border-indigo-500"
                    id="input-client-status"
                  >
                    <option value={ClientStatus.ACTIVE}>Active Partner (Ongoing Projects)</option>
                    <option value={ClientStatus.LEAD}>SaaS Lead / Prospect</option>
                    <option value={ClientStatus.INACTIVE}>Inactive Partner (Closed Account)</option>
                  </select>
                </div>

                <div className="col-span-1 sm:col-span-2">
                  <label className="block text-xs font-semibold text-gray-700 mb-1">Key Context Memorandums</label>
                  <textarea
                    rows={3}
                    value={formNotes}
                    onChange={(e) => setFormNotes(e.target.value)}
                    placeholder="Add brief memos. (e.g. Prefers slack, billing standard invoicing timelines 30-days net term etc.)"
                    className="w-full bg-white text-gray-900 border border-gray-200 rounded-lg px-3 py-2 text-sm outline-none focus:border-indigo-500 font-sans"
                    id="input-client-notes"
                  />
                </div>
              </div>

              {/* Action buttons */}
              <div className="pt-4 border-t border-gray-100 flex items-center justify-end gap-3">
                <button
                  type="button"
                  onClick={() => setIsModalOpen(false)}
                  className="px-4 py-2 text-sm font-semibold text-gray-700 hover:bg-gray-150 rounded-lg border border-gray-200 transition cursor-pointer"
                  id="btn-close-form"
                >
                  Cancel
                </button>
                <button
                  type="submit"
                  disabled={formSaving}
                  className="px-4 py-2 bg-indigo-600 hover:bg-indigo-700 text-white rounded-lg text-sm font-semibold transition inline-flex items-center gap-1 cursor-pointer disabled:opacity-50"
                  id="btn-submit-client"
                >
                  {formSaving && <Loader2 className="w-3.5 h-3.5 animate-spin" />}
                  {editingClient ? 'Apply Revisions' : 'Secure Register'}
                </button>
              </div>
            </form>
          </div>
        </div>
      )}
    </div>
  );
}
