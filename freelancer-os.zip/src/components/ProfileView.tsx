import React, { useState, useEffect } from 'react';
import { 
  User, 
  Building, 
  MapPin, 
  Mail, 
  Tag, 
  Save, 
  CheckCircle, 
  Loader2 
} from 'lucide-react';
import { useAuth } from '../contexts/AuthContext';

export default function ProfileView() {
  const { userProfile, updateProfileInfo } = useAuth();
  
  const [name, setName] = useState('');
  const [companyName, setCompanyName] = useState('');
  const [category, setCategory] = useState('');
  const [country, setCountry] = useState('');
  const [photoUrl, setPhotoUrl] = useState('');
  
  const [saving, setSaving] = useState(false);
  const [success, setSuccess] = useState(false);

  // Load from ctx
  useEffect(() => {
    if (userProfile) {
      setName(userProfile.name || '');
      setCompanyName(userProfile.companyName || '');
      setCategory(userProfile.freelancerCategory || '');
      setCountry(userProfile.country || '');
      setPhotoUrl(userProfile.profilePhoto || '');
    }
  }, [userProfile]);

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!name.trim()) {
      alert('Your Full Name is a required property.');
      return;
    }

    try {
      setSaving(true);
      setSuccess(false);
      await updateProfileInfo({
        name,
        companyName,
        freelancerCategory: category,
        country,
        profilePhoto: photoUrl
      });
      setSuccess(true);
      setTimeout(() => setSuccess(false), 4000);
    } catch (err) {
      console.error(err);
      alert('Failed to update your freelancer profile record.');
    } finally {
      setSaving(false);
    }
  };

  return (
    <div className="max-w-xl mx-auto space-y-6" id="profile-container">
      <div>
        <h2 className="text-2xl font-bold tracking-tight text-gray-950" id="profile-title">Professional Profile</h2>
        <p className="text-sm text-gray-500 mt-1 font-sans" id="profile-desc font-sans">Manage your freelancer brand representation, regional configurations, and invoice credentials.</p>
      </div>

      <div className="bg-white rounded-xl border border-gray-100 shadow-xs overflow-hidden" id="profile-card">
        {/* Banner */}
        <div className="h-28 bg-gradient-to-r from-indigo-500 to-violet-600 relative" id="profile-banner">
          <div className="absolute -bottom-10 left-6" id="profile-image-wrap">
            <img 
              src={photoUrl || 'https://api.dicebear.com/7.x/initials/svg?seed=Freelancer'} 
              alt="Profile avatar" 
              referrerPolicy="no-referrer"
              className="w-20 h-20 bg-white rounded-xl border-4 border-white shadow-md object-cover select-none"
            />
          </div>
        </div>

        {/* Form Container */}
        <form onSubmit={handleSubmit} className="p-6 pt-12 space-y-4" id="profile-form">
          <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
            <div className="col-span-1 sm:col-span-2">
              <label className="block text-xs font-semibold text-gray-700 mb-1">Full Brand Display Name *</label>
              <div className="relative">
                <User className="absolute left-3 top-2.5 w-4.5 h-4.5 text-gray-400" />
                <input
                  type="text"
                  required
                  value={name}
                  onChange={(e) => setName(e.target.value)}
                  placeholder="e.g. Timothy Vance"
                  className="w-full bg-white text-gray-900 border border-gray-200 rounded-lg pl-10 pr-3 py-2 text-sm outline-none focus:border-indigo-500"
                  id="profile-name-field"
                />
              </div>
            </div>

            <div>
              <label className="block text-xs font-semibold text-gray-700 mb-1">Registered Corporate Email (System Lock)</label>
              <div className="relative">
                <Mail className="absolute left-3 top-2.5 w-4.5 h-4.5 text-gray-400" />
                <input
                  type="email"
                  disabled
                  value={userProfile?.email || 'user@example.com'}
                  className="w-full bg-gray-50 text-gray-400 border border-gray-200 rounded-lg pl-10 pr-3 py-2 text-sm outline-none cursor-not-allowed"
                  id="profile-email-field"
                />
              </div>
            </div>

            <div>
              <label className="block text-xs font-semibold text-gray-700 mb-1">Registered Company Name</label>
              <div className="relative">
                <Building className="absolute left-3 top-2.5 w-4.5 h-4.5 text-gray-400" />
                <input
                  type="text"
                  value={companyName}
                  onChange={(e) => setCompanyName(e.target.value)}
                  placeholder="e.g. Timothy Vance consulting"
                  className="w-full bg-white text-gray-900 border border-gray-200 rounded-lg pl-10 pr-3 py-2 text-sm outline-none focus:border-indigo-500"
                  id="profile-company-field"
                />
              </div>
            </div>

            <div>
              <label className="block text-xs font-semibold text-gray-700 mb-1">Freelancer Category Industry</label>
              <div className="relative">
                <Tag className="absolute left-3 top-2.5 w-4.5 h-4.5 text-gray-400" />
                <input
                  type="text"
                  value={category}
                  onChange={(e) => setCategory(e.target.value)}
                  placeholder="e.g. Full-Stack Engineer"
                  className="w-full bg-white text-gray-900 border border-gray-200 rounded-lg pl-10 pr-3 py-2 text-sm outline-none focus:border-indigo-500"
                  id="profile-category-field"
                />
              </div>
            </div>

            <div>
              <label className="block text-xs font-semibold text-gray-700 mb-1">Country alignment</label>
              <div className="relative">
                <MapPin className="absolute left-3 top-2.5 w-4.5 h-4.5 text-gray-400" />
                <input
                  type="text"
                  value={country}
                  onChange={(e) => setCountry(e.target.value)}
                  placeholder="e.g. United Kingdom"
                  className="w-full bg-white text-gray-900 border border-gray-200 rounded-lg pl-10 pr-3 py-2 text-sm outline-none focus:border-indigo-500"
                  id="profile-country-field"
                />
              </div>
            </div>

            <div className="col-span-1 sm:col-span-2">
              <label className="block text-xs font-semibold text-gray-700 mb-1">Profile Photo Avatar URL</label>
              <input
                type="text"
                value={photoUrl}
                onChange={(e) => setPhotoUrl(e.target.value)}
                placeholder="Paste URL e.g. https://api.dicebear.com/..."
                className="w-full bg-white text-gray-900 border border-gray-200 rounded-lg px-3 py-2 text-sm outline-none focus:border-indigo-500"
                id="profile-avatar-field"
              />
            </div>
          </div>

          {/* Success indicators */}
          {success && (
            <div className="p-3 bg-emerald-50 border border-emerald-150 rounded-xl text-xs text-emerald-800 flex items-center gap-2" id="profile-success-prompt">
              <CheckCircle className="w-4.5 h-4.5 text-emerald-600" />
              <span>Great! Your professional profile modifications have been successfully written to Firebase Storage.</span>
            </div>
          )}

          {/* Operations row */}
          <div className="pt-4 border-t border-gray-50 flex justify-end" id="profile-actions">
            <button
              type="submit"
              disabled={saving}
              className="px-5 py-2.5 bg-indigo-600 hover:bg-indigo-700 text-white rounded-lg text-sm font-semibold transition inline-flex items-center gap-2 cursor-pointer disabled:opacity-50 font-sans"
              id="profile-save-btn"
            >
              {saving ? (
                <Loader2 className="w-4 h-4 animate-spin" />
              ) : (
                <Save className="w-4 h-4" />
              )}
              Save Specifications
            </button>
          </div>
        </form>
      </div>
    </div>
  );
}
