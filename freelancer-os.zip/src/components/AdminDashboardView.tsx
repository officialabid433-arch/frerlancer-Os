import React, { useEffect, useState } from 'react';
import { 
  Users, 
  CreditCard, 
  TrendingUp, 
  Briefcase, 
  FileText, 
  Activity as ActivityIcon, 
  ShieldAlert,
  Loader2 
} from 'lucide-react';
import { 
  getAllUsers, 
  getAllProjects, 
  getAllInvoices, 
  getAllPayments, 
  getSubscriptions, 
  getAllActivities 
} from '../services/db';
import { UserProfile, Project, Invoice, Payment, Subscription, Activity } from '../types';

export default function AdminDashboardView() {
  const [loading, setLoading] = useState(true);
  const [users, setUsers] = useState<UserProfile[]>([]);
  const [projects, setProjects] = useState<Project[]>([]);
  const [invoices, setInvoices] = useState<Invoice[]>([]);
  const [payments, setPayments] = useState<Payment[]>([]);
  const [subscriptions, setSubscriptions] = useState<Subscription[]>([]);
  const [activities, setActivities] = useState<Activity[]>([]);

  useEffect(() => {
    async function loadData() {
      try {
        setLoading(true);
        const [
          allUsers,
          allProj,
          allInv,
          allPay,
          allSubs,
          allAct
        ] = await Promise.all([
          getAllUsers(),
          getAllProjects(),
          getAllInvoices(),
          getAllPayments(),
          getSubscriptions(),
          getAllActivities()
        ]);
        
        setUsers(allUsers || []);
        setProjects(allProj || []);
        setInvoices(allInv || []);
        setPayments(allPay || []);
        setSubscriptions(allSubs || []);
        setActivities(allAct || []);
      } catch (err) {
        console.error("Failed to fetch admin dashboard statistics:", err);
      } finally {
        setLoading(false);
      }
    }
    loadData();
  }, []);

  if (loading) {
    return (
      <div className="flex flex-col items-center justify-center py-20" id="admin-dash-spinner">
        <Loader2 className="w-8 h-8 text-indigo-600 animate-spin" />
        <p className="text-xs text-gray-500 font-bold mt-2 uppercase font-mono tracking-wider">Gathering system intelligence...</p>
      </div>
    );
  }

  // Calculated metrics
  const activeUsersCount = users.filter(u => u.status !== 'suspended').length;
  const suspendedUsersCount = users.filter(u => u.status === 'suspended').length;
  const activeSubs = subscriptions.filter(s => s.status === 'active');
  const totalMRR = activeSubs.reduce((sum, s) => {
    // If yearly, split by 12
    const mAmount = s.billingCycle === 'yearly' ? s.price / 12 : s.price;
    return sum + mAmount;
  }, 0);

  const totalRevenue = payments
    .filter(p => p.paymentStatus === 'Paid')
    .reduce((sum, p) => sum + p.amount, 0);

  return (
    <div className="space-y-8 animate-fade-in font-sans" id="admin-dashboard-root">
      
      {/* Upper header */}
      <div className="flex flex-col md:flex-row md:items-center justify-between border-b border-gray-150 pb-5 gap-4">
        <div>
          <h1 className="text-2xl font-black text-gray-950 tracking-tight font-sans">System Diagnostics & SaaS Dashboard</h1>
          <p className="text-xs text-gray-500 mt-1 font-sans">Review SaaS system counters, billing MRR, active users and platform integrity status.</p>
        </div>
        <div className="flex items-center gap-2 bg-emerald-50 border border-emerald-150 px-3 py-1.5 rounded-full select-none">
          <span className="w-2 h-2 rounded-full bg-emerald-500 animate-ping"></span>
          <span className="text-[10px] uppercase font-mono font-bold text-emerald-800 tracking-wider">All Systems Operating Securely</span>
        </div>
      </div>

      {/* Metrics Row */}
      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-6" id="admin-kpis-grid">
        
        {/* KPI 1 */}
        <div className="bg-white p-6 border border-gray-150 rounded-2xl shadow-xs hover:shadow-sm transition" id="admin-card-users">
          <div className="flex justify-between items-start">
            <div>
              <span className="text-3xs uppercase font-extrabold tracking-wider text-gray-400 font-mono">Platform Members</span>
              <h3 className="text-3xl font-black text-gray-950 tracking-tight mt-1">{users.length}</h3>
            </div>
            <div className="p-2.5 bg-indigo-50 text-indigo-600 rounded-xl">
              <Users className="w-5 h-5" />
            </div>
          </div>
          <div className="flex items-center gap-3 mt-4 text-xs font-semibold">
            <span className="text-emerald-700 bg-emerald-50 px-2 py-0.5 rounded-full text-3xs font-mono font-bold">{activeUsersCount} Active</span>
            <span className="text-rose-700 bg-rose-50 px-2 py-0.5 rounded-full text-3xs font-mono font-bold">{suspendedUsersCount} Suspended</span>
          </div>
        </div>

        {/* KPI 2 */}
        <div className="bg-white p-6 border border-gray-150 rounded-2xl shadow-xs hover:shadow-sm transition" id="admin-card-mrr">
          <div className="flex justify-between items-start">
            <div>
              <span className="text-3xs uppercase font-extrabold tracking-wider text-gray-400 font-mono">Monthly Recurring Revenue</span>
              <h3 className="text-3xl font-black text-gray-950 tracking-tight mt-1">
                ${totalMRR.toLocaleString('en-US', { minimumFractionDigits: 2, maximumFractionDigits: 2 })}
              </h3>
            </div>
            <div className="p-2.5 bg-emerald-50 text-emerald-600 rounded-xl">
              <TrendingUp className="w-5 h-5" />
            </div>
          </div>
          <p className="text-xs text-gray-400 mt-4 font-semibold font-mono">Based on {activeSubs.length} Active SLA plans</p>
        </div>

        {/* KPI 3 */}
        <div className="bg-white p-6 border border-gray-150 rounded-2xl shadow-xs hover:shadow-sm transition" id="admin-card-subs">
          <div className="flex justify-between items-start">
            <div>
              <span className="text-3xs uppercase font-extrabold tracking-wider text-gray-400 font-mono">SLA Subscriptions</span>
              <h3 className="text-3xl font-black text-gray-950 tracking-tight mt-1">{subscriptions.length}</h3>
            </div>
            <div className="p-2.5 bg-amber-50 text-amber-600 rounded-xl">
              <CreditCard className="w-5 h-5" />
            </div>
          </div>
          <div className="flex items-center gap-1.5 mt-4 text-xs font-semibold">
            <span className="text-gray-500 font-medium">Accumulated billing:</span>
            <span className="text-gray-900 font-bold">${totalRevenue.toLocaleString('en-US')} USD</span>
          </div>
        </div>

        {/* KPI 4 */}
        <div className="bg-white p-6 border border-gray-150 rounded-2xl shadow-xs hover:shadow-sm transition" id="admin-card-assets">
          <div className="flex justify-between items-start">
            <div>
              <span className="text-3xs uppercase font-extrabold tracking-wider text-gray-400 font-mono">Distributed Entities</span>
              <h3 className="text-3xl font-black text-gray-950 tracking-tight mt-1">{projects.length + invoices.length}</h3>
            </div>
            <div className="p-2.5 bg-sky-50 text-sky-600 rounded-xl">
              <Briefcase className="w-5 h-5" />
            </div>
          </div>
          <div className="flex items-center gap-3 mt-4 text-xs font-semibold">
            <span className="text-gray-500 font-bold font-mono text-3xs bg-gray-100 px-2 py-0.5 rounded-full">{projects.length} Projects</span>
            <span className="text-gray-500 font-bold font-mono text-3xs bg-gray-100 px-2 py-0.5 rounded-full">{invoices.length} Invoices</span>
          </div>
        </div>

      </div>

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
        
        {/* Subscriptions Overview Breakdown */}
        <div className="bg-white p-6 border border-gray-150 rounded-2xl lg:col-span-1 space-y-4" id="admin-plans-overview">
          <h2 className="text-sm font-bold text-gray-900 tracking-tight uppercase font-mono text-gray-500">Plan Matrix Breakdown</h2>
          
          <div className="space-y-3 pt-2">
            {['Starter', 'Grower', 'Professional', 'Enterprise'].map(p => {
              const count = subscriptions.filter(s => s.plan === p && s.status === 'active').length;
              const percent = subscriptions.length > 0 ? (count / subscriptions.length) * 100 : 0;
              
              return (
                <div key={p} className="space-y-1">
                  <div className="flex justify-between items-center text-xs">
                    <span className="font-bold text-gray-700">{p} License</span>
                    <span className="font-mono text-gray-500">{count} active / {percent.toFixed(0)}%</span>
                  </div>
                  <div className="w-full bg-gray-100 h-1.5 rounded-full overflow-hidden">
                    <div className="bg-indigo-600 h-full rounded-full" style={{ width: `${percent}%` }}></div>
                  </div>
                </div>
              );
            })}
          </div>
        </div>

        {/* Global Activity Log Ledger - REAL TIME FEED */}
        <div className="bg-white p-6 border border-gray-150 rounded-2xl lg:col-span-2 space-y-4" id="admin-recent-ledger">
          <div className="flex justify-between items-center">
            <h2 className="text-sm font-bold text-gray-900 tracking-tight uppercase font-mono text-gray-500 flex items-center gap-2">
              <ActivityIcon className="w-4 h-4 text-indigo-600" />
              Recent Audit Log Ledger
            </h2>
            <span className="text-[10px] font-mono text-indigo-650 bg-indigo-50 font-bold px-2 py-0.5 rounded-full">
              Latest {activities.length} System Records
            </span>
          </div>

          <div className="divide-y divide-gray-100 max-h-[290px] overflow-y-auto pr-2 space-y-3 pt-1">
            {activities.length === 0 ? (
              <div className="py-12 text-center text-xs text-gray-400 font-semibold">
                No system activity events recorded in system metrics logs.
              </div>
            ) : (
              activities.map((act) => (
                <div key={act.id} className="pt-3 first:pt-0 flex items-start gap-3.5 text-xs">
                  <div className={`p-1.5 rounded-lg shrink-0 mt-0.5 ${
                    act.type === 'auth' ? 'bg-indigo-50 text-indigo-600' :
                    act.type === 'payment' ? 'bg-emerald-50 text-emerald-600' : 'bg-gray-50 text-gray-650'
                  }`}>
                    {act.type === 'auth' ? <Users className="w-3.5 h-3.5" /> : <Loader2 className="w-3.5 h-3.5" />}
                  </div>
                  <div className="flex-1 min-w-0">
                    <p className="text-gray-800 font-bold leading-normal">{act.description}</p>
                    <div className="flex items-center gap-2 mt-1 text-[10px] text-gray-400 font-mono font-semibold">
                      <span>USER_ID: {act.userId}</span>
                      <span>•</span>
                      <span>{act.createdAt?.seconds ? new Date(act.createdAt.seconds * 1000).toLocaleString() : 'Just now'}</span>
                    </div>
                  </div>
                </div>
              ))
            )}
          </div>
        </div>

      </div>

    </div>
  );
}
