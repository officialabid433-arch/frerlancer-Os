import React, { useEffect, useState } from 'react';
import { 
  CreditCard, 
  Plus, 
  Trash2, 
  Edit, 
  Loader2, 
  X, 
  Euro, 
  UserPlus, 
  CheckCircle2, 
  AlertTriangle 
} from 'lucide-react';
import { 
  getSubscriptions, 
  addSubscription, 
  updateSubscription, 
  deleteSubscription, 
  getAllUsers,
  logActivity 
} from '../services/db';
import { Subscription, UserProfile, ActivityType } from '../types';
import { useAuth } from '../contexts/AuthContext';

export default function AdminSubscriptionsView() {
  const { adminProfile } = useAuth();
  const [subscriptions, setSubscriptions] = useState<Subscription[]>([]);
  const [users, setUsers] = useState<UserProfile[]>([]);
  const [loading, setLoading] = useState(true);
  const [modalOpen, setModalOpen] = useState(false);
  const [actionLoading, setActionLoading] = useState<string | null>(null);

  // New Subscription Forms Schema States
  const [targetUserId, setTargetUserId] = useState('');
  const [targetEmail, setTargetEmail] = useState('');
  const [selectedPlan, setSelectedPlan] = useState<'Starter' | 'Grower' | 'Professional' | 'Enterprise'>('Starter');
  const [billingCycle, setBillingCycle] = useState<'monthly' | 'yearly'>('monthly');
  const [subStatus, setSubStatus] = useState<'active' | 'cancelled' | 'expired' | 'trialing'>('active');

  const [editingSubId, setEditingSubId] = useState<string | null>(null);

  const [success, setSuccess] = useState('');
  const [error, setError] = useState('');

  const loadData = async () => {
    try {
      setLoading(true);
      const [allSubs, allUsers] = await Promise.all([
        getSubscriptions(),
        getAllUsers()
      ]);
      setSubscriptions(allSubs || []);
      setUsers(allUsers || []);
      if (allUsers?.length > 0) {
        setTargetUserId(allUsers[0].userId);
        setTargetEmail(allUsers[0].email);
      }
    } catch (err: any) {
      console.error(err);
      setError('Failed to gather subscription metrics and rosters.');
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    loadData();
  }, []);

  const handleUserSelect = (uid: string) => {
    setTargetUserId(uid);
    const selected = users.find(u => u.userId === uid);
    if (selected) {
      setTargetEmail(selected.email);
    }
  };

  const handleSaveSubscription = async (e: React.FormEvent) => {
    e.preventDefault();
    setError('');
    setSuccess('');
    
    if (!targetUserId || !targetEmail) {
      setError('Please assign a target client profile user.');
      return;
    }

    // Determine premium price tags
    const planPrices = {
      'Starter': 19,
      'Grower': 49,
      'Professional': 99,
      'Enterprise': 249
    };
    
    let planPrice = planPrices[selectedPlan];
    if (billingCycle === 'yearly') {
      planPrice = planPrice * 10; // 2 months off pricing discount
    }

    try {
      setActionLoading('save');
      if (editingSubId) {
        // Edit Mode
        await updateSubscription(editingSubId, {
          userId: targetUserId,
          userEmail: targetEmail,
          plan: selectedPlan,
          price: planPrice,
          billingCycle,
          status: subStatus
        });

        setSubscriptions(prev => prev.map(s => s.id === editingSubId ? {
          ...s,
          userId: targetUserId,
          userEmail: targetEmail,
          plan: selectedPlan,
          price: planPrice,
          billingCycle,
          status: subStatus,
          updatedAt: new Date()
        } : s));

        await logActivity(
          adminProfile?.adminId || 'system-admin',
          `Modified subscription details for user ${targetEmail} (Plan: ${selectedPlan})`,
          ActivityType.PROJECT
        );

        setSuccess('Subscription records revised successfully.');
      } else {
        // Create Mode
        const created = await addSubscription({
          userId: targetUserId,
          userEmail: targetEmail,
          plan: selectedPlan,
          price: planPrice,
          billingCycle,
          status: subStatus
        });

        setSubscriptions(prev => [created, ...prev]);

        await logActivity(
          adminProfile?.adminId || 'system-admin',
          `Issued new subscription licenses to user ${targetEmail} (Plan: ${selectedPlan})`,
          ActivityType.PROJECT
        );

        setSuccess('New subscription license allocated successfully.');
      }

      setModalOpen(false);
      resetForm();
    } catch (err: any) {
      console.error(err);
      setError(err?.message || 'Transaction assignment aborted.');
    } finally {
      setActionLoading(null);
    }
  };

  const startEdit = (sub: Subscription) => {
    setEditingSubId(sub.id);
    setTargetUserId(sub.userId);
    setTargetEmail(sub.userEmail);
    setSelectedPlan(sub.plan);
    setBillingCycle(sub.billingCycle);
    setSubStatus(sub.status);
    setModalOpen(true);
  };

  const handleDeleteSub = async (id: string, email: string) => {
    if (!window.confirm(`Are you sure you want to revoke the subscription license of ${email}?`)) {
      return;
    }

    try {
      setError('');
      setActionLoading('delete-' + id);
      await deleteSubscription(id);
      
      setSubscriptions(prev => prev.filter(s => s.id !== id));

      await logActivity(
        adminProfile?.adminId || 'system-admin',
        `Terminated and deleted subscription license ${id} of user ${email}`,
        ActivityType.PROJECT
      );

      setSuccess('Subscription license revoked successfully.');
    } catch (err: any) {
      console.error(err);
      setError('Revocation transaction failed.');
    } finally {
      setActionLoading(null);
    }
  };

  const resetForm = () => {
    setEditingSubId(null);
    if (users?.length > 0) {
      setTargetUserId(users[0].userId);
      setTargetEmail(users[0].email);
    } else {
      setTargetUserId('');
      setTargetEmail('');
    }
    setSelectedPlan('Starter');
    setBillingCycle('monthly');
    setSubStatus('active');
  };

  return (
    <div className="space-y-6 animate-fade-in font-sans" id="admin-subscriptions-root">
      
      <div className="flex flex-col md:flex-row md:items-center justify-between border-b border-gray-150 pb-5 gap-4">
        <div>
          <h1 className="text-2xl font-black text-gray-950 tracking-tight">Active License Plans & Sales Ledger</h1>
          <p className="text-xs text-gray-500 mt-1">Oversee current client active profiles payment SLA logs, provision or terminate premium product subscriptions manually.</p>
        </div>
        <button
          onClick={() => { resetForm(); setModalOpen(true); }}
          className="w-full md:w-auto px-5 py-2.5 bg-indigo-600 hover:bg-indigo-700 text-white rounded-xl text-xs font-bold transition flex items-center justify-center gap-1.5 shadow-md cursor-pointer select-none"
        >
          <Plus className="w-4 h-4" />
          <span>Provision SLA License</span>
        </button>
      </div>

      {success && (
        <div className="p-3 bg-emerald-50 border border-emerald-150 rounded-xl text-xs text-emerald-850 font-semibold">
          {success}
        </div>
      )}

      {error && (
        <div className="p-3 bg-rose-50 border border-rose-150 rounded-xl text-xs text-rose-850 font-semibold">
          {error}
        </div>
      )}

      {loading ? (
        <div className="flex justify-center py-20" id="subs-loading">
          <Loader2 className="w-8 h-8 text-indigo-650 animate-spin" />
        </div>
      ) : (
        <div className="bg-white border border-gray-150 rounded-2xl overflow-hidden shadow-xs" id="subs-list-wrapper">
          <div className="overflow-x-auto">
            <table className="w-full text-left border-collapse" id="admin-subs-table">
              <thead>
                <tr className="bg-gray-50 border-b border-gray-150 text-[10px] font-extrabold text-gray-400 uppercase select-none">
                  <th className="p-4 px-6">Subscriber Account</th>
                  <th className="p-4">Assigned Plan</th>
                  <th className="p-4">Paid Price Tag</th>
                  <th className="p-4">Cash Billing Cycle</th>
                  <th className="p-4">SLA License Status</th>
                  <th className="p-4 text-right px-6">Modifications</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-gray-150 text-xs">
                {subscriptions.length === 0 ? (
                  <tr>
                    <td colSpan={6} className="p-12 text-center text-gray-400 font-semibold">
                      No customer account has been provisioned a subscription license.
                    </td>
                  </tr>
                ) : (
                  subscriptions.map((sub) => (
                    <tr key={sub.id} className="hover:bg-gray-50/50 transition">
                      
                      <td className="p-4 px-6">
                        <div className="font-bold text-gray-900">{sub.userEmail}</div>
                        <span className="text-[10px] font-mono text-gray-450 uppercase tracking-widest font-bold">CLIENT U_ID: {sub.userId.slice(0, 8)}...</span>
                      </td>

                      <td className="p-4">
                        <span className="bg-indigo-50 border border-indigo-150 text-indigo-805 text-[10px] font-extrabold px-2.5 py-0.5 rounded-full uppercase">
                          {sub.plan} Plan
                        </span>
                      </td>

                      <td className="p-4 font-bold text-gray-900">
                        ${sub.price.toFixed(2)} USD
                      </td>

                      <td className="p-4 text-gray-500 font-bold capitalize">
                        {sub.billingCycle}
                      </td>

                      <td className="p-4">
                        <span className={`inline-flex items-center gap-1 px-2 py-0.5 rounded-full text-[10px] font-mono font-bold uppercase border ${
                          sub.status === 'active' ? 'bg-emerald-50 border-emerald-150 text-emerald-800' :
                          sub.status === 'trialing' ? 'bg-blue-50 border-blue-150 text-blue-800' :
                          'bg-amber-50 border-amber-105 text-amber-800'
                        }`}>
                          {sub.status}
                        </span>
                      </td>

                      <td className="p-4 text-right px-6 space-x-2">
                        <button
                          onClick={() => startEdit(sub)}
                          className="p-1.5 bg-gray-50 hover:bg-gray-100 border border-gray-200 text-gray-700 rounded-lg transition cursor-pointer select-none"
                          title="Revise records"
                          id={`btn-edit-sub-${sub.id}`}
                        >
                          <Edit className="w-3.5 h-3.5" />
                        </button>
                        <button
                          onClick={() => handleDeleteSub(sub.id, sub.userEmail)}
                          disabled={actionLoading !== null}
                          className="p-1.5 bg-rose-50 hover:bg-rose-100 border border-rose-150 text-rose-700 rounded-lg transition cursor-pointer select-none"
                          title="Revoke license"
                          id={`btn-delete-sub-${sub.id}`}
                        >
                          {actionLoading === 'delete-' + sub.id ? (
                            <Loader2 className="w-3.5 h-3.5 animate-spin" />
                          ) : (
                            <Trash2 className="w-3.5 h-3.5 text-rose-800" />
                          )}
                        </button>
                      </td>

                    </tr>
                  ))
                )}
              </tbody>
            </table>
          </div>
        </div>
      )}

      {/* SLA PROVISIONING SYSTEM MODAL BOX */}
      {modalOpen && (
        <div className="fixed inset-0 bg-black/60 backdrop-blur-xs flex items-center justify-center p-4 z-50">
          <div className="bg-white rounded-2xl w-full max-w-md overflow-hidden shadow-2xl border border-gray-100 animate-scale-up">
            
            <div className="p-5 border-b border-gray-100 flex justify-between items-center bg-gray-50/50 select-none">
              <h3 className="font-extrabold text-sm uppercase font-mono tracking-wider text-gray-700">
                {editingSubId ? 'Update Assigned License' : 'Provision Premium License'}
              </h3>
              <button 
                onClick={() => setModalOpen(false)}
                className="p-1 hover:bg-gray-200 text-gray-400 rounded-lg transition cursor-pointer"
              >
                <X className="w-4.5 h-4.5" />
              </button>
            </div>

            <form onSubmit={handleSaveSubscription} className="p-5 space-y-4">
              
              {/* User Selection */}
              <div>
                <label className="block text-3xs font-extrabold text-gray-400 uppercase tracking-widest mb-1.5">Select Roster User Account *</label>
                <select
                  disabled={editingSubId !== null}
                  value={targetUserId}
                  onChange={(e) => handleUserSelect(e.target.value)}
                  className="w-full bg-white text-gray-900 border border-gray-200 rounded-lg p-2.5 text-xs outline-none focus:border-indigo-500 font-semibold"
                >
                  {users.length === 0 ? (
                    <option value="">No platform users registered.</option>
                  ) : (
                    users.map(u => (
                      <option key={u.userId} value={u.userId}>{u.email} ({u.name})</option>
                    ))
                  )}
                </select>
              </div>

              {/* Plans Grid Selection */}
              <div>
                <label className="block text-3xs font-extrabold text-gray-400 uppercase tracking-widest mb-1.5">Select Premium Tier Plan *</label>
                <div className="grid grid-cols-2 gap-2 text-xs font-bold leading-none select-none">
                  {['Starter', 'Grower', 'Professional', 'Enterprise'].map((p) => (
                    <button
                      key={p}
                      type="button"
                      onClick={() => setSelectedPlan(p as any)}
                      className={`p-3 rounded-xl border text-left flex flex-col gap-1 cursor-pointer transition ${
                        selectedPlan === p 
                          ? 'border-indigo-600 bg-indigo-50/55 text-indigo-900' 
                          : 'border-gray-200 border-dashed text-gray-700 hover:bg-gray-50'
                      }`}
                    >
                      <span className="text-[10px] font-extrabold uppercase">{p}</span>
                      <span className="text-gray-450 font-mono text-3xs">
                        {p === 'Starter' && '$19/mo'}
                        {p === 'Grower' && '$49/mo'}
                        {p === 'Professional' && '$99/mo'}
                        {p === 'Enterprise' && '$249/mo'}
                      </span>
                    </button>
                  ))}
                </div>
              </div>

              {/* Billing Cycle */}
              <div>
                <label className="block text-3xs font-extrabold text-gray-400 uppercase tracking-widest mb-1.5">Cash Billing Cycle *</label>
                <div className="flex gap-4 select-none">
                  <label className="flex items-center gap-2 cursor-pointer text-xs font-semibold text-gray-700">
                    <input
                      type="radio"
                      name="billingCycle"
                      value="monthly"
                      checked={billingCycle === 'monthly'}
                      onChange={() => setBillingCycle('monthly')}
                      className="accent-indigo-600"
                    />
                    <span>Monthly</span>
                  </label>
                  <label className="flex items-center gap-2 cursor-pointer text-xs font-semibold text-gray-700">
                    <input
                      type="radio"
                      name="billingCycle"
                      value="yearly"
                      checked={billingCycle === 'yearly'}
                      onChange={() => setBillingCycle('yearly')}
                      className="accent-indigo-600"
                    />
                    <span>Yearly (Save 2 Months Discount!)</span>
                  </label>
                </div>
              </div>

              {/* Status */}
              <div>
                <label className="block text-3xs font-extrabold text-gray-400 uppercase tracking-widest mb-1.5">State Status</label>
                <select
                  value={subStatus}
                  onChange={(e) => setSubStatus(e.target.value as any)}
                  className="w-full bg-white text-gray-900 border border-gray-200 rounded-lg p-2 text-xs outline-none focus:border-indigo-500 font-semibold capitalize"
                >
                  <option value="active">active</option>
                  <option value="trialing">trialing</option>
                  <option value="cancelled">cancelled</option>
                  <option value="expired">expired</option>
                </select>
              </div>

              <div className="pt-2">
                <button
                  type="submit"
                  disabled={actionLoading === 'save'}
                  className="w-full py-2.5 px-4 bg-indigo-600 hover:bg-indigo-700 text-white font-extrabold text-xs uppercase font-mono tracking-wider rounded-xl cursor-pointer shadow-md transition flex items-center justify-center gap-1.5"
                >
                  {actionLoading === 'save' ? (
                    <Loader2 className="w-4 h-4 animate-spin" />
                  ) : (
                    <>
                      <CheckCircle2 className="w-4 h-4 shrink-0" />
                      <span>{editingSubId ? 'Save Revisions' : 'Provision SLA Client'}</span>
                    </>
                  )}
                </button>
              </div>

            </form>

          </div>
        </div>
      )}

    </div>
  );
}
