import React, { useState, useEffect } from 'react';
import { 
  getInvoices, 
  getProjects, 
  getClients 
} from '../services/db';
import { 
  getEmailLogs, 
  triggerPaymentReminderNotification, 
  triggerDeadlineApproachingNotification,
  sendTransactionalEmail
} from '../services/emailService';
import { useAuth } from '../contexts/AuthContext';
import { NotificationEmail, Invoice, Project, Client, PaymentStatus, ProjectStatus } from '../types';
import { 
  Mail, 
  Send, 
  AlertTriangle, 
  FileText, 
  CheckCircle, 
  Clock, 
  Search, 
  Calendar, 
  ChevronRight, 
  RefreshCw, 
  Info,
  ExternalLink
} from 'lucide-react';

export default function NotificationsView() {
  const { user } = useAuth();
  
  // App states
  const [emails, setEmails] = useState<NotificationEmail[]>([]);
  const [invoices, setInvoices] = useState<Invoice[]>([]);
  const [projects, setProjects] = useState<Project[]>([]);
  const [clients, setClients] = useState<Client[]>([]);
  const [loading, setLoading] = useState(true);
  const [triggering, setTriggering] = useState<string | null>(null);
  
  // Interactive form states
  const [selectedInvoiceId, setSelectedInvoiceId] = useState('');
  const [selectedProjectId, setSelectedProjectId] = useState('');
  const [selectedMail, setSelectedMail] = useState<NotificationEmail | null>(null);

  // Search filter
  const [searchTerm, setSearchTerm] = useState('');

  // Fetch all relevant data
  const loadData = async () => {
    if (!user) return;
    setLoading(true);
    try {
      const [emailLogs, invoiceList, projectList, clientList] = await Promise.all([
        getEmailLogs(user.uid),
        getInvoices(user.uid),
        getProjects(user.uid),
        getClients(user.uid)
      ]);
      setEmails(emailLogs);
      setInvoices(invoiceList);
      setProjects(projectList);
      setClients(clientList);
    } catch (err) {
      console.error("Error retrieving notification metrics:", err);
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    loadData();
  }, [user]);

  // Helpers for identifying approaching project deadline
  const calculateDaysLeft = (deadlineStr: string): number => {
    try {
      const deadline = new Date(deadlineStr);
      const today = new Date();
      // Set to midnight to align calculation boundaries
      deadline.setHours(0,0,0,0);
      today.setHours(0,0,0,0);
      const diffMs = deadline.getTime() - today.getTime();
      return Math.ceil(diffMs / (1000 * 60 * 60 * 24));
    } catch {
      return 999;
    }
  };

  const getApproachingDeadlineProjects = () => {
    return projects.filter(p => {
      if (p.status === ProjectStatus.COMPLETED || p.status === ProjectStatus.CANCELLED) return false;
      const days = calculateDaysLeft(p.deadline);
      return days >= 0 && days <= 5; // Projects due within five days
    });
  };

  const getOverdueInvoices = () => {
    return invoices.filter(inv => inv.status !== PaymentStatus.PAID);
  };

  // manual notification triggers
  const handleTriggerPaymentReminder = async () => {
    if (!user || !selectedInvoiceId) return;
    setTriggering('payment_reminder');
    try {
      const resp = await triggerPaymentReminderNotification(user.uid, selectedInvoiceId);
      if (resp) {
        // Success
        setSelectedInvoiceId('');
        await loadData();
      }
    } catch (err) {
      console.error(err);
    } finally {
      setTriggering(null);
    }
  };

  const handleTriggerDeadlineAlert = async () => {
    if (!user || !selectedProjectId) return;
    setTriggering('deadline');
    try {
      const project = projects.find(p => p.id === selectedProjectId);
      const daysLeft = project ? calculateDaysLeft(project.deadline) : 3;
      const resp = await triggerDeadlineApproachingNotification(user.uid, selectedProjectId, daysLeft);
      if (resp) {
        setSelectedProjectId('');
        await loadData();
      }
    } catch (err) {
      console.error(err);
    } finally {
      setTriggering(null);
    }
  };

  const handleAutoSweepDeadlines = async () => {
    if (!user) return;
    setTriggering('sweep');
    try {
      const closeProjects = getApproachingDeadlineProjects();
      let sentCount = 0;
      for (const proj of closeProjects) {
        const days = calculateDaysLeft(proj.deadline);
        const resp = await triggerDeadlineApproachingNotification(user.uid, proj.id, days);
        if (resp) sentCount++;
      }
      alert(`Automated deadline sweep complete! Dispatched notification reminders for ${sentCount} active projects.`);
      await loadData();
    } catch (err) {
      console.error(err);
    } finally {
      setTriggering(null);
    }
  };

  // Count indicators for KPIs
  const totalEmails = emails.length;
  const invoiceCreatesCount = emails.filter(e => e.triggerEvent === 'invoice_created').length;
  const paymentRecsCount = emails.filter(e => e.triggerEvent === 'payment_received').length;
  const remindersCount = emails.filter(e => e.triggerEvent === 'payment_reminder').length;
  const deadlineCount = emails.filter(e => e.triggerEvent === 'deadline_approaching').length;

  // Filter logs via query match
  const filteredEmails = emails.filter(m => {
    const query = searchTerm.toLowerCase();
    return (
      m.recipientEmail.toLowerCase().includes(query) ||
      m.recipientName.toLowerCase().includes(query) ||
      m.subject.toLowerCase().includes(query) ||
      m.triggerEvent.toLowerCase().includes(query)
    );
  });

  return (
    <div className="space-y-6" id="notifications-workspace" style={{ contentVisibility: 'auto' }}>
      
      {/* HEADER SECTION */}
      <div className="flex flex-col md:flex-row md:items-center justify-between gap-4 border-b border-gray-100 pb-5" id="notif-header">
        <div>
          <span className="text-2xs font-extrabold tracking-wider uppercase text-indigo-650 bg-indigo-50 px-2.5 py-1 rounded-full font-sans">
            Client Communication
          </span>
          <h1 className="text-2xl font-black text-gray-950 tracking-tight mt-1">
            Email Dispatch Center
          </h1>
          <p className="text-sm text-gray-500 mt-1">
            Audit automatic client communication logs, record transaction confirmations, or execute customized transactional reminders.
          </p>
        </div>
        <button
          onClick={loadData}
          disabled={loading}
          className="self-start md:self-center px-4 py-2 text-xs bg-white text-gray-700 border border-gray-150 rounded-xl hover:bg-gray-50 transition font-bold flex items-center gap-1.5 cursor-pointer shadow-xs disabled:opacity-50"
          id="btn-refresh-logs"
        >
          <RefreshCw className={`w-3.5 h-3.5 ${loading ? 'animate-spin' : ''}`} />
          Refresh Dispatch Console
        </button>
      </div>

      {/* KPI METRICS CARDS */}
      <div className="grid grid-cols-2 lg:grid-cols-5 gap-4" id="notif-kpis">
        <div className="bg-white p-4 rounded-xl border border-gray-100 flex items-center gap-4 shadow-xs" id="kpi-total-sent">
          <div className="p-3 bg-indigo-50 rounded-xl text-indigo-600">
            <Mail className="w-5 h-5" />
          </div>
          <div>
            <p className="text-2xs font-bold text-gray-400 uppercase tracking-widest">Total Triggers</p>
            <h4 className="text-xl font-black text-gray-950 leading-none mt-1">{totalEmails}</h4>
          </div>
        </div>

        <div className="bg-white p-4 rounded-xl border border-gray-100 flex items-center gap-4 shadow-xs" id="kpi-invoice-creates">
          <div className="p-3 bg-sky-50 rounded-xl text-sky-600">
            <FileText className="w-5 h-5" />
          </div>
          <div>
            <p className="text-2xs font-bold text-gray-400 uppercase tracking-widest">New Invoices</p>
            <h4 className="text-xl font-black text-gray-950 leading-none mt-1">{invoiceCreatesCount}</h4>
          </div>
        </div>

        <div className="bg-white p-4 rounded-xl border border-gray-100 flex items-center gap-4 shadow-xs" id="kpi-payment-received">
          <div className="p-3 bg-emerald-50 rounded-xl text-emerald-600">
            <CheckCircle className="w-5 h-5" />
          </div>
          <div>
            <p className="text-2xs font-bold text-gray-400 uppercase tracking-widest">Receipt confirms</p>
            <h4 className="text-xl font-black text-gray-950 leading-none mt-1">{paymentRecsCount}</h4>
          </div>
        </div>

        <div className="bg-white p-4 rounded-xl border border-gray-100 flex items-center gap-4 shadow-xs" id="kpi-payment-reminders">
          <div className="p-3 bg-amber-50 rounded-xl text-amber-600">
            <Clock className="w-5 h-5" />
          </div>
          <div>
            <p className="text-2xs font-bold text-gray-400 uppercase tracking-widest">Pay Reminders</p>
            <h4 className="text-xl font-black text-gray-950 leading-none mt-1">{remindersCount}</h4>
          </div>
        </div>

        <div className="bg-white p-4 rounded-xl border border-gray-100 col-span-2 lg:col-span-1 flex items-center gap-4 shadow-xs" id="kpi-deadlines">
          <div className="p-3 bg-rose-50 rounded-xl text-rose-600">
            <AlertTriangle className="w-5 h-5" />
          </div>
          <div>
            <p className="text-2xs font-bold text-gray-400 uppercase tracking-widest">Deadline alerts</p>
            <h4 className="text-xl font-black text-gray-950 leading-none mt-1">{deadlineCount}</h4>
          </div>
        </div>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6" id="notif-core-layout">
        
        {/* INTERACTIVE MANUAL TRIGGERS SHELF */}
        <div className="space-y-6 lg:col-span-1" id="notif-triggers-column">
          
          {/* TRIGGER 1: DUE DATE WARNINGS DECLARED ON ACTIVE PROJECTS */}
          <div className="bg-white p-5 rounded-2xl border border-gray-100 shadow-xs space-y-4" id="trigger-box-projects">
            <div className="flex items-center gap-2 border-b border-gray-50 pb-3">
              <div className="p-1.5 bg-rose-50 text-rose-600 rounded-lg">
                <AlertTriangle className="w-4 h-4" />
              </div>
              <h3 className="text-sm font-bold text-gray-900 tracking-tight">Project Deadline Warnings</h3>
            </div>

            <p className="text-xs text-gray-500 leading-relaxed">
              Triggers informational emails to clients alerting them that an active project baseline delivery timeline is fast approaching.
            </p>

            {/* QUICK SWEEP DECTECTOR */}
            {getApproachingDeadlineProjects().length > 0 ? (
              <div className="p-3 bg-rose-55/5 border border-rose-100 rounded-xl" id="deadline-sweep-reminder">
                <div className="flex items-start gap-2.5">
                  <Info className="w-3.5 h-3.5 text-rose-600 mt-0.5" />
                  <div className="space-y-1">
                    <p className="text-xs font-bold text-rose-950">
                      {getApproachingDeadlineProjects().length} Projects due soon (≤ 5d)
                    </p>
                    <p className="text-[10px] text-rose-700 leading-normal">
                      Scan project baselines instantly to trigger client notification alerts.
                    </p>
                    <button
                      onClick={handleAutoSweepDeadlines}
                      disabled={!!triggering}
                      className="mt-1.5 px-3 py-1 bg-rose-600 hover:bg-rose-700 text-white rounded-lg text-[10px] font-bold transition flex items-center gap-1 cursor-pointer disabled:opacity-50"
                      id="btn-sweep-now"
                    >
                      {triggering === 'sweep' ? 'Sweeping...' : 'Sweep & Alert Clients Now'}
                    </button>
                  </div>
                </div>
              </div>
            ) : (
              <div className="p-3 bg-emerald-55/5 border border-emerald-100 rounded-xl flex items-center gap-2" id="deadline-sweep-clean">
                <CheckCircle className="w-4 h-4 text-emerald-600" />
                <span className="text-[11px] font-medium text-emerald-800">
                  All active project timetables are in healthy standing.
                </span>
              </div>
            )}

            <div className="space-y-2 mt-2">
              <label className="text-[10px] font-extrabold text-gray-400 uppercase tracking-wider block">
                Deliverable Project Selection
              </label>
              <select
                value={selectedProjectId}
                onChange={(e) => setSelectedProjectId(e.target.value)}
                className="w-full text-xs p-2.5 bg-gray-50 border border-gray-200 rounded-xl focus:bg-white focus:ring-1 focus:ring-indigo-600"
                id="select-project-reminder"
              >
                <option value="">-- Choose active project --</option>
                {projects.map(p => (
                  <option key={p.id} value={p.id}>
                    {p.projectName} (Due: {p.deadline})
                  </option>
                ))}
              </select>
            </div>

            <button
              onClick={handleTriggerDeadlineAlert}
              disabled={!selectedProjectId || !!triggering}
              className="w-full py-2 bg-indigo-600 hover:bg-indigo-700 text-white rounded-xl text-xs font-bold transition flex items-center justify-center gap-1.5 disabled:opacity-50 disabled:cursor-not-allowed cursor-pointer"
              id="btn-trigger-deadline"
            >
              <Send className="w-3.5 h-3.5" />
              <span>{triggering === 'deadline' ? 'Sending...' : 'Dispatch Milestone Notification'}</span>
            </button>
          </div>

          {/* TRIGGER 2: OUTSTANDING INVOICES FOLLOW-UP PAYMENT REMINDERS */}
          <div className="bg-white p-5 rounded-2xl border border-gray-100 shadow-xs space-y-4" id="trigger-box-payments">
            <div className="flex items-center gap-2 border-b border-gray-50 pb-3">
              <div className="p-1.5 bg-amber-50 text-amber-600 rounded-lg">
                <Clock className="w-4 h-4" />
              </div>
              <h3 className="text-sm font-bold text-gray-900 tracking-tight">Unpaid Invoice Reminders</h3>
            </div>

            <p className="text-xs text-gray-500 leading-relaxed">
              Dispatch high-fidelity billing reminders urging your corporate client contacts to process outstanding cash invoices cleanly.
            </p>

            <div className="space-y-2">
              <label className="text-[10px] font-extrabold text-gray-400 uppercase tracking-wider block">
                Overdue Invoice Ledger
              </label>
              <select
                value={selectedInvoiceId}
                onChange={(e) => setSelectedInvoiceId(e.target.value)}
                className="w-full text-xs p-2.5 bg-gray-50 border border-gray-200 rounded-xl focus:bg-white focus:ring-1 focus:ring-indigo-600"
                id="select-invoice-reminder"
              >
                <option value="">-- Choose outstanding invoice --</option>
                {getOverdueInvoices().map(inv => (
                  <option key={inv.id} value={inv.id}>
                    {inv.invoiceNumber} - {inv.clientName} (${inv.totalAmount.toLocaleString()})
                  </option>
                ))}
              </select>
            </div>

            <button
              onClick={handleTriggerPaymentReminder}
              disabled={!selectedInvoiceId || !!triggering}
              className="w-full py-2 bg-amber-600 hover:bg-amber-700 text-white rounded-xl text-xs font-bold transition flex items-center justify-center gap-1.5 disabled:opacity-50 disabled:cursor-not-allowed cursor-pointer"
              id="btn-trigger-invoice"
            >
              <Send className="w-3.5 h-3.5" />
              <span>{triggering === 'payment_reminder' ? 'Sending...' : 'Dispatch Follow-up Reminder'}</span>
            </button>
          </div>

          {/* SIMULATION SUMMARY INFO NOTE */}
          <div className="bg-slate-900 text-slate-350 p-4 rounded-xl border border-slate-800 space-y-2">
            <div className="flex items-center gap-2 text-white">
              <Info className="w-4 h-4 text-emerald-450 shrink-0" />
              <h4 className="text-xs font-bold tracking-tight">Transactional Sandbox active</h4>
            </div>
            <p className="text-[11px] leading-relaxed">
              All emails are constructed strictly and registered via clean cloud database loggers. Your customers are logged safely and simulated in real time.
            </p>
          </div>

        </div>

        {/* LOG HISTORY GRID - TRANSACTION TIMELINE */}
        <div className="lg:col-span-2 space-y-4" id="notif-logs-column">
          
          {/* SEARCH BAR */}
          <div className="bg-white p-3.5 rounded-xl border border-gray-100 shadow-2xs flex items-center gap-3" id="notif-search-row">
            <Search className="w-4 h-4 text-gray-400" />
            <input
              type="text"
              placeholder="Search dispatch logs by recipient name, email subject, or trigger keyword..."
              value={searchTerm}
              onChange={(e) => setSearchTerm(e.target.value)}
              className="w-full text-xs text-gray-800 bg-transparent outline-none focus:placeholder-gray-300"
              id="notif-search-field"
            />
          </div>

          <div className="bg-white rounded-2xl border border-gray-100 shadow-xs overflow-hidden" id="notif-logs-table-wrapper">
            <div className="p-4 bg-gray-50 border-b border-gray-100 flex items-center justify-between">
              <h3 className="text-xs font-black text-gray-700 uppercase tracking-wider font-mono">
                Log Dispatch History
              </h3>
              <span className="text-3xs bg-indigo-100 text-indigo-800 px-2.5 py-0.5 rounded-full font-bold">
                Showing {filteredEmails.length} Outbound mailings
              </span>
            </div>

            {loading ? (
              <div className="p-12 text-center" id="notif-load-spinner">
                <RefreshCw className="w-8 h-8 text-indigo-650 animate-spin mx-auto" />
                <p className="text-xs text-gray-500 mt-2">Loading email transmission ledger...</p>
              </div>
            ) : filteredEmails.length === 0 ? (
              <div className="p-12 text-center text-gray-400 space-y-2" id="notif-load-empty">
                <Mail className="w-10 h-10 mx-auto text-gray-300" />
                <p className="text-sm font-semibold text-gray-800">No transactional dispatch records found</p>
                <p className="text-2xs text-gray-500 max-w-sm mx-auto">
                  Triggers fire instantly when you draft billing invoices, receive outstanding payments, or trigger manual warnings.
                </p>
              </div>
            ) : (
              <div className="divide-y divide-gray-55" id="notif-logs-list">
                {filteredEmails.map((mail) => {
                  
                  // Label details
                  let badgeBg = 'bg-gray-50 text-gray-700';
                  let badgeLabel = mail.triggerEvent;
                  if (mail.triggerEvent === 'invoice_created') {
                    badgeBg = 'bg-sky-50 text-sky-700 border-sky-100';
                    badgeLabel = 'New Invoice Bending';
                  } else if (mail.triggerEvent === 'payment_received') {
                    badgeBg = 'bg-emerald-50 text-emerald-700 border-emerald-100';
                    badgeLabel = 'Payment Receipt Confirmed';
                  } else if (mail.triggerEvent === 'payment_reminder') {
                    badgeBg = 'bg-amber-50 text-amber-700 border-amber-100';
                    badgeLabel = 'Payment Overdue Follow-up';
                  } else if (mail.triggerEvent === 'deadline_approaching') {
                    badgeBg = 'bg-rose-50 text-rose-700 border-rose-100';
                    badgeLabel = 'Timeline Milestone Approach';
                  }

                  const formattedDate = mail.sentAt ? 
                    new Date(mail.sentAt.seconds * 1000).toLocaleString() : 
                    new Date().toLocaleString();

                  return (
                    <div 
                      key={mail.id}
                      onClick={() => setSelectedMail(mail)}
                      className={`p-4 hover:bg-gray-50/70 transition-all cursor-pointer flex items-start justify-between gap-3 text-left ${selectedMail?.id === mail.id ? 'bg-indigo-50/30' : ''}`}
                    >
                      <div className="space-y-1 overflow-hidden">
                        <div className="flex flex-wrap items-center gap-1.5">
                          <span className={`text-[10px] font-bold px-2 py-0.5 rounded-full border ${badgeBg}`}>
                            {badgeLabel}
                          </span>
                          <span className="text-3xs text-gray-400 font-mono">
                            {formattedDate}
                          </span>
                        </div>
                        
                        <h4 className="text-xs font-bold text-gray-900 truncate">
                          {mail.subject}
                        </h4>
                        
                        <p className="text-2xs text-gray-500 font-sans">
                          To: <span className="font-bold text-gray-700">{mail.recipientName}</span> ( {mail.recipientEmail} )
                        </p>
                        
                        {mail.referenceNumber && (
                          <div className="flex items-center gap-1 text-3xs text-indigo-600 font-mono mt-1">
                            <span className="bg-indigo-50 px-1.5 py-0.2 rounded">Reference: {mail.referenceNumber}</span>
                          </div>
                        )}
                      </div>

                      <ChevronRight className="w-4 h-4 text-gray-300 mt-1 shrink-0" />
                    </div>
                  );
                })}
              </div>
            )}
          </div>

        </div>

      </div>

      {/* DISPATCH DETAIL LIGHTBOX MODAL */}
      {selectedMail && (
        <div className="fixed inset-0 bg-black/50 backdrop-blur-xs flex items-center justify-center z-50 p-4 transition-all animate-fade-in" id="modal-notif-detail">
          <div className="bg-white w-full max-w-2xl rounded-2xl shadow-xl border border-gray-100 overflow-hidden flex flex-col animate-scale-up">
            
            {/* Header */}
            <div className="p-4 bg-gray-50 border-b border-gray-150 flex items-center justify-between">
              <div>
                <span className="text-3xs font-bold font-mono tracking-widest text-indigo-600 uppercase bg-indigo-50 px-2 py-0.5 rounded-full border border-indigo-100">
                  Outbound transactional ledger details
                </span>
                <h3 className="text-sm font-black text-gray-900 mt-1 flex items-center gap-1.5">
                  <Mail className="w-4 h-4 text-gray-500" />
                  Inspect Communication Dispatch
                </h3>
              </div>
              <button
                onClick={() => setSelectedMail(null)}
                className="text-gray-400 hover:text-gray-700 text-xs font-extrabold focus:outline-none cursor-pointer"
                id="btn-close-notif-detail"
              >
                ✕ Close Preview
              </button>
            </div>

            {/* Meta */}
            <div className="p-4 bg-indigo-50/20 border-b border-indigo-50/10 grid grid-cols-1 md:grid-cols-2 gap-3 text-xs text-gray-600">
              <div className="space-y-1">
                <p><span className="font-bold text-gray-400">Recipient contact name:</span> <span className="text-gray-800 font-medium">{selectedMail.recipientName}</span></p>
                <p><span className="font-bold text-gray-400">Recipient email address:</span> <span className="text-gray-800 font-medium">{selectedMail.recipientEmail}</span></p>
              </div>
              <div className="space-y-1 md:border-l md:border-gray-100 md:pl-4">
                <p><span className="font-bold text-gray-400">Dispatch system state:</span> <span className="text-emerald-700 font-bold capitalize">● {selectedMail.status}</span></p>
                <p><span className="font-bold text-gray-400">Time of log emission:</span> <span className="text-gray-800 font-mono">{selectedMail.sentAt ? new Date(selectedMail.sentAt.seconds * 1000).toLocaleString() : new Date().toLocaleString()}</span></p>
              </div>
            </div>

            {/* Email Subject and Body preview box */}
            <div className="p-6 flex-1 overflow-y-auto max-h-[50vh] text-left space-y-4 font-sans bg-gray-50/30">
              <div>
                <p className="text-3xs font-extrabold font-mono text-gray-400 uppercase tracking-widest leading-none">Mail Topic</p>
                <h2 className="text-base font-black text-gray-900 mt-1.5 pb-2.5 border-b border-gray-100">
                  {selectedMail.subject}
                </h2>
              </div>

              <div>
                <p className="text-3xs font-extrabold font-mono text-gray-400 uppercase tracking-widest leading-none">Parsed Text Body</p>
                <div className="mt-2.5 bg-white p-5 border border-gray-150 rounded-xl whitespace-pre-wrap text-xs text-gray-700 leading-relaxed font-mono font-medium shadow-2xs">
                  {selectedMail.body}
                </div>
              </div>
            </div>

            {/* Footer triggers */}
            <div className="p-4 bg-gray-50 border-t border-gray-150 flex justify-end">
              <button
                onClick={() => setSelectedMail(null)}
                className="px-4 py-2 bg-gray-800 hover:bg-gray-950 text-white rounded-xl text-xs font-bold transition cursor-pointer"
                id="btn-close-lightbox"
              >
                Close Trace Log
              </button>
            </div>

          </div>
        </div>
      )}

    </div>
  );
}
