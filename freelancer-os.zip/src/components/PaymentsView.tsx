import React, { useState, useEffect } from 'react';
import { 
  CheckCircle, 
  XOctagon, 
  Clock, 
  Search, 
  Filter, 
  DollarSign, 
  CheckCircle2, 
  Loader2, 
  TrendingUp, 
  AlertTriangle 
} from 'lucide-react';
import { Payment, PaymentStatus } from '../types';
import { getPayments, updatePaymentStatus } from '../services/db';
import { useAuth } from '../contexts/AuthContext';

export default function PaymentsView() {
  const { user } = useAuth();
  const [payments, setPayments] = useState<Payment[]>([]);
  const [loading, setLoading] = useState(true);
  const [searchQuery, setSearchQuery] = useState('');
  const [statusFilter, setStatusFilter] = useState<string>('All');

  const loadPayments = async () => {
    if (!user) return;
    try {
      setLoading(true);
      const data = await getPayments(user.uid);
      setPayments(data);
    } catch (err) {
      console.error(err);
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    loadPayments();
  }, [user]);

  // Handle Changing status
  const handleTogglePayment = async (paymentId: string, invoiceId: string, currentStatus: PaymentStatus) => {
    if (!user) return;
    const nextStatus = currentStatus === PaymentStatus.PAID ? PaymentStatus.UNPAID : PaymentStatus.PAID;
    try {
      await updatePaymentStatus(user.uid, paymentId, invoiceId, nextStatus);
      await loadPayments();
    } catch (err) {
      console.error(err);
      alert('Failed to update receipt payment status: ' + (err instanceof Error ? err.message : String(err)));
    }
  };

  // Filtration
  const filteredPayments = payments.filter((pay) => {
    const matchSearch = pay.invoiceNumber.toLowerCase().includes(searchQuery.toLowerCase());
    const matchStatus = statusFilter === 'All' ? true : pay.paymentStatus === statusFilter;
    return matchSearch && matchStatus;
  });

  // Calculate high-fidelity figures
  const totalReceived = payments
    .filter(p => p.paymentStatus === PaymentStatus.PAID)
    .reduce((sum, p) => sum + p.amount, 0);

  const totalOutstanding = payments
    .filter(p => p.paymentStatus !== PaymentStatus.PAID)
    .reduce((sum, p) => sum + p.amount, 0);

  const collectionRate = payments.length > 0
    ? (totalReceived / (totalReceived + totalOutstanding)) * 100
    : 0;

  return (
    <div className="space-y-6" id="payments-view-container">
      {/* Header */}
      <div className="flex flex-col md:flex-row md:items-center md:justify-between gap-4" id="payments-view-header">
        <div>
          <h2 className="text-2xl font-bold tracking-tight text-gray-950" id="payments-title">Payment History & Ledger</h2>
          <p className="text-sm text-gray-500 mt-1" id="payments-desc">Keep active balance sheets, cross-reference billing invoices, and audit transactional collections.</p>
        </div>
      </div>

      {/* KPI Stats Widgets */}
      <div className="grid grid-cols-1 sm:grid-cols-3 gap-4" id="payments-kpis">
        <div className="bg-white p-4 rounded-xl border border-gray-100 flex items-center gap-4 shadow-xs" id="payment-kpi-total">
          <div className="p-3 bg-emerald-50 text-emerald-600 rounded-lg">
            <TrendingUp className="w-5 h-5" />
          </div>
          <div>
            <p className="text-xs text-gray-500 font-medium">Secured Billings (Collected)</p>
            <h3 className="text-xl font-bold text-gray-900 mt-0.5">${totalReceived.toLocaleString(undefined, { minimumFractionDigits: 2, maximumFractionDigits: 2 })}</h3>
          </div>
        </div>

        <div className="bg-white p-4 rounded-xl border border-gray-100 flex items-center gap-4 shadow-xs" id="payment-kpi-receivable">
          <div className="p-3 bg-amber-50 text-amber-600 rounded-lg">
            <AlertTriangle className="w-5 h-5" />
          </div>
          <div>
            <p className="text-xs text-gray-500 font-medium">Outstanding Accounts Receivable</p>
            <h3 className="text-xl font-bold text-gray-900 mt-0.5">${totalOutstanding.toLocaleString(undefined, { minimumFractionDigits: 2, maximumFractionDigits: 2 })}</h3>
          </div>
        </div>

        <div className="bg-white p-4 rounded-xl border border-gray-100 flex items-center gap-4 shadow-xs" id="payment-kpi-rate">
          <div className="p-3 bg-indigo-50 text-indigo-600 rounded-lg">
            <DollarSign className="w-5 h-5" />
          </div>
          <div>
            <p className="text-xs text-gray-500 font-medium">Collections Ratio rate</p>
            <h3 className="text-xl font-bold text-gray-900 mt-0.5">{collectionRate.toFixed(1)}%</h3>
          </div>
        </div>
      </div>

      {/* Search and filter toolbar */}
      <div className="flex flex-col sm:flex-row items-center gap-3 bg-white p-4 rounded-xl border border-gray-100 shadow-xs" id="payments-filter-bar">
        <div className="relative flex-1 w-full" id="search-payment-wrapper">
          <Search className="absolute left-3 top-2.5 h-4.5 w-4.5 text-gray-400" />
          <input
            type="text"
            placeholder="Search payments by invoice serial e.g., INV-1001..."
            value={searchQuery}
            onChange={(e) => setSearchQuery(e.target.value)}
            className="w-full bg-gray-50 text-gray-900 pl-10 pr-4 py-2 rounded-lg text-sm border border-gray-200 outline-none focus:border-indigo-500 font-sans"
            id="payment-search"
          />
        </div>
        <div className="flex items-center gap-2 w-full sm:w-auto" id="filter-payment-wrapper">
          <Filter className="w-4 h-4 text-gray-400" />
          <select
            value={statusFilter}
            onChange={(e) => setStatusFilter(e.target.value)}
            className="w-full sm:w-auto text-sm text-gray-700 bg-gray-50 border border-gray-200 rounded-lg px-3 py-2 cursor-pointer outline-none focus:border-indigo-500"
            id="payment-filter-status"
          >
            <option value="All">All statuses</option>
            <option value={PaymentStatus.PAID}>Paid</option>
            <option value={PaymentStatus.UNPAID}>Unpaid / Overdue</option>
          </select>
        </div>
      </div>

      {/* Ledger Table */}
      {loading ? (
        <div className="flex flex-col items-center justify-center p-12 bg-white rounded-xl border border-gray-100 shadow-xs" id="payments-loading">
          <Loader2 className="w-8 h-8 text-indigo-600 animate-spin" />
          <p className="text-sm text-gray-500 mt-2">Opening financial balance books...</p>
        </div>
      ) : filteredPayments.length === 0 ? (
        <div className="text-center p-12 bg-white rounded-xl border border-gray-100 shadow-xs animate-fade-in" id="payments-empty">
          <div className="w-12 h-12 bg-indigo-50 text-indigo-600 rounded-full flex items-center justify-center mx-auto mb-3">
            <CheckCircle2 className="w-6 h-6" />
          </div>
          <p className="text-base font-semibold text-gray-900">No payment records mapped</p>
          <p className="text-sm text-gray-500 mt-1 max-w-sm mx-auto">
            Payment records appear automatically as soon as you generate client billing invoices in Freelancer OS.
          </p>
        </div>
      ) : (
        <div className="bg-white rounded-xl border border-gray-100 shadow-xs overflow-hidden" id="payments-ledger-table-wrapper">
          <div className="overflow-x-auto text-sm text-gray-700">
            <table className="w-full text-left border-collapse" id="payments-ledger-table">
              <thead>
                <tr className="bg-gray-50 border-b border-gray-100 font-semibold text-gray-650 text-xs">
                  <th className="p-4 px-6">Invoice Serial</th>
                  <th className="p-4">Transaction Volume</th>
                  <th className="p-4">Billing Date Limit</th>
                  <th className="p-4 text-center">Settlement Status</th>
                  <th className="p-4 text-right px-6">Direct Reconciliation</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-gray-50">
                {filteredPayments.map((pay) => (
                  <tr key={pay.id} className="hover:bg-gray-50/50 transition">
                    <td className="p-4 px-6 font-bold text-gray-900">{pay.invoiceNumber}</td>
                    <td className="p-4 font-bold text-gray-800">${pay.amount.toLocaleString(undefined, { minimumFractionDigits: 2 })}</td>
                    <td className="p-4 text-xs text-gray-500">{pay.paymentDate}</td>
                    <td className="p-4 text-center">
                      <span 
                        className={`inline-flex items-center gap-1 px-3 py-0.5 rounded-full text-2xs font-bold uppercase tracking-wider ${
                          pay.paymentStatus === PaymentStatus.PAID 
                            ? 'bg-emerald-50 text-emerald-700 border border-emerald-150' 
                            : 'bg-rose-50 text-rose-700 border border-rose-150'
                        }`}
                      >
                        {pay.paymentStatus === PaymentStatus.PAID ? (
                          <CheckCircle className="w-3 h-3 text-emerald-600" />
                        ) : (
                          <Clock className="w-3 h-3 text-rose-500" />
                        )}
                        {pay.paymentStatus}
                      </span>
                    </td>
                    <td className="p-4 text-right px-6">
                      <button
                        onClick={() => handleTogglePayment(pay.id, pay.invoiceId, pay.paymentStatus)}
                        className={`p-1.5 px-3 rounded-lg text-2xs font-bold font-sans cursor-pointer transition flex items-center gap-1.5 ml-auto border ${
                          pay.paymentStatus === PaymentStatus.PAID
                            ? 'text-rose-600 hover:text-rose-800 bg-rose-50/50 border-rose-100 hover:border-rose-200'
                            : 'text-emerald-700 hover:text-emerald-900 bg-emerald-50/80 border-emerald-100 hover:border-emerald-200'
                        }`}
                        id={`btn-reconciliation-${pay.id}`}
                      >
                        {pay.paymentStatus === PaymentStatus.PAID ? (
                          <>
                            <XOctagon className="w-3 h-3" />
                            Mark Unpaid
                          </>
                        ) : (
                          <>
                            <CheckCircle2 className="w-3 h-3" />
                            Mark Paid
                          </>
                        )}
                      </button>
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </div>
      )}
    </div>
  );
}
