import React, { useState } from 'react';
import { useNavigate } from 'react-router-dom';
import { Lock, Mail, Loader2, ArrowRight, ArrowLeft, ShieldCheck } from 'lucide-react';
import { useAuth } from '../contexts/AuthContext';

export default function AdminLogin() {
  const { loginWithEmail, loginWithGoogle, role, userProfile } = useAuth();
  const navigate = useNavigate();
  
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [loading, setLoading] = useState(false);
  const [errorMessage, setErrorMessage] = useState('');

  const handleAdminSignIn = async (e: React.FormEvent) => {
    e.preventDefault();
    setErrorMessage('');
    if (!email.trim() || !password.trim()) {
      setErrorMessage('Please fill in both your admin email and password.');
      return;
    }

    try {
      setLoading(true);
      await loginWithEmail(email.trim(), password.trim());
      // Upon successful login, the AuthContext state updates.
      // We will redirect to /admin/dashboard in App.tsx or use a timeout/effect, but let's try pushing directly.
      setTimeout(() => {
        navigate('/admin/dashboard');
      }, 800);
    } catch (err: any) {
      console.error(err);
      setErrorMessage(err?.message || 'Access Denied. Invalid admin credentials.');
    } finally {
      setLoading(false);
    }
  };

  const handleGoogleAdmin = async () => {
    setErrorMessage('');
    try {
      setLoading(true);
      await loginWithGoogle();
      setTimeout(() => {
        navigate('/admin/dashboard');
      }, 800);
    } catch (err: any) {
      console.error(err);
      setErrorMessage(err?.message || 'Google verification canceled.');
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="min-h-screen bg-slate-950 text-white flex flex-col justify-center py-12 px-4 sm:px-6 lg:px-8 font-sans" id="admin-login-screen">
      {/* Brand Header */}
      <div className="sm:mx-auto sm:w-full sm:max-w-md text-center" id="admin-brand-header">
        <div className="inline-flex p-3 bg-indigo-500 text-white rounded-xl shadow-lg mb-4">
          <ShieldCheck className="w-8 h-8" />
        </div>
        <h1 className="text-3xl font-black tracking-tight text-white uppercase">Freelancer OS Admin</h1>
        <p className="text-sm text-slate-400 mt-2">
          Secure Administrative Gateway. Authorization Required.
        </p>
      </div>

      <div className="mt-8 sm:mx-auto sm:w-full sm:max-w-md" id="admin-login-card">
        <div className="bg-slate-900 border border-slate-800 py-8 px-6 shadow-2xl rounded-2xl space-y-6">
          <div className="text-center">
            <h2 className="text-lg font-bold text-white tracking-tight">Admin Authentication Terminal</h2>
            <p className="text-xs text-slate-550 mt-1">Provide pre-authorized administrative credentials.</p>
          </div>

          {errorMessage && (
            <div className="p-3 bg-rose-950/50 border border-rose-900 rounded-xl text-xs text-rose-200" id="admin-login-error">
              <p className="font-semibold">Security Gate feedback:</p>
              <p className="mt-0.5">{errorMessage}</p>
            </div>
          )}

          {/* Core admin credential actions */}
          <form onSubmit={handleAdminSignIn} className="space-y-4" id="admin-login-form">
            <div>
              <label className="block text-3xs font-extrabold uppercase tracking-wider text-slate-400 mb-1">Admin Email Address *</label>
              <div className="relative">
                <Mail className="absolute left-3 top-2.5 h-4.5 w-4.5 text-slate-500" />
                <input
                  type="email"
                  required
                  placeholder="admin@freelanceros.com"
                  value={email}
                  onChange={(e) => setEmail(e.target.value)}
                  className="w-full bg-slate-950 border border-slate-800 text-white rounded-lg pl-10 pr-3 py-2 text-sm outline-none focus:border-indigo-500"
                  id="admin-email-field"
                />
              </div>
            </div>

            <div>
              <div className="flex justify-between items-center mb-1">
                <label className="block text-3xs font-extrabold uppercase tracking-wider text-slate-400">Admin Secret Key *</label>
              </div>
              <div className="relative">
                <Lock className="absolute left-3 top-2.5 h-4.5 w-4.5 text-slate-500" />
                <input
                  type="password"
                  required
                  placeholder="••••••••"
                  value={password}
                  onChange={(e) => setPassword(e.target.value)}
                  className="w-full bg-slate-950 border border-slate-800 text-white rounded-lg pl-10 pr-3 py-2 text-sm outline-none focus:border-indigo-500"
                  id="admin-pass-field"
                />
              </div>
            </div>

            <button
              type="submit"
              disabled={loading}
              className="w-full justify-center py-2.5 px-4 bg-indigo-600 hover:bg-indigo-500 text-white rounded-lg text-sm font-bold transition flex items-center gap-1.5 cursor-pointer disabled:opacity-55"
              id="admin-signin-btn"
            >
              {loading ? (
                <Loader2 className="w-4.5 h-4.5 animate-spin" />
              ) : (
                <>
                  <span>Verify Credentials</span>
                  <ArrowRight className="w-4 h-4" />
                </>
              )}
            </button>
          </form>

          {/* Separator */}
          <div className="relative flex py-1 items-center" id="admin-divider">
            <div className="flex-grow border-t border-slate-800"></div>
            <span className="flex-shrink mx-4 text-slate-500 text-[10px] uppercase font-mono select-none">Or Authorize with</span>
            <div className="flex-grow border-t border-slate-800"></div>
          </div>

          <button
            type="button"
            onClick={handleGoogleAdmin}
            disabled={loading}
            className="w-full py-2.5 px-4 bg-slate-950 hover:bg-slate-850 hover:bg-slate-800 border border-slate-800 text-slate-200 rounded-lg text-sm font-bold transition flex items-center justify-center gap-2 cursor-pointer disabled:opacity-55"
            id="admin-google-sso"
          >
            <svg className="w-4.5 h-4.5 shrink-0" viewBox="0 0 24 24">
              <path fill="#4285F4" d="M22.56 12.25c0-.78-.07-1.53-.2-2.25H12v4.26h5.92c-.26 1.37-1.04 2.53-2.21 3.31v2.77h3.57c2.08-1.92 3.28-4.74 3.28-8.09z" />
              <path fill="#34A853" d="M12 23c2.97 0 5.46-.98 7.28-2.66l-3.57-2.77c-.98.66-2.23 1.06-3.71 1.06-2.86 0-5.29-1.93-6.16-4.53H2.18v2.84C3.99 20.53 7.7 23 12 23z" />
              <path fill="#FBBC05" d="M5.84 14.09c-.22-.66-.35-1.36-.35-2.09s.13-1.43.35-2.09V7.06H2.18C1.43 8.55 1 10.22 1 12s.43 3.45 1.18 4.94l2.85-2.22c-.62-.87-.84-2.12-.84-3.57z" />
              <path fill="#EA4335" d="M12 5.38c1.62 0 3.06.56 4.21 1.64l3.15-3.15C17.45 2.09 14.97 1 12 1 7.7 1 3.99 3.47 2.18 7.06l3.66 2.84c.87-2.6 3.3-4.52 6.16-4.52z" />
            </svg>
            <span>Bootstrap Google Single-Sign-On</span>
          </button>

          <div className="text-center mt-4">
            <button
              onClick={() => navigate('/login')}
              className="text-indigo-400 hover:text-indigo-300 font-bold hover:underline inline-flex items-center gap-1 cursor-pointer font-sans text-xs"
              id="return-to-standard-login"
            >
              <ArrowLeft className="w-3.5 h-3.5" />
              Return to User Workspace
            </button>
          </div>
        </div>
      </div>
    </div>
  );
}
