import React, { useState } from 'react';
import { 
  Lock, 
  Mail, 
  User, 
  Loader2, 
  ArrowRight, 
  HelpCircle, 
  Sparkles, 
  ArrowLeft,
  Briefcase
} from 'lucide-react';
import { useAuth } from '../contexts/AuthContext';

export default function AuthenticationView() {
  const { signUpWithEmail, loginWithEmail, loginWithGoogle, resetPassword } = useAuth();
  
  // View controller states: 'login' | 'signup' | 'forgot'
  const [viewState, setViewState] = useState<'login' | 'signup' | 'forgot'>('login');
  
  // Fields inputs
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [name, setName] = useState('');
  
  const [loading, setLoading] = useState(false);
  const [forgotSent, setForgotSent] = useState(false);
  const [errorMessage, setErrorMessage] = useState('');

  const handleEmailAction = async (e: React.FormEvent) => {
    e.preventDefault();
    setErrorMessage('');
    if (!email.trim() || (viewState !== 'forgot' && !password.trim())) {
      setErrorMessage('Please fill in some required authentication credentials.');
      return;
    }

    try {
      setLoading(true);
      if (viewState === 'login') {
        await loginWithEmail(email, password);
      } else if (viewState === 'signup') {
        if (!name.trim()) {
          setErrorMessage('Your Name display field is a required property.');
          setLoading(false);
          return;
        }
        await signUpWithEmail(email, password, name);
      } else {
        // Forgot Password Mode
        await resetPassword(email);
        setForgotSent(true);
      }
    } catch (err: any) {
      console.error(err);
      setErrorMessage(err?.message || 'Authentication error. Please verify input fields.');
    } finally {
      setLoading(false);
    }
  };

  const handleGoogleAction = async () => {
    setErrorMessage('');
    try {
      setLoading(true);
      await loginWithGoogle();
    } catch (err: any) {
      console.error(err);
      setErrorMessage(err?.message || 'Google signup operation canceled.');
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="min-h-screen bg-gray-50 flex flex-col justify-center py-12 px-4 sm:px-6 lg:px-8 font-sans" id="auth-screen-container">
      {/* Visual Header */}
      <div className="sm:mx-auto sm:w-full sm:max-w-md text-center" id="auth-visual-header">
        <div className="inline-flex p-3 bg-indigo-600 text-white rounded-xl shadow-md mb-4 animate-scale-up">
          <Briefcase className="w-8 h-8" />
        </div>
        <h1 className="text-3xl font-black text-gray-950 tracking-tight font-sans">FREELANCER OS</h1>
        <p className="text-sm text-gray-500 mt-2 font-sans">
          All-in-one suite to manage clients, track project budgets, and auto-generate invoices.
        </p>
      </div>

      {/* Form Card Layout */}
      <div className="mt-8 sm:mx-auto sm:w-full sm:max-w-md animate-fade-in" id="auth-form-card">
        <div className="bg-white py-8 px-6 shadow-xl border border-gray-100 rounded-2xl space-y-6">
          <div className="text-center" id="auth-state-header">
            <h2 className="text-lg font-bold text-gray-900 tracking-tight">
              {viewState === 'login' && 'Sign In to Your Workspace'}
              {viewState === 'signup' && 'Create Your Freelancer Account'}
              {viewState === 'forgot' && 'Request Password Recovery'}
            </h2>
            <p className="text-xs text-gray-400 mt-1">
              {viewState === 'login' && 'Enter your registered credentials to launch.'}
              {viewState === 'signup' && 'Build your personal dashboard space in seconds.'}
              {viewState === 'forgot' && 'Type in your email to send reset links.'}
            </p>
          </div>

          {/* User feedback error messaging */}
          {errorMessage && (
            <div className="p-3 bg-rose-50 border border-rose-150 rounded-xl text-xs text-rose-800" id="auth-error-output">
              <p className="font-semibold">Authentication feedback:</p>
              <p className="mt-0.5">{errorMessage}</p>
            </div>
          )}

          {/* Forgot email success checklist */}
          {forgotSent && viewState === 'forgot' && (
            <div className="p-4 bg-emerald-50 border border-emerald-150 rounded-xl text-xs text-emerald-800 text-center space-y-1.5" id="auth-forgot-success">
              <p className="font-extrabold text-sm text-emerald-900">Recovery Email Sent!</p>
              <p>Check your email inbox directory for instructions to reset your account password.</p>
              <button
                onClick={() => { setViewState('login'); setForgotSent(false); }}
                className="text-indigo-600 font-bold underline cursor-pointer mt-1"
              >
                Sign In now
              </button>
            </div>
          )}

          {/* Authentic action forms */}
          {(!forgotSent || viewState !== 'forgot') && (
            <form onSubmit={handleEmailAction} className="space-y-4" id="auth-core-form">
              {viewState === 'signup' && (
                <div>
                  <label className="block text-2xs font-bold text-gray-650 uppercase tracking-wider mb-1">Your Full Name *</label>
                  <div className="relative">
                    <User className="absolute left-3 top-2.5 h-4.5 w-4.5 text-gray-400" />
                    <input
                      type="text"
                      required
                      placeholder="e.g. Timothy Vance"
                      value={name}
                      onChange={(e) => setName(e.target.value)}
                      className="w-full bg-white text-gray-900 border border-gray-200 rounded-lg pl-10 pr-3 py-2 text-sm outline-none focus:border-indigo-500"
                      id="auth-input-name"
                    />
                  </div>
                </div>
              )}

              <div>
                <label className="block text-2xs font-bold text-gray-655 uppercase tracking-wider mb-1">Work Email Address *</label>
                <div className="relative">
                  <Mail className="absolute left-3 top-2.5 h-4.5 w-4.5 text-gray-400" />
                  <input
                    type="email"
                    required
                    placeholder="e.g. timothy@vance.io"
                    value={email}
                    onChange={(e) => setEmail(e.target.value)}
                    className="w-full bg-white text-gray-900 border border-gray-200 rounded-lg pl-10 pr-3 py-2 text-sm outline-none focus:border-indigo-500"
                    id="auth-input-email"
                  />
                </div>
              </div>

              {viewState !== 'forgot' && (
                <div>
                  <div className="flex justify-between items-center mb-1">
                    <label className="block text-2xs font-bold text-gray-650 uppercase tracking-wider">Account Password *</label>
                    {viewState === 'login' && (
                      <button
                        type="button"
                        onClick={() => setViewState('forgot')}
                        className="text-xs text-indigo-600 hover:text-indigo-800 transition font-sans cursor-pointer font-semibold"
                        id="forgot-password-trigger"
                      >
                        Reset Password?
                      </button>
                    )}
                  </div>
                  <div className="relative">
                    <Lock className="absolute left-3 top-2.5 h-4.5 w-4.5 text-gray-400" />
                    <input
                      type="password"
                      required
                      placeholder="••••••••"
                      value={password}
                      onChange={(e) => setPassword(e.target.value)}
                      className="w-full bg-white text-gray-900 border border-gray-200 rounded-lg pl-10 pr-3 py-2 text-sm outline-none focus:border-indigo-500"
                      id="auth-input-password"
                    />
                  </div>
                </div>
              )}

              <button
                type="submit"
                disabled={loading}
                className="w-full justify-center py-2.5 px-4 bg-indigo-600 hover:bg-indigo-700 text-white rounded-lg text-sm font-bold transition flex items-center gap-1.5 cursor-pointer disabled:opacity-50"
                id="btn-submit-auth"
              >
                {loading ? (
                  <Loader2 className="w-4.5 h-4.5 animate-spin" />
                ) : (
                  <>
                    {viewState === 'login' && 'Sign In'}
                    {viewState === 'signup' && 'Create Free Account'}
                    {viewState === 'forgot' && 'Send Recovery Email'}
                    <ArrowRight className="w-4 h-4" />
                  </>
                )}
              </button>
            </form>
          )}

          {/* Separator */}
          {(!forgotSent || viewState !== 'forgot') && (
            <div className="relative flex py-1 items-center" id="auth-separator">
              <div className="flex-grow border-t border-gray-200"></div>
              <span className="flex-shrink mx-4 text-gray-400 text-2xs uppercase font-mono select-none">Or Continue With</span>
              <div className="flex-grow border-t border-gray-200"></div>
            </div>
          )}

          {/* Google SSO Login */}
          {(!forgotSent || viewState !== 'forgot') && (
            <button
              type="button"
              onClick={handleGoogleAction}
              disabled={loading}
              className="w-full py-2.5 px-4 bg-gray-50 hover:bg-gray-100 border border-gray-200 text-gray-700 rounded-lg text-sm font-bold transition flex items-center justify-center gap-2 cursor-pointer disabled:opacity-50"
              id="google-sso-action"
            >
              <svg className="w-4.5 h-4.5 shrink-0" viewBox="0 0 24 24">
                <path fill="#4285F4" d="M22.56 12.25c0-.78-.07-1.53-.2-2.25H12v4.26h5.92c-.26 1.37-1.04 2.53-2.21 3.31v2.77h3.57c2.08-1.92 3.28-4.74 3.28-8.09z" />
                <path fill="#34A853" d="M12 23c2.97 0 5.46-.98 7.28-2.66l-3.57-2.77c-.98.66-2.23 1.06-3.71 1.06-2.86 0-5.29-1.93-6.16-4.53H2.18v2.84C3.99 20.53 7.7 23 12 23z" />
                <path fill="#FBBC05" d="M5.84 14.09c-.22-.66-.35-1.36-.35-2.09s.13-1.43.35-2.09V7.06H2.18C1.43 8.55 1 10.22 1 12s.43 3.45 1.18 4.94l2.85-2.22c-.62-.87-.84-2.12-.84-3.57z" />
                <path fill="#EA4335" d="M12 5.38c1.62 0 3.06.56 4.21 1.64l3.15-3.15C17.45 2.09 14.97 1 12 1 7.7 1 3.99 3.47 2.18 7.06l3.66 2.84c.87-2.6 3.3-4.52 6.16-4.52z" />
              </svg>
              <span>Authenticate with Google</span>
            </button>
          )}

          {/* Navigation link togglers between screens */}
          <div className="text-center text-xs" id="auth-switch-views">
            {viewState === 'login' && (
              <div className="space-y-3">
                <p className="text-gray-500 font-sans">
                  Don't have a Freelancer OS account?{' '}
                  <button
                    onClick={() => { setViewState('signup'); setErrorMessage(''); }}
                    className="text-indigo-600 font-bold hover:underline cursor-pointer"
                    id="link-to-signup"
                  >
                    Join for Free
                  </button>
                </p>
                <div className="pt-2 border-t border-gray-100 flex justify-center">
                  <a
                    href="/admin/login"
                    className="text-[10px] font-semibold text-gray-400 hover:text-indigo-600 tracking-wider uppercase font-sans hover:underline flex items-center gap-1"
                    id="link-to-admin-portal"
                  >
                    Are you an Administrator? Access Portal
                  </a>
                </div>
              </div>
            )}

            {viewState === 'signup' && (
              <p className="text-gray-500 font-sans">
                Already registered with an account?{' '}
                <button
                  onClick={() => { setViewState('login'); setErrorMessage(''); }}
                  className="text-indigo-600 font-bold hover:underline cursor-pointer"
                  id="link-to-login"
                >
                  Log In
                </button>
              </p>
            )}

            {viewState === 'forgot' && (
              <button
                onClick={() => { setViewState('login'); setErrorMessage(''); }}
                className="text-indigo-600 font-bold hover:underline inline-flex items-center gap-1 cursor-pointer font-sans"
                id="link-return-to-login"
              >
                <ArrowLeft className="w-3.5 h-3.5" />
                Return to Login
              </button>
            )}
          </div>
        </div>
      </div>
    </div>
  );
}
