import React, { useEffect, useState } from 'react';
import { BarChart, Users, TrendingUp, DollarSign, Loader2, Calendar } from 'lucide-react';
import { getAllUsers, getSubscriptions, getAllPayments } from '../services/db';
import { UserProfile, Subscription, Payment } from '../types';

export default function AdminAnalyticsView() {
  const [loading, setLoading] = useState(true);
  const [users, setUsers] = useState<UserProfile[]>([]);
  const [subscriptions, setSubscriptions] = useState<Subscription[]>([]);
  const [payments, setPayments] = useState<Payment[]>([]);

  useEffect(() => {
    async function loadData() {
      try {
        setLoading(true);
        const [u, s, p] = await Promise.all([
          getAllUsers(),
          getSubscriptions(),
          getAllPayments()
        ]);
        setUsers(u || []);
        setSubscriptions(s || []);
        setPayments(p || []);
      } catch (err) {
        console.error("Failed to load analytics details:", err);
      } finally {
        setLoading(false);
      }
    }
    loadData();
  }, []);

  if (loading) {
    return (
      <div className="flex justify-center py-24" id="analytics-spinner">
        <Loader2 className="w-8 h-8 text-indigo-650 animate-spin" />
      </div>
    );
  }

  // Calculate stats
  const activeSubs = subscriptions.filter(s => s.status === 'active');
  const totalARR = activeSubs.reduce((sum, s) => {
    const isYearly = s.billingCycle === 'yearly';
    const annualPrice = isYearly ? s.price : s.price * 12;
    return sum + annualPrice;
  }, 0);

  const averageARPUs = activeSubs.length > 0 ? (totalARR / 12) / activeSubs.length : 0;

  // Let's create a list of plans and their counts for data viz
  const plansStats = ['Starter', 'Grower', 'Professional', 'Enterprise'].map(title => {
    const activeForPlan = subscriptions.filter(s => s.plan === title && s.status === 'active').length;
    return { plan: title, count: activeForPlan };
  });

  const maxPlanCount = Math.max(...plansStats.map(p => p.count), 1);

  // Growth mock timelines for dynamic illustration
  const growthTimeline = [
    { month: 'Jan', revenue: 1450, users: 12 },
    { month: 'Feb', revenue: 2100, users: 18 },
    { month: 'Mar', revenue: 3900, users: 29 },
    { month: 'Apr', revenue: 4700, users: 35 },
    { month: 'May', revenue: 6400, users: 48 },
    { month: 'Jun', revenue: 8300, users: 60 }
  ];

  const maxRev = Math.max(...growthTimeline.map(g => g.revenue), 1);

  return (
    <div className="space-y-8 animate-fade-in font-sans" id="admin-analytics-root">
      
      <div className="border-b border-gray-150 pb-5">
        <h1 className="text-2xl font-black text-gray-950 tracking-tight">Platform SaaS Analytics</h1>
        <p className="text-xs text-gray-500 mt-1">Acquire deep performance insights, annualized cash schedules (ARR), average revenue per user (ARPU), and license allocations ratios.</p>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-3 gap-6" id="analytics-overview-row">
        
        {/* Metric 1 */}
        <div className="bg-white p-6 border border-gray-155 rounded-2xl flex items-center gap-4 border-gray-150 hover:shadow-xs transition">
          <div className="p-3 bg-indigo-50 text-indigo-650 rounded-xl">
            <TrendingUp className="w-5.5 h-5.5" />
          </div>
          <div>
            <span className="text-3xs uppercase font-extrabold tracking-wider text-gray-405 font-mono text-gray-400">Annual Run Rate (ARR)</span>
            <h4 className="text-2xl font-bold text-gray-950 tracking-tight mt-0.5">
              ${totalARR.toLocaleString('en-US', { minimumFractionDigits: 2, maximumFractionDigits: 2 })}
            </h4>
          </div>
        </div>

        {/* Metric 2 */}
        <div className="bg-white p-6 border border-gray-155 rounded-2xl flex items-center gap-4 border-gray-150 hover:shadow-xs transition">
          <div className="p-3 bg-emerald-50 text-emerald-650 rounded-xl">
            <DollarSign className="w-5.5 h-5.5" />
          </div>
          <div>
            <span className="text-3xs uppercase font-extrabold tracking-wider text-gray-405 font-mono text-gray-400">Avg Mo. ARPU</span>
            <h4 className="text-2xl font-bold text-gray-950 tracking-tight mt-0.5">
              ${averageARPUs.toFixed(2)}
            </h4>
          </div>
        </div>

        {/* Metric 3 */}
        <div className="bg-white p-6 border border-gray-155 rounded-2xl flex items-center gap-4 border-gray-150 hover:shadow-xs transition">
          <div className="p-3 bg-amber-50 text-amber-650 rounded-xl">
            <Users className="w-5.5 h-5.5" />
          </div>
          <div>
            <span className="text-3xs uppercase font-extrabold tracking-wider text-gray-450 font-mono text-gray-400 font-bold">Conversion Percent</span>
            <h4 className="text-2xl font-bold text-gray-950 tracking-tight mt-0.5">
              {users.length > 0 ? ((activeSubs.length / users.length) * 100).toFixed(1) : 0}%
            </h4>
          </div>
        </div>

      </div>

      <div className="grid grid-cols-1 lg:grid-cols-2 gap-8" id="analytics-viz-row">
        
        {/* Chart A: Plan Distribution Chart */}
        <div className="bg-white p-6 border border-gray-150 rounded-2xl space-y-4" id="chart-plan-distribution">
          <h3 className="text-xs font-bold text-gray-450 uppercase font-mono tracking-wider text-gray-500">
            Active SLA Plan Allocations Distribution
          </h3>
          
          <div className="space-y-4" id="plan-viz-bars">
            {plansStats.map(item => {
              const innerWidth = (item.count / maxPlanCount) * 100;
              return (
                <div key={item.plan} className="space-y-1 select-none">
                  <div className="flex justify-between text-xs font-bold text-gray-700">
                    <span>{item.plan} Premium License</span>
                    <span className="font-mono text-gray-500">{item.count} Accounts</span>
                  </div>
                  <div className="w-full bg-gray-50 border border-gray-150/40 h-8 rounded-xl overflow-hidden flex items-center relative">
                    <div 
                      className="bg-indigo-650/15 border-r-2 border-indigo-600 h-full transition-all duration-700" 
                      style={{ width: `${item.count > 0 ? innerWidth : 0}%` }}
                    ></div>
                    <span className="absolute left-3 text-2xs text-indigo-950 font-bold font-sans">
                      {item.count > 0 ? `${innerWidth.toFixed(0)}% Allocation` : 'No active licenses'}
                    </span>
                  </div>
                </div>
              );
            })}
          </div>
        </div>

        {/* Chart B: Mo. cash accumulation HISTOGRAM */}
        <div className="bg-white p-6 border border-gray-150 rounded-2xl space-y-4" id="chart-revenue-accumulation">
          <div className="flex justify-between items-center select-none">
            <h3 className="text-xs font-bold text-gray-450 uppercase font-mono tracking-wider text-gray-500 flex items-center gap-1">
              <BarChart className="w-4.5 h-4.5 text-indigo-605" />
              SaaS Growth Matrix Track
            </h3>
            <span className="text-[10px] uppercase font-mono bg-gray-50 text-gray-550 border border-gray-150 px-2.5 py-0.5 rounded-full font-bold flex items-center gap-1">
              <Calendar className="w-3 h-3 text-indigo-600" />
              H1 Schedule
            </span>
          </div>

          <div className="h-56 flex items-end gap-3 pt-6 relative" id="histogram-viewport">
            {/* Legend guide lines */}
            <div className="absolute inset-y-0 left-0 right-0 flex flex-col justify-between pointer-events-none text-2xs font-mono font-bold text-gray-300">
              <div className="border-b border-gray-100 w-full pt-1"></div>
              <div className="border-b border-gray-100 w-full"></div>
              <div className="border-b border-gray-100 w-full"></div>
            </div>

            {growthTimeline.map((g) => {
              const barHeight = (g.revenue / maxRev) * 100;
              return (
                <div key={g.month} className="flex-1 flex flex-col items-center gap-2 group cursor-pointer z-10" id={`bar-${g.month}`}>
                  
                  {/* Tooltip hovering effect */}
                  <div className="bg-slate-900 border border-slate-800 text-white text-[10px] font-bold px-2 py-1.5 rounded-lg opacity-0 group-hover:opacity-100 transition absolute -top-1 translate-y-[-10px] pointer-events-none text-center">
                    <p className="font-mono">${g.revenue.toLocaleString()} Cash</p>
                    <p className="text-3xs text-slate-400">{g.users} Members</p>
                  </div>

                  {/* Rectangle */}
                  <div className="w-full bg-indigo-50 border border-indigo-150 hover:bg-indigo-600 hover:border-transparent transition-all duration-300 rounded-lg overflow-hidden flex items-end" style={{ height: `${barHeight}%` }}>
                    <div className="w-full bg-indigo-600 h-1/3 opacity-30 group-hover:opacity-100 transition"></div>
                  </div>

                  {/* Title labels */}
                  <span className="text-2xs font-bold font-mono text-gray-600">{g.month}</span>
                </div>
              );
            })}
          </div>
        </div>

      </div>

    </div>
  );
}
