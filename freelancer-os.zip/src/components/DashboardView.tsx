import React, { useState, useEffect } from 'react';
import { 
  Building, 
  FolderGit2, 
  CheckCircle, 
  Clock, 
  CircleDollarSign, 
  TrendingUp, 
  Clock3, 
  Plus, 
  Lightbulb, 
  ChevronRight, 
  Bot, 
  FileText, 
  ArrowUpRight, 
  Loader2, 
  Users, 
  Sparkles 
} from 'lucide-react';
import { Client, Project, Invoice, Activity, ClientStatus, ProjectStatus, PaymentStatus } from '../types';
import { getClients, getProjects, getInvoices, getActivities } from '../services/db';
import { useAuth } from '../contexts/AuthContext';

interface DashboardViewProps {
  onNavigate: (view: 'dashboard' | 'clients' | 'projects' | 'invoices' | 'payments' | 'profile' | 'ai') => void;
}

export default function DashboardView({ onNavigate }: DashboardViewProps) {
  const { userProfile, user } = useAuth();
  const [clients, setClients] = useState<Client[]>([]);
  const [projects, setProjects] = useState<Project[]>([]);
  const [invoices, setInvoices] = useState<Invoice[]>([]);
  const [activities, setActivities] = useState<Activity[]>([]);
  const [loading, setLoading] = useState(true);

  const loadDashboardData = async () => {
    if (!user) return;
    try {
      setLoading(true);
      const [clientList, projectList, invoiceList, activityList] = await Promise.all([
        getClients(user.uid),
        getProjects(user.uid),
        getInvoices(user.uid),
        getActivities(user.uid)
      ]);
      setClients(clientList);
      setProjects(projectList);
      setInvoices(invoiceList);
      setActivities(activityList);
    } catch (err) {
      console.error("Failed to load dashboard metrics", err);
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    loadDashboardData();
  }, [user]);

  if (loading) {
    return (
      <div className="flex flex-col items-center justify-center p-16 bg-white rounded-xl border border-gray-105 shadow-xs" id="dashboard-loader">
        <Loader2 className="w-8 h-8 text-indigo-650 animate-spin" />
        <p className="text-sm text-gray-500 mt-2">Computing SaaS analytics telemetry...</p>
      </div>
    );
  }

  // Count metrics
  const totalClientsCount = clients.length;
  const activeProjectsCount = projects.filter(p => p.status === ProjectStatus.IN_PROGRESS).length;
  const pendingProjectsCount = projects.filter(p => p.status === ProjectStatus.PENDING).length;

  // Revenue computations
  const totalRevenue = invoices.reduce((sum, i) => sum + i.totalAmount, 0);
  const paidRevenue = invoices.filter(i => i.status === PaymentStatus.PAID).reduce((sum, i) => sum + i.totalAmount, 0);
  const pendingRevenue = invoices.filter(i => i.status !== PaymentStatus.PAID).reduce((sum, i) => sum + i.totalAmount, 0);

  // Growth percentages placeholders/simulated
  const clientGoalPercent = Math.min((totalClientsCount / 10) * 100, 100);
  const projectGoalPercent = Math.min(((activeProjectsCount + pendingProjectsCount) / 12) * 100, 100);

  return (
    <div className="space-y-6" id="dashboard-container">
      {/* Dynamic Welcoming Row */}
      <div className="flex flex-col md:flex-row md:items-center md:justify-between gap-4" id="dashboard-welcome">
        <div>
          <h2 className="text-2xl font-black text-gray-950 tracking-tight">
            Welcome back, {userProfile?.name || 'Freelancer'}!
          </h2>
          <p className="text-sm text-gray-500 mt-1 font-sans">
            Here is your financial and operational status summary for {new Date().toLocaleString(undefined, {month: 'long', year: 'numeric'})}.
          </p>
        </div>
        
        {/* Quick Operations bar */}
        <div className="flex items-center gap-3" id="quick-action-shortcuts">
          <button
            onClick={() => onNavigate('clients')}
            className="px-3.5 py-1.5 bg-white border border-gray-200 text-gray-700 font-sans font-bold rounded-lg text-xs hover:border-indigo-300 transition duration-150 cursor-pointer inline-flex items-center gap-1.5"
          >
            <Users className="w-3.5 h-3.5 mt-0.5 text-gray-500" />
            + Client Record
          </button>
          <button
            onClick={() => onNavigate('invoices')}
            className="px-3.5 py-1.5 bg-indigo-600 hover:bg-indigo-700 text-white font-sans font-bold rounded-lg text-xs transition duration-150 cursor-pointer inline-flex items-center gap-1.5 shadow-xs"
          >
            <FileText className="w-3.5 h-3.5" />
            New Invoice
          </button>
        </div>
      </div>

      {/* KPI Stats cards */}
      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-6" id="dashboard-kpis">
        {/* Total clients */}
        <div className="bg-white p-5 rounded-2xl border border-gray-100 flex items-start gap-4 shadow-xs hover:shadow-md transition">
          <div className="p-3 bg-indigo-50 text-indigo-700 rounded-xl">
            <Building className="w-5.5 h-5.5" />
          </div>
          <div className="flex-1">
            <p className="text-xs text-gray-500 font-sans font-bold">Client accounts</p>
            <h3 className="text-2xl font-black text-gray-950 mt-1">{totalClientsCount}</h3>
            
            {/* Visual Progress bar */}
            <div className="w-full bg-gray-100 h-1.5 rounded-full mt-3 overflow-hidden">
              <div className="bg-indigo-600 h-full transition-all duration-300" style={{ width: `${clientGoalPercent}%` }}></div>
            </div>
            <p className="text-3xs text-gray-400 mt-1.5">{clientGoalPercent.toFixed(0)}% represented toward monthly partner cap</p>
          </div>
        </div>

        {/* Active Workspace */}
        <div className="bg-white p-5 rounded-2xl border border-gray-100 flex items-start gap-4 shadow-xs hover:shadow-md transition">
          <div className="p-3 bg-amber-50 text-amber-700 rounded-xl animate-fade-in">
            <FolderGit2 className="w-5.5 h-5.5" />
          </div>
          <div className="flex-1">
            <p className="text-xs text-gray-500 font-sans font-bold">Under Progress</p>
            <div className="flex items-baseline gap-2 mt-1">
              <h3 className="text-2xl font-black text-gray-950">{activeProjectsCount}</h3>
              <span className="text-xs text-gray-400 font-medium font-sans">({pendingProjectsCount} Pending)</span>
            </div>

            <div className="w-full bg-gray-100 h-1.5 rounded-full mt-3 overflow-hidden">
              <div className="bg-amber-500 h-full transition-all duration-300" style={{ width: `${projectGoalPercent}%` }}></div>
            </div>
            <p className="text-3xs text-gray-400 mt-1.5">{projectGoalPercent.toFixed(0)}% of server resource limits allocated</p>
          </div>
        </div>

        {/* Paid collections */}
        <div className="bg-white p-5 rounded-2xl border border-gray-100 flex items-start gap-4 shadow-xs hover:shadow-md transition sm:col-span-2 lg:col-span-1">
          <div className="p-3 bg-emerald-50 text-emerald-700 rounded-xl">
            <CircleDollarSign className="w-5.5 h-5.5" />
          </div>
          <div className="flex-1">
            <p className="text-xs text-gray-500 font-sans font-bold font-sans">Cash Collected (Paid)</p>
            <h3 className="text-2xl font-black text-emerald-700 mt-1">${paidRevenue.toLocaleString(undefined, { minimumFractionDigits: 2, maximumFractionDigits: 2 })}</h3>
            <p className="text-xs text-gray-400 mt-3 flex items-center gap-1">
              <TrendingUp className="w-3.5 h-3.5 text-emerald-600" />
              <span>Outstanding: <span className="font-bold text-gray-800">${pendingRevenue.toLocaleString()}</span></span>
            </p>
          </div>
        </div>
      </div>

      {/* Main Working Grid splits */}
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6" id="dashboard-grid">
        {/* Left column: SVG Charts & Financial analytics (2 cols layout span) */}
        <div className="lg:col-span-2 bg-white rounded-2xl border border-gray-100 p-6 space-y-6 shadow-xs" id="dashboard-charts-module">
          <div className="flex items-center justify-between border-b border-gray-50 pb-3">
            <div>
              <h3 className="text-sm font-bold text-gray-900 tracking-tight">Earnings Distribution Matrix</h3>
              <p className="text-xs text-gray-400">Comparing paid cash inflows against pending invoice outstanding receivable.</p>
            </div>
            <span className="text-2xs uppercase tracking-wider font-bold text-indigo-700 bg-indigo-50 px-2.5 py-0.5 rounded border border-indigo-150">LEDGER</span>
          </div>

          {/* SVG Graphical Bar meters */}
          <div className="space-y-4" id="svg-analytics">
            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              <div className="space-y-2 bg-gray-50 p-4 rounded-xl border border-gray-100">
                <p className="text-3xs uppercase text-gray-400 tracking-wider font-bold">General Cash Flow Efficiency</p>
                <div className="flex items-center justify-between font-sans">
                  <span className="text-xs font-bold text-gray-700">Collections Rate</span>
                  <span className="text-sm font-bold text-gray-905">
                    {totalRevenue > 0 ? ((paidRevenue / totalRevenue) * 100).toFixed(0) : 0}%
                  </span>
                </div>
                <div className="w-full bg-gray-200 h-2.5 rounded-full overflow-hidden mt-1">
                  <div 
                    className="bg-emerald-500 h-full rounded-full transition-all duration-300"
                    style={{ width: `${totalRevenue > 0 ? (paidRevenue / totalRevenue) * 100 : 0}%` }}
                  ></div>
                </div>
                <p className="text-3xs text-gray-400 mt-1 bg-white p-1 rounded border border-gray-100">Outstanding: ${(totalRevenue - paidRevenue).toLocaleString(undefined, {minimumFractionDigits: 2})}</p>
              </div>

              {/* Dynamic SVG Visual Donut Ring bar representation */}
              <div className="flex items-center justify-between bg-gray-50 p-4 rounded-xl border border-gray-100" id="visual-mini-donut">
                <div className="space-y-1">
                  <p className="text-3xs uppercase text-gray-400 tracking-wider font-bold">Ledger Balance Volume</p>
                  <p className="text-xs font-bold text-gray-800">Paid: <span className="text-emerald-700">${paidRevenue.toLocaleString()}</span></p>
                  <p className="text-xs font-bold text-gray-800 font-sans">Pending: <span className="text-rose-600">${pendingRevenue.toLocaleString()}</span></p>
                </div>
                {/* SVG Visual Arc */}
                <svg className="w-16 h-16 shrink-0 transform -rotate-90" viewBox="0 0 36 36">
                  <path
                    className="text-gray-200"
                    strokeWidth="3.5"
                    stroke="currentColor"
                    fill="none"
                    d="M18 2.0845 a 15.9155 15.9155 0 0 1 0 31.831 a 15.9155 15.9155 0 0 1 0 -31.831"
                  />
                  {totalRevenue > 0 && (
                    <path
                      className="text-emerald-500 transition-all duration-200"
                      strokeDasharray={`${(paidRevenue / totalRevenue) * 100}, 100`}
                      strokeWidth="3.5"
                      strokeLinecap="round"
                      stroke="currentColor"
                      fill="none"
                      d="M18 2.0845 a 15.9155 15.9155 0 0 1 0 31.831 a 15.9155 15.9155 0 0 1 0 -31.831"
                    />
                  )}
                </svg>
              </div>
            </div>

            {/* Smart tip panel */}
            <div className="p-3.5 bg-indigo-50/50 rounded-xl border border-indigo-100 text-xs text-indigo-950 flex items-start gap-2.5 font-sans">
              <Lightbulb className="w-5 h-5 text-indigo-600 shrink-0 mt-0.5" />
              <div>
                <span className="font-bold">Business intelligence tip: </span>
                {pendingRevenue > 0 
                  ? `You have pending invoices worth $${pendingRevenue.toLocaleString()}. Visit the Payment Tracker to audit overdue accounts or schedule dynamic follow-up reminders.`
                  : "Excellent job keeping your invoices clear and accounts ledger in healthy standing!"}
              </div>
            </div>
          </div>
        </div>

        {/* Right column: Recent Activity Logs (Feature 5 checklist) */}
        <div className="bg-white rounded-2xl border border-gray-100 p-6 flex flex-col justify-between shadow-xs" id="dashboard-activities-module">
          <div className="space-y-4">
            <div className="border-b border-gray-50 pb-3 flex items-center justify-between">
              <div>
                <h3 className="text-sm font-bold text-gray-900 tracking-tight">Audit Checklist Logs</h3>
                <p className="text-xs text-gray-400">Latest operations recorded on Freelancer OS.</p>
              </div>
              <ChevronRight className="w-4 h-4 text-gray-400" />
            </div>

            {/* Activities list map */}
            <div className="space-y-4" id="activity-trails-list">
              {activities.length === 0 ? (
                <div className="text-center py-10 text-gray-400">
                  <Clock3 className="w-8 h-8 text-gray-300 mx-auto mb-2" />
                  <p className="text-xs font-semibold text-gray-500">No activities documented yet</p>
                  <p className="text-3xs text-gray-400 mt-0.5">CRUD actions log here automatically.</p>
                </div>
              ) : (
                activities.slice(0, 5).map((act) => (
                  <div key={act.id} className="flex gap-3 text-xs items-start" id={`activity-item-${act.id}`}>
                    <div className="p-1 px-1.5 bg-gray-55/10 rounded font-semibold text-3xs text-gray-650 shrink-0 uppercase tracking-widest leading-none mt-0.5">
                      {act.type}
                    </div>
                    <div className="flex-1">
                      <p className="text-gray-700 font-medium font-sans leading-tight">{act.description}</p>
                      <p className="text-3xs text-gray-400 mt-0.5">
                        {act.createdAt?.seconds 
                          ? new Date(act.createdAt.seconds * 1000).toLocaleString(undefined, {hour: '2-digit', minute: '2-digit'})
                          : 'Recorded recently'}
                      </p>
                    </div>
                  </div>
                ))
              )}
            </div>
          </div>

          {/* Quick AI Assist CTA */}
          <div className="bg-gradient-to-br from-indigo-50 to-violet-50 border border-indigo-100 p-4 rounded-xl mt-6 flex items-start gap-3 relative overflow-hidden" id="dashboard-ai-card">
            <div className="absolute right-0 bottom-0 select-none opacity-20 pointer-events-none">
              <Bot className="w-20 h-20 text-indigo-550" />
            </div>
            
            <div className="space-y-1 z-10">
              <span className="inline-flex items-center gap-1 px-2 py-0.5 bg-indigo-100 text-indigo-805 text-3xs font-extrabold rounded-full">
                <Sparkles className="w-3 h-3 text-indigo-600" />
                AI CO-PILOT
              </span>
              <h4 className="text-xs font-bold text-indigo-950 mt-1">Accelerate Proposals</h4>
              <p className="text-3xs text-indigo-800 max-w-[200px]">Draft custom client contract pitches and responses inside your automated copilot panel.</p>
              <button
                onClick={() => onNavigate('ai')}
                className="mt-2.5 text-3xs font-black text-indigo-700 hover:text-indigo-900 inline-flex items-center gap-1 cursor-pointer"
              >
                Launch Copilot
                <ArrowUpRight className="w-3.5 h-3.5" />
              </button>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}
