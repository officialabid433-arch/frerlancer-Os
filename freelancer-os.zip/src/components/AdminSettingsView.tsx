import React from 'react';
import { ShieldCheck, Calendar, Mail, FileText, Settings, Key, UserCheck } from 'lucide-react';
import { useAuth } from '../contexts/AuthContext';

export default function AdminSettingsView() {
  const { adminProfile, user } = useAuth();

  return (
    <div className="space-y-6 animate-fade-in font-sans" id="admin-settings-root">
      
      <div className="border-b border-gray-150 pb-5">
        <h1 className="text-2xl font-black text-gray-950 tracking-tight">System Settings & RBAC Configuration</h1>
        <p className="text-xs text-gray-500 mt-1">Review active system rules, bootstrap administrative profiles, and active access tokens.</p>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
        
        {/* Profile Card details */}
        <div className="bg-white p-6 border border-gray-150 rounded-2xl lg:col-span-1 space-y-4 shadow-xs" id="admin-profile-card">
          <div className="text-center select-none">
            <div className="inline-flex p-4 bg-indigo-50 border border-indigo-150 rounded-full text-indigo-750 mb-3 text-indigo-700">
              <ShieldCheck className="w-8 h-8" />
            </div>
            <h3 className="text-base font-extrabold text-gray-950 truncate">{adminProfile?.name || 'Administrator'}</h3>
            <span className="text-[10px] uppercase font-mono tracking-wider font-extrabold text-indigo-650 bg-indigo-50 px-2.5 py-0.5 rounded-full mt-1.5 inline-block">
              PLATFORM_ADMIN
            </span>
          </div>

          <div className="divide-y divide-gray-100 text-xs space-y-3 pt-3">
            <div className="flex justify-between items-center pt-3 first:pt-0">
              <span className="font-semibold text-gray-450 text-gray-400">Account Role</span>
              <span className="font-bold font-mono text-indigo-950 capitalize">{adminProfile?.role || 'admin'}</span>
            </div>
            
            <div className="flex justify-between items-center pt-3">
              <span className="font-semibold text-gray-450 text-gray-400">Email Contact</span>
              <span className="font-bold text-gray-700 font-sans truncate max-w-[150px]">{adminProfile?.email}</span>
            </div>

            <div className="flex justify-between items-center pt-3">
              <span className="font-semibold text-gray-450 text-gray-400">Security Status</span>
              <span className="bg-emerald-55 text-emerald-800 font-extrabold font-mono text-[10px] uppercase px-2 py-0.5 rounded-full bg-emerald-50 border border-emerald-150">
                {adminProfile?.status || 'Active'}
              </span>
            </div>

            <div className="flex justify-between items-center pt-3">
              <span className="font-semibold text-gray-450 text-gray-400">User Identification</span>
              <span className="font-mono text-gray-500 truncate max-w-[120px]" title={adminProfile?.adminId}>
                {adminProfile?.adminId}
              </span>
            </div>
          </div>
        </div>

        {/* Global Security Policies */}
        <div className="bg-white p-6 border border-gray-150 rounded-2xl lg:col-span-2 space-y-6 shadow-xs" id="admin-policies">
          
          <div>
            <h3 className="text-xs font-bold text-gray-450 uppercase font-mono tracking-widest text-gray-400 flex items-center gap-1.5 mb-2 select-none">
              <Settings className="w-4 h-4 text-indigo-600" />
              Active System Rule Guards
            </h3>
            <p className="text-xs text-gray-500">
              Administrative parameters are bound to Firestore Security rules and cannot be bypassed at the browser layer. Below is the configuration structure of the RBAC engine currently active.
            </p>
          </div>

          <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
            
            <div className="p-4 bg-gray-50 border border-gray-150 rounded-xl space-y-1.5">
              <div className="flex items-center gap-1 text-gray-800 font-extrabold text-xs">
                <ShieldCheck className="w-4 h-4 text-emerald-600 shrink-0" />
                <span>Dual Sandbox Shield</span>
              </div>
              <p className="text-3xs text-gray-500 leading-normal">
                Standard users are securely walled-off within their own customer identifiers path matching `request.auth.uid`. Cross-user data bleed reads or modifications is rejected by deep guards rules.
              </p>
            </div>

            <div className="p-4 bg-gray-50 border border-gray-150 rounded-xl space-y-1.5">
              <div className="flex items-center gap-1 text-gray-800 font-extrabold text-xs">
                <UserCheck className="w-4 h-4 text-indigo-600 shrink-0" />
                <span>Super-User Authentication Override</span>
              </div>
              <p className="text-3xs text-gray-500 leading-normal">
                Administrators are dynamically resolved via lookup checks pointing to "/admins/{"{uid}"}" matching collection indices, allowing instantaneous overrides to examine transactions.
              </p>
            </div>

          </div>

          <div className="p-4 bg-indigo-50/50 border border-indigo-150 rounded-xl flex gap-3 text-xs leading-normal">
            <Key className="w-5 h-5 text-indigo-600 shrink-0 mt-0.5 animate-pulse" />
            <div>
              <h4 className="font-bold text-indigo-950">Dynamic Admin Self-Bootstrapping Active</h4>
              <p className="text-indigo-900 mt-0.5">
                The administrative email <span className="font-mono font-bold select-all underline">{user?.email}</span> is validated by high-privilege keys. If a profile doesn't exist, the system creates it securely.
              </p>
            </div>
          </div>

        </div>

      </div>

    </div>
  );
}
