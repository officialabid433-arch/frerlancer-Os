import React, { useState, useEffect } from 'react';
import { 
  Plus, 
  Trash2, 
  Edit, 
  Calendar, 
  DollarSign, 
  Clock, 
  CheckCircle2, 
  Layout, 
  AlertCircle, 
  X, 
  Loader2, 
  UserPlus 
} from 'lucide-react';
import { Project, Client, ProjectStatus } from '../types';
import { getProjects, addProject, updateProject, deleteProject, getClients } from '../services/db';
import { useAuth } from '../contexts/AuthContext';

export default function ProjectsView() {
  const { user } = useAuth();
  const [projects, setProjects] = useState<Project[]>([]);
  const [clients, setClients] = useState<Client[]>([]);
  const [loading, setLoading] = useState(true);

  // Form States
  const [isModalOpen, setIsModalOpen] = useState(false);
  const [editingProject, setEditingProject] = useState<Project | null>(null);
  const [formName, setFormName] = useState('');
  const [formDesc, setFormDesc] = useState('');
  const [formClientId, setFormClientId] = useState('');
  const [formBudget, setFormBudget] = useState(0);
  const [formDeadline, setFormDeadline] = useState('');
  const [formStatus, setFormStatus] = useState<ProjectStatus>(ProjectStatus.PENDING);
  const [formSaving, setFormSaving] = useState(false);

  const loadData = async () => {
    if (!user) return;
    try {
      setLoading(true);
      const [projList, clientList] = await Promise.all([
        getProjects(user.uid),
        getClients(user.uid)
      ]);
      setProjects(projList);
      setClients(clientList);
      
      if (clientList.length > 0) {
        setFormClientId(clientList[0].id);
      }
    } catch (err) {
      console.error(err);
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    loadData();
  }, [user]);

  // Open modal for Add
  const handleOpenAdd = () => {
    setEditingProject(null);
    setFormName('');
    setFormDesc('');
    setFormBudget(0);
    setFormDeadline('');
    setFormStatus(ProjectStatus.PENDING);
    if (clients.length > 0) {
      setFormClientId(clients[0].id);
    } else {
      setFormClientId('');
    }
    setIsModalOpen(true);
  };

  // Open modal for Edit
  const handleOpenEdit = (project: Project) => {
    setEditingProject(project);
    setFormName(project.projectName);
    setFormDesc(project.description || '');
    setFormClientId(project.clientId);
    setFormBudget(project.budget);
    setFormDeadline(project.deadline || '');
    setFormStatus(project.status);
    setIsModalOpen(true);
  };

  // Save submit
  const handleSaveProject = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!user) return;
    if (!formName.trim() || !formClientId) {
      alert('Project Name and assigned Client are required fields.');
      return;
    }

    try {
      setFormSaving(true);
      if (editingProject) {
        await updateProject(user.uid, editingProject.id, {
          projectName: formName,
          description: formDesc,
          clientId: formClientId,
          budget: Number(formBudget),
          deadline: formDeadline,
          status: formStatus
        });
      } else {
        await addProject(user.uid, {
          clientId: formClientId,
          projectName: formName,
          description: formDesc,
          budget: Number(formBudget),
          deadline: formDeadline,
          status: formStatus
        });
      }
      setIsModalOpen(false);
      await loadData();
    } catch (err) {
      console.error(err);
      alert('Error updating project collection record: ' + (err instanceof Error ? err.message : String(err)));
    } finally {
      setFormSaving(false);
    }
  };

  // Delete Action
  const handleDeleteProject = async (id: string, name: string) => {
    if (!user) return;
    if (!confirm(`Are you sure you want to permanently delete project "${name}"?`)) return;
    try {
      await deleteProject(user.uid, id, name);
      await loadData();
    } catch (err) {
      console.error(err);
      alert('Failed to delete project.');
    }
  };

  // Find Client name mapping helper
  const getClientName = (clientId: string) => {
    const match = clients.find(c => c.id === clientId);
    return match ? match.clientName : 'Unassigned Client';
  };

  // KPIs
  const totalBdg = projects.reduce((acc, curr) => acc + (curr.budget || 0), 0);
  const activeCount = projects.filter(p => p.status === ProjectStatus.IN_PROGRESS).length;
  const pendingCount = projects.filter(p => p.status === ProjectStatus.PENDING).length;

  return (
    <div className="space-y-6" id="projects-view-container">
      {/* Header */}
      <div className="flex flex-col md:flex-row md:items-center md:justify-between gap-4" id="projects-view-header">
        <div>
          <h2 className="text-2xl font-bold tracking-tight text-gray-950" id="projects-title">Contracts & Workspaces</h2>
          <p className="text-sm text-gray-500 mt-1" id="projects-desc">Track timelines, contractual budgets, and workflow progress across your active scope.</p>
        </div>
        <button
          onClick={handleOpenAdd}
          disabled={clients.length === 0}
          className="inline-flex items-center gap-2 justify-center px-4 py-2 bg-indigo-600 hover:bg-indigo-700 disabled:opacity-50 text-white rounded-lg text-sm font-medium transition cursor-pointer"
          id="btn-add-project"
        >
          <Plus className="w-4 h-4" />
          Create Project
        </button>
      </div>

      {clients.length === 0 && !loading && (
        <div className="p-4 bg-amber-50 border border-amber-200 rounded-xl text-sm text-amber-800 flex items-start gap-3" id="warning-no-clients-registered">
          <AlertCircle className="w-5 h-5 text-amber-600 shrink-0 mt-0.5" />
          <div>
            <span className="font-bold">Prerequisite Action Needed: </span>
            You must add at least one client before you can initiate work project spaces. Head over to the <span className="underline font-bold">Client Directory</span> to register a client record first.
          </div>
        </div>
      )}

      {/* Stats row */}
      <div className="grid grid-cols-1 sm:grid-cols-3 gap-4" id="projects-kpis">
        <div className="bg-white p-4 rounded-xl border border-gray-100 flex items-center gap-4 shadow-xs" id="project-kpi-ongoing">
          <div className="p-3 bg-indigo-50 text-indigo-600 rounded-lg">
            <Clock className="w-5 h-5" />
          </div>
          <div>
            <p className="text-xs text-gray-500 font-medium font-sans">Active Projects</p>
            <h3 className="text-xl font-bold text-gray-900 mt-0.5">{activeCount}</h3>
          </div>
        </div>
        <div className="bg-white p-4 rounded-xl border border-gray-100 flex items-center gap-4 shadow-xs" id="project-kpi-pending">
          <div className="p-3 bg-amber-50 text-amber-600 rounded-lg">
            <Layout className="w-5 h-5" />
          </div>
          <div>
            <p className="text-xs text-gray-500 font-medium font-sans">Pending Projects</p>
            <h3 className="text-xl font-bold text-gray-900 mt-0.5">{pendingCount}</h3>
          </div>
        </div>
        <div className="bg-white p-4 rounded-xl border border-gray-100 flex items-center gap-4 shadow-xs" id="project-kpi-revenue">
          <div className="p-3 bg-emerald-50 text-emerald-600 rounded-lg">
            <DollarSign className="w-5 h-5" />
          </div>
          <div>
            <p className="text-xs text-gray-500 font-medium font-sans">Contract Gross value</p>
            <h3 className="text-xl font-bold text-gray-900 mt-0.5">${totalBdg.toLocaleString()}</h3>
          </div>
        </div>
      </div>

      {/* Grid listing */}
      {loading ? (
        <div className="flex flex-col items-center justify-center p-12 bg-white rounded-xl border border-gray-100 shadow-xs" id="projects-loading">
          <Loader2 className="w-8 h-8 text-indigo-600 animate-spin" />
          <p className="text-sm text-gray-500 mt-2">Retrieving active work deliverables...</p>
        </div>
      ) : projects.length === 0 ? (
        <div className="text-center p-12 bg-white rounded-xl border border-gray-100 shadow-xs" id="projects-empty">
          <div className="w-12 h-12 bg-indigo-50 text-indigo-600 rounded-full flex items-center justify-center mx-auto mb-3">
            <Layout className="w-6 h-6" />
          </div>
          <p className="text-base font-semibold text-gray-900">No projects started yet</p>
          <p className="text-sm text-gray-500 mt-1 max-w-sm mx-auto">
            Organize tasks and track deadlines. Map your project assignments to clients to calculate delivery metrics in real-time.
          </p>
          {clients.length > 0 && (
            <button
              onClick={handleOpenAdd}
              className="mt-4 px-4 py-2 bg-indigo-600 hover:bg-indigo-700 text-white rounded-lg text-sm font-medium transition cursor-pointer"
              id="cta-add-first-project"
            >
              Initiate Workspace
            </button>
          )}
        </div>
      ) : (
        <div className="grid grid-cols-1 md:grid-cols-2 gap-6" id="projects-grid-list">
          {projects.map((project) => (
            <div 
              key={project.id}
              className="bg-white rounded-xl border border-gray-100 shadow-xs overflow-hidden flex flex-col justify-between hover:border-indigo-150 transition group"
              id={`project-card-${project.id}`}
            >
              <div className="p-5 space-y-4">
                {/* Header */}
                <div className="flex items-start justify-between gap-3">
                  <div>
                    <h4 className="text-base font-bold text-gray-900 tracking-tight">{project.projectName}</h4>
                    <span className="inline-flex items-center gap-1 mt-1 text-xs font-semibold text-gray-500 bg-gray-50 rounded-md px-2 py-0.5 border border-gray-100">
                      <UserPlus className="w-3 h-3 text-indigo-500" />
                      {getClientName(project.clientId)}
                    </span>
                  </div>
                  <span 
                    className={`inline-flex items-center px-2 py-0.5 rounded-full text-2xs font-semibold uppercase tracking-wider ${
                      project.status === ProjectStatus.COMPLETED ? 'bg-emerald-50 text-emerald-700 border border-emerald-150' :
                      project.status === ProjectStatus.IN_PROGRESS ? 'bg-indigo-50 text-indigo-700 border border-indigo-155' :
                      project.status === ProjectStatus.PENDING ? 'bg-amber-50 text-amber-700 border border-amber-155' :
                      'bg-rose-55/10 text-rose-700 border border-rose-55/20'
                    }`}
                  >
                    {project.status}
                  </span>
                </div>

                {/* Description */}
                {project.description && (
                  <p className="text-xs text-gray-500 line-clamp-3">
                    {project.description}
                  </p>
                )}

                {/* Financial figures & dates */}
                <div className="grid grid-cols-2 gap-4 pt-4 border-t border-gray-50">
                  <div className="flex items-center gap-2">
                    <div className="p-2 bg-emerald-50 text-emerald-600 rounded-lg">
                      <DollarSign className="w-3.5 h-3.5" />
                    </div>
                    <div>
                      <p className="text-3xs text-gray-400 font-bold uppercase tracking-wider">Budget</p>
                      <p className="text-xs font-bold text-gray-900">${(project.budget || 0).toLocaleString()}</p>
                    </div>
                  </div>

                  <div className="flex items-center gap-2">
                    <div className="p-2 bg-indigo-50 text-indigo-600 rounded-lg">
                      <Calendar className="w-3.5 h-3.5" />
                    </div>
                    <div>
                      <p className="text-3xs text-gray-400 font-bold uppercase tracking-wider font-sans">Deadline</p>
                      <p className="text-xs font-bold text-gray-900">{project.deadline || 'Flexible timeline'}</p>
                    </div>
                  </div>
                </div>
              </div>

              {/* Action buttons footer */}
              <div className="px-5 py-3 bg-gray-50 border-t border-gray-100 flex items-center justify-end gap-3.5">
                <button
                  onClick={() => handleOpenEdit(project)}
                  className="p-1 px-2.5 text-xs text-gray-650 hover:text-indigo-600 flex items-center gap-1 bg-white border border-gray-250 rounded-md transition hover:border-indigo-300 font-medium cursor-pointer"
                  id={`btn-edit-proj-${project.id}`}
                >
                  <Edit className="w-3.5 h-3.5" />
                  Edit Workspace
                </button>
                <button
                  onClick={() => handleDeleteProject(project.id, project.projectName)}
                  className="p-1 px-2.5 text-xs text-rose-600 hover:text-rose-700 flex items-center gap-1 bg-white border border-rose-200 rounded-md transition hover:bg-rose-50 font-medium cursor-pointer"
                  id={`btn-delete-proj-${project.id}`}
                >
                  <Trash2 className="w-3.5 h-3.5" />
                  Delete
                </button>
              </div>
            </div>
          ))}
        </div>
      )}

      {/* Add / Edit Form Modal */}
      {isModalOpen && (
        <div className="fixed inset-0 bg-black/50 backdrop-blur-xs flex items-center justify-center z-50 p-4 animate-fade-in" id="project-modal-overlay">
          <div className="bg-white w-full max-w-lg rounded-2xl shadow-xl border border-gray-100 overflow-hidden flex flex-col animate-scale-up" id="project-modal-content">
            {/* Header */}
            <div className="px-6 py-4 border-b border-b-gray-100 flex items-center justify-between bg-gray-50">
              <h3 className="text-base font-bold text-gray-900">
                {editingProject ? 'Modify Project Parameters' : 'Create Project Workspace'}
              </h3>
              <button
                onClick={() => setIsModalOpen(false)}
                className="p-1.5 hover:bg-gray-200 text-gray-500 rounded-lg transition"
                id="btn-close-project-modal"
              >
                <X className="w-4.5 h-4.5" />
              </button>
            </div>

            {/* Form scroll */}
            <form onSubmit={handleSaveProject} className="p-6 space-y-4 overflow-y-auto max-h-[80vh]">
              <div>
                <label className="block text-xs font-semibold text-gray-700 mb-1">Project Name *</label>
                <input
                  type="text"
                  required
                  value={formName}
                  onChange={(e) => setFormName(e.target.value)}
                  placeholder="e.g. Redesign Corporate Landing Page"
                  className="w-full bg-white text-gray-900 border border-gray-200 rounded-lg px-3 py-2 text-sm outline-none focus:border-indigo-500"
                  id="input-project-name"
                />
              </div>

              <div>
                <label className="block text-xs font-semibold text-gray-700 mb-1">Assign Client *</label>
                <select
                  required
                  value={formClientId}
                  onChange={(e) => setFormClientId(e.target.value)}
                  className="w-full bg-white text-gray-900 border border-gray-200 rounded-lg px-3 py-2 text-sm outline-none focus:border-indigo-500 cursor-pointer"
                  id="input-project-client"
                >
                  {clients.map((c) => (
                    <option key={c.id} value={c.id}>
                      {c.clientName} ({c.company || 'Private Person'})
                    </option>
                  ))}
                </select>
              </div>

              <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                <div>
                  <label className="block text-xs font-semibold text-gray-700 mb-1">Contract Budget (USD) *</label>
                  <div className="relative">
                    <DollarSign className="absolute left-3 top-2.5 w-4 h-4 text-gray-400" />
                    <input
                      type="number"
                      required
                      min={0}
                      value={formBudget}
                      onChange={(e) => setFormBudget(Number(e.target.value))}
                      placeholder="e.g. 3500"
                      className="w-full bg-white text-gray-900 border border-gray-200 rounded-lg pl-8 pr-3 py-2 text-sm outline-none focus:border-indigo-500"
                      id="input-project-budget"
                    />
                  </div>
                </div>

                <div>
                  <label className="block text-xs font-semibold text-gray-700 mb-1">Target Deadline</label>
                  <input
                    type="date"
                    value={formDeadline}
                    onChange={(e) => setFormDeadline(e.target.value)}
                    className="w-full bg-white text-gray-900 border border-gray-200 rounded-lg px-3 py-2 text-sm outline-none focus:border-indigo-500"
                    id="input-project-deadline"
                  />
                </div>
              </div>

              <div>
                <label className="block text-xs font-semibold text-gray-700 mb-1">Deliverable Workflow Status</label>
                <select
                  value={formStatus}
                  onChange={(e) => setFormStatus(e.target.value as ProjectStatus)}
                  className="w-full bg-white text-gray-900 border border-gray-200 rounded-lg px-3 py-2 text-sm outline-none focus:border-indigo-500 cursor-pointer"
                  id="input-project-status"
                >
                  <option value={ProjectStatus.PENDING}>Pending Launch (Signed Agreement)</option>
                  <option value={ProjectStatus.IN_PROGRESS}>In Progress (Active Deliverables)</option>
                  <option value={ProjectStatus.COMPLETED}>Completed & Transferred</option>
                  <option value={ProjectStatus.CANCELLED}>Cancelled / Inactive Scope</option>
                </select>
              </div>

              <div>
                <label className="block text-xs font-semibold text-gray-700 mb-1 font-sans">Scope Description</label>
                <textarea
                  rows={4}
                  value={formDesc}
                  onChange={(e) => setFormDesc(e.target.value)}
                  placeholder="Detail clear milestones, constraints, and project expectations..."
                  className="w-full bg-white text-gray-900 border border-gray-200 rounded-lg px-3 py-2 text-sm outline-none focus:border-indigo-500 font-sans"
                  id="input-project-desc"
                />
              </div>

              {/* Action buttons */}
              <div className="pt-4 border-t border-gray-100 flex items-center justify-end gap-3">
                <button
                  type="button"
                  onClick={() => setIsModalOpen(false)}
                  className="px-4 py-2 text-sm font-semibold text-gray-700 hover:bg-gray-150 rounded-lg border border-gray-200 transition cursor-pointer"
                  id="btn-close-project-form"
                >
                  Cancel
                </button>
                <button
                  type="submit"
                  disabled={formSaving}
                  className="px-4 py-2 bg-indigo-600 hover:bg-indigo-700 text-white rounded-lg text-sm font-semibold transition inline-flex items-center gap-1 cursor-pointer disabled:opacity-50"
                  id="btn-submit-project"
                >
                  {formSaving && <Loader2 className="w-3.5 h-3.5 animate-spin" />}
                  {editingProject ? 'Update Deliverable' : 'Initialize Deliverable'}
                </button>
              </div>
            </form>
          </div>
        </div>
      )}
    </div>
  );
}
